    <div class="hero">
    <div class="container text-end">
        <div class="row d-flex align-items-center">
            <div class="col-md-6 text-md-end text-center text-white">
                <h1 style="font-size: 60px;"><?php echo getTranslation('welcome', $lang, $translations); ?></h1>
                <p><?php echo getTranslation('description', $lang, $translations); ?></p>
                <h2><?php echo getTranslation('join_us', $lang, $translations); ?></h2>
                <a href="register.php" class="btn btn-custom"><?php echo getTranslation('join_button', $lang, $translations); ?></a>
            </div>
            <div class="col-md-6 text-center">
                <img src="imge/logo2.jpg" alt="<?php echo getTranslation('brand', $lang, $translations); ?>" class="logo">
            </div>
        </div>
    </div>
</div>