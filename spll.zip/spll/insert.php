<?php 
// Include database connection (adjust as necessary)
include 'config/connect.php';

// Sample passwords for each user (you can change them as needed)
$sample_password = '123456'; // Example password
$users = [
    // Branch 1
    // Male Proctors
    ['username' => 'Dr. Hamdan Ahmed Al-Zahrani', 'email' => 'hzahrani@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Ihsan Ahmed', 'email' => 'iahmed@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Youssef Ali Al-Mansour', 'email' => 'ymansour@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Khaled Mohammed Al-Shehri', 'email' => 'kshehri@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Ziad Mohammed Al-Ali', 'email' => 'zsaleh@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Male IT-Support
    ['username' => 'Ahmed Saeed Al-Ghamdi', 'email' => 'aghamdi@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Omar Abdulaziz Al-Fahad', 'email' => 'ofahad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Faisal Mohammed Al-Harbi', 'email' => 'fharbi1@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Tamer Ali Al-Mutairi', 'email' => 'tmutairi@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Nasser Ibrahim Al-Juhani', 'email' => 'njuhani@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Female Proctors
    ['username' => 'Abrar Mohammed Al-Zahrani', 'email' => 'abrar@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Buthaina Saeed Al-Harbi', 'email' => 'buthaina@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Sabah Ahmed Al-Ghamdi', 'email' => 'sabah@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Zainab Ali Al-Shehri', 'email' => 'zainab@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Wardah Ibrahim Al-Juhani', 'email' => 'wardah@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Female IT-Support
    ['username' => 'Hasna Abdullah Al-Fahad', 'email' => 'hasna@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Alya Mohammed Al-Mutairi', 'email' => 'alya@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Amani Saeed Al-Ghamdi', 'email' => 'amanis@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Ahlam Ahmed Al-Saleh', 'email' => 'ahlam@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Widad Khalid Al-Shehri', 'email' => 'widad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 1, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Branch 2
    // Male Proctors
    ['username' => 'Dr. Samir Ahmed Al-Mansour', 'email' => 'smansour1@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Tariq Ali Al-Harbi', 'email' => 'tharbi@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Rami Abdulaziz Al-Ghamdi', 'email' => 'rghamdi@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Walid Mohammed Al-Juhani', 'email' => 'wjuhani@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Abdullah Mohammed Al-Saleh', 'email' => 'asaleh1@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Male IT-Support
    ['username' => 'Saeed Ibrahim Al-Fahad', 'email' => 'sfahad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Khalid Ali Al-Mutairi', 'email' => 'kmutairi@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Omar Mohammed Al-Saleh', 'email' => 'osaleh@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Yasser Abdulaziz Al-Mansour', 'email' => 'ymansour1@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Fawaz Mohammed Al-Juhani', 'email' => 'fjuhani@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Female Proctors
    ['username' => 'Shahd Ali Al-Najdi', 'email' => 'shahd@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Noura Ahmed Al-Shehri', 'email' => 'noura@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Fatima Mohammed Al-Suqur', 'email' => 'fatima@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Ranya Zainab Al-Mansour', 'email' => 'ranya@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Reem Abdulrahman Al-Fahad', 'email' => 'reem@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Female IT-Support
    ['username' => 'Maha Ali Al-Saleh', 'email' => 'maha@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Sara Mohammed Al-Juhani', 'email' => 'sara@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Layla Ibrahim Al-Ghamdi', 'email' => 'layla@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Hanan Zainab Al-Suqur', 'email' => 'hanan@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Hind Abdulrahman Al-Mansour', 'email' => 'hind@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 2, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Branch 3
    // Male Proctors
    ['username' => 'Dr. Ahmad Mohammed Al-Juhani', 'email' => 'amjuhani@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Khalil Ali Al-Fahad', 'email' => 'kalfahad@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Ali Ahmad Al-Suqur', 'email' => 'aaalq@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Zahir Abdulaziz Al-Mansour', 'email' => 'zalmansour@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Nabil Mohammed Al-Ghamdi', 'email' => 'nghamdi@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Male IT-Support
    ['username' => 'Yusuf Saeed Al-Juhani', 'email' => 'yusuf@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Abdul Rahman Khalid Al-Fahad', 'email' => 'arfahad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Zaid Mohammed Al-Suqur', 'email' => 'zaid@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Rami Abdulaziz Al-Mansour', 'email' => 'rami@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Hamza Ali Al-Ghamdi', 'email' => 'hamza@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Female Proctors
    ['username' => 'Sara Ali Al-Qahtani', 'email' => 'saraqahtani@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Lina Mohammed Al-Mutairi', 'email' => 'linamutairi@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dalia Abdulrahman Al-Najdi', 'email' => 'dalia@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Hana Saeed Al-Qarmizi', 'email' => 'hana@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Salma Abdulaziz Hilal', 'email' => 'salma@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Female IT-Support
    ['username' => 'Nour Ahmed Al-Hamad', 'email' => 'nour@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Rana Zainab Al-Suqur', 'email' => 'rana@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Amani Khalid Al-Naqour', 'email' => 'amani@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Yasmin Ali Al-Masry', 'email' => 'yasmina@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Raghad Mohammed Al-Ghamdi', 'email' => 'raghad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 3, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Branch 4
    // Male Proctors
    ['username' => 'Dr. Hamid Abdulaziz Al-Harbi', 'email' => 'hamid@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Basim Mohammed Al-Ghamdi', 'email' => 'bgamdi@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Khaled Ali Al-Saleh', 'email' => 'kalsaleh@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Samir Ahmad Al-Qarni', 'email' => 'saqarni@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Dr. Munir Ali Al-Awaji', 'email' => 'mawaji@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Male IT-Support
    ['username' => 'Adnan Khalid Al-Ghamdi', 'email' => 'adnan@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Yasmeen Mohammed Al-Suqur', 'email' => 'yasmeen@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Saad Abdulaziz Al-Juhani', 'email' => 'saad@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Mohammed Hamad Al-Fahad', 'email' => 'mohammed@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Sultan Mohammed Al-Mutairi', 'email' => 'sultan@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Male', 'verification' => 0, 'password' => $sample_password],

    // Female Proctors
    ['username' => 'Rama Aisha Al-Suqur', 'email' => 'rama@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Afnan Ali Al-Mansour', 'email' => 'afnan@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Nadia Abdulaziz Al-Ghamdi', 'email' => 'nadia@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Alaa Mohammed Al-Juhani', 'email' => 'alaa@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Yasmin Khalid Al-Najdi', 'email' => 'yasmin@seu.edu.sa', 'role' => 'Proctor', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],

    // Female IT-Support
    ['username' => 'Alia Zainab Al-Saleh', 'email' => 'alia@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Rita Abdulrahman Al-Ghamdi', 'email' => 'rita@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Noura Ahmed Al-Najdi', 'email' => 'nouraa@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Muna Mohammed Al-Fahad', 'email' => 'muna@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
    ['username' => 'Mariam Ali Al-Juhani', 'email' => 'mariam@seu.edu.sa', 'role' => 'IT-Support', 'branch_id' => 4, 'gender' => 'Female', 'verification' => 0, 'password' => $sample_password],
];

 
$query = "INSERT INTO `users` (`username`, `email`, `password_hash`, `role`, `branch_id`, `verification`, `gender`) VALUES ";

$values = [];
foreach ($users as $user) {
    $hashed_password = password_hash($user['password'], PASSWORD_DEFAULT);
    $values[] = "('" . mysqli_real_escape_string($conn, $user['username']) . "', '" . mysqli_real_escape_string($conn, $user['email']) . "', '$hashed_password', '" . mysqli_real_escape_string($conn, $user['role']) . "', " . $user['branch_id'] . ", " . $user['verification'] . ", '" . mysqli_real_escape_string($conn, $user['gender']) . "')";
}

$query .= implode(", ", $values) . ";";

// Execute the query
if (mysqli_query($conn, $query)) {
    echo "New users added successfully!";
} else {
    echo "Error: " . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
?>