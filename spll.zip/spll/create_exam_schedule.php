<?php
require_once('config/connect.php');

// جلب بيانات المدخلات من المستخدم
$exam_id = $_POST['exam_id'];
$exam_start_date = $_POST['exam_date_start'];
$exam_end_date = $_POST['exam_date_end'];

// جلسات الامتحانات - كل جلسة مدتها 60 دقيقة وبين كل جلسة وأخرى 30 دقيقة
$sessions = [
    ['start_time' => '16:00:00', 'end_time' => '17:00:00'],
    ['start_time' => '17:30:00', 'end_time' => '18:30:00'],
    ['start_time' => '19:00:00', 'end_time' => '20:00:00'],
    ['start_time' => '20:30:00', 'end_time' => '21:30:00']
];

// جلب جميع الفروع والكليات والأقسام والكورسات من قاعدة البيانات
$query = "
    SELECT 
        c.course_id, c.course_name, 
        b.branch_id, b.branch_name, 
        cl.College_id, cl.College_name, 
        d.Department_id, d.Department 
    FROM courses c
    JOIN department d ON c.course_id = d.Department_id
    JOIN college cl ON d.collage_id = cl.College_id
    JOIN branches b ON cl.branch_id = b.branch_id
";
$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    // تكرار لكل يوم بين تاريخ البداية والنهاية
    $current_date = $exam_start_date;
    while (strtotime($current_date) <= strtotime($exam_end_date)) {
        $session_count = 0;
        
        // تكرار لكل جلسة في اليوم
        while ($session_count < count($sessions)) {
            // تكرار لكل مادة وفرع وقسم
            mysqli_data_seek($result, 0); // إعادة تعيين المؤشر في النتائج
            while ($row = mysqli_fetch_assoc($result)) {
                $course_id = $row['course_id'];
                $branch_id = $row['branch_id'];
                $college_id = $row['College_id'];
                $department_id = $row['Department_id'];

                $start_time = $sessions[$session_count]['start_time'];
                $end_time = $sessions[$session_count]['end_time'];

                // إدخال بيانات الجدول في قاعدة البيانات
                $insert_query = "
                    INSERT INTO exam_schedules 
                    (exam_id, exam_date_start, exam_date_end, start_time, end_time, course_id, branch_id, College, Department, semester) 
                    VALUES ('$exam_id', '$current_date', '$current_date', '$start_time', '$end_time', '$course_id', '$branch_id', '$college_id', '$department_id', 'Semester 1')
                ";
                
                // تنفيذ استعلام الإدخال والتحقق من الأخطاء
                if (!mysqli_query($conn, $insert_query)) {
                    echo "Error inserting record: " . mysqli_error($conn);
                }
            }

            $session_count++;
        }
        // الانتقال إلى اليوم التالي
        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
    }
    echo "Exam schedule generated successfully!";
} else {
    echo "Error fetching course and department details.";
}
?>
