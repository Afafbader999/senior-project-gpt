<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('brand', $lang, $translations); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap" rel="stylesheet">
 <style>
  html,
 body {
     font-family: 'Cairo', sans-serif;
 
     margin: 0;
     display: flex;
     flex-direction: column;
     background: #fff;
     color: #000;
 }
     header {
         background-color: #000;
         color: #fff;
         padding: 20px;
     }

     header nav a {
         color: #fff;
         margin: 0 10px;
         text-decoration: none;
         font-weight: lighter;
         font-size: large;
     }

     .hero {
         flex: 1;
         display: flex;
         align-items: center;
         padding: 50px 0;
         position: relative;
     }

     .hero h1,
     .hero p,
     .hero h2 {
         color: #000;
     }

     .hero .btn {
         background-color: #000;
         color: #fff;
         padding: 10px 20px;
         border-radius: 15px;
     }

     .hero .row {
         display: flex;
         align-items: center;
         /* محاذاة رأسية للوسط */
         justify-content: space-between;
         /* توزيع العناصر أفقياً */
     }

     .logo {
         max-width: 100%;
         height: auto;
     }

 
.btn:hover {
    background-color: #fff;
    color: #160505;
    border: 1px solid #000;
}

     .logo {
         max-width: 100%;
     }

     footer {
         text-align: center;
         background-color: #000;
         color: #fff;
         padding: 10px;
 
     }

     .form-container {
        margin-top: 50px;
        max-width: 500px;
        margin-left: auto;
        margin-right: auto;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 10px;
        background-color: #f9f9f9;
    }
 </style>
    <link href="css/styles.css" rel="stylesheet">
 
</head>
<body>

    <!-- Include header -->
    <?php include 'config/header.php'; ?>

    <!-- Hero section based on user session -->
    <?php 
    if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])) {
        include 'homepage.php'; // Include homepage for guests
    } else {
        include 'hero.php'; // Include hero section for logged-in users
    }
    ?>

 
<?php include 'config/footer.php' ; ?>

</body>
</html>
