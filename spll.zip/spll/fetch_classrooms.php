<?php
include 'config/connect.php'; // تضمين الاتصال بقاعدة البيانات

if (isset($_GET['branch_id'])) {
    $branchId = intval($_GET['branch_id']); // الحصول على ID الفرع
    $result = mysqli_query($conn, "SELECT room_id, room_name FROM classrooms WHERE branch_id = $branchId");
    
    $classrooms = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $classrooms[] = $row; // إضافة الغرف إلى المصفوفة
    }
    
    echo json_encode($classrooms); // إرسال البيانات كـ JSON
}
?>
