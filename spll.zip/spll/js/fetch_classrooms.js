  function fetchClassrooms(branchId) {
                            if (branchId) {
                                const xhr = new XMLHttpRequest();
                                xhr.open('GET', `fetch_classrooms.php?branch_id=${branchId}`, true);
                                xhr.onload = function() {
                                    if (this.status === 200) {
                                        const classrooms = JSON.parse(this.responseText);
                                        const classroomSelect = document.getElementById('classroom_id');
                                        classroomSelect.innerHTML = ''; // Clear previous options
                                        classrooms.forEach(function(classroom) {
                                            const option = document.createElement('option');
                                            option.value = classroom.room_id;
                                            option.textContent = classroom.room_name;
                                            classroomSelect.appendChild(option);
                                        });
                                        document.getElementById('classroom-container').style.display = 'block'; // Show classroom section
                                    }
                                };
                                xhr.send();
                            } else {
                                document.getElementById('classroom-container').style.display = 'none'; // Hide classroom section if no branch is selected
                            }
                        }
          
            // Function to check classroom availability and manage form submission
            document.getElementById("end_time").addEventListener("blur", function () {
                var classroomId = document.getElementById("classroom_id").value;
                var branchId = document.getElementById("branch_idl").value; // إضافة branch_id هنا
                var examDate = document.getElementById("exam_date").value;
                var startTime = document.getElementById("start_time").value;
                var endTime = document.getElementById("end_time").value;
                var classMessage = document.getElementById("classMessage");
                var submitButton = document.getElementById("submit");

                // طباعة القيم للتحقق
                console.log("Classroom ID:", classroomId);
                console.log("Branch ID:", branchId); // تأكد من طباعة branch_id
                console.log("Exam Date:", examDate);
                console.log("Start Time:", startTime);
                console.log("End Time:", endTime);

                // التأكد من أن كل الحقول الضرورية مليئة
                if (classroomId && branchId && examDate && startTime && endTime) {
                    // AJAX request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function () {
                        if (this.readyState === 4 && this.status === 200) {
                            var responseText = this.responseText.trim(); // إزالة المسافات الزائدة
                            classMessage.innerText = responseText;

                            // تحقق من توفر القاعة
                            if (responseText === 'The classroom is available.') {
                                submitButton.disabled = false; // تفعيل زر الإرسال
                            } else {
                                submitButton.disabled = true; // تعطيل زر الإرسال
                            }
                        }
                    };
                    xhttp.open("POST", "check_class_availability.php", true);
                    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    xhttp.send("classroom_id=" + classroomId + "&branch_id=" + branchId + "&exam_date=" + examDate + "&start_time=" + startTime + "&end_time=" + endTime); // إرسال branch_id هنا
                } else {
                    classMessage.innerText = "Please fill in all fields.";
                    submitButton.disabled = true; // تعطيل زر الإرسال إذا كانت الحقول غير مكتملة
                }
            });

            // Function to update the submit button state based on field values
            function updateSubmitButton() {
                var classroomId = document.getElementById("classroom_id").value;
                var branchId = document.getElementById("branch_id").value; // إضافة branch_id هنا
                var examDate = document.getElementById("exam_date").value;
                var startTime = document.getElementById("start_time").value;
                var endTime = document.getElementById("end_time").value;
                var submitButton = document.querySelector("form button[type='submit']");

                // التأكد من أن كل الحقول الضرورية مليئة
                if (classroomId && branchId && examDate && startTime && endTime) {
                    submitButton.disabled = false; // تفعيل زر الإرسال
                } else {
                    submitButton.disabled = true; // تعطيل زر الإرسال
                }
            }
 
 