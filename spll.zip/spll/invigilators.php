    <?php
    //invigilators.php
    session_start();

    // التحقق من الجلسة
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php"); // إعادة توجيه المستخدم لصفحة تسجيل الدخول
        exit();
    }

    // تضمين ملف الترجمة
    include 'lang.php';

    // تحديد اللغة
    $lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; // افتراضياً اللغة الإنجليزية
    $username = isset($_SESSION['username']) ? $_SESSION['username'] : '';


    // Check if the session is valid
    if (!isset($_SESSION['branch_id'])) {
        echo json_encode(["error" => "Branch ID is not set."]);
        exit();
    }

    // Get the branch ID from the session
    $branch_id = intval($_SESSION['branch_id']);

    
    ?>
    <!DOCTYPE html>
    <html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo getTranslation('dashboard', $lang, $translations); ?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <style>
            body {
                font-family: 'Cairo', sans-serif;
                direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
            }

            .sidebar {
                height: 100vh;
                background-color: #000;
                color: white;
                text-align: center;
                padding-top: 20px;
                position: fixed;
                top: 0;
                <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
                width: 250px;
                transition: width 0.3s;
            }

            .sidebar a {
                color: white;
                text-decoration: none;
                display: block;
                padding: 10px 20px;
            }

            .sidebar a:hover {
                background-color: #495057;
            }

            .dashboard-content {
                margin-left: 250px; /* Adjust margin based on sidebar width */
                margin-top: 20px; /* Space above content */
                padding: 20px; /* Padding inside content */
                transition: margin 0.3s;
            }

            .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
            /* ضبط محاذاة النص */
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>margin-left: 15px;
            /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>margin-right: 15px;
            /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .navbar .dropdown-menu a {
            color: black;
        }

            .btn-primary {
                background-color: #000;
                color: #fff;
                padding: 10px 20px;
                border-radius: 15px;
            }

            /* Responsive adjustments */
            @media (max-width: 768px) {
                .sidebar {
                    display: none; /* Hide sidebar on small screens */
                }

                .dashboard-content {
                    margin: 0; /* Reset margin for mobile */
                    padding: 20px; /* Ensure padding remains */
                }
            }

            /* Toast styles */
            .message {
                display: none;
                margin: 10px 0;
                color: green;
            }

            .error {
                color: red;
            }
            h1 {
            margin-top: 20px;
            text-align: center;
        }
        </style>
    </head>

    <body>

        <?php include 'sidebar.php'; ?>

        <div class="dashboard-content">
            <h1 >Exam Invigilator Management</h1>

            <!-- Toast Container -->
            <div class="toast-container position-fixed top-50 end-50 p-3">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                            <strong class="me-auto">Notification</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            <?php
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
<br>
<br>
            <div id="messageDiv" style='display:none;' class="message"></div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12"> <!-- Adjusted to 12 columns for full width -->
                        <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="invigilatorsTable">
    <thead class="table-dark">
        <tr>
            <th>Exam Name</th>
            <th>Course Name</th>
            <th>Room Name</th>
            <th>Exam Date</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Invigilator 1</th>
            <th>Invigilator 2</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <form action="insert_exam_assignment.php" method="post" onsubmit="return validateInvigilators()">
                <td>
                    <select class="form-control" id="exam_id" name="exam_id" required>
                        <option value="0">Select Exam</option>
                        <option value="1">Midterm Exam</option>
                        <option value="2">Final Exam</option>
                        <option value="3">Lab</option>
                    </select>
                </td>
                <td>
                    <select id="course_id" name="course_id" required class="form-control" onchange="fetchExamDetails()">
                        <option value="">Select Course</option>
                    </select>
                </td>
                <td>
                    <?php
                    include 'config/connect.php'; 
                    $sql = "SELECT room_id, room_name FROM classrooms WHERE branch_id='$branch_id'";
                    $result = $conn->query($sql);
                    ?>
                    <select id="room_id" name="room_id" required class="form-control">
                        <option value="">Select Room</option>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . $row['room_id'] . '">' . htmlspecialchars($row['room_name']) . '</option>';
                            }
                        } else {
                            echo '<option value="">No Rooms Available</option>';
                        }
                        ?>
                    </select>
                </td>
                <td>
                    <input type="date" id="assignment_date" name="assignment_date" required class="form-control">
                </td>
                <td>
                    <input type="time" id="start_time" name="start_time" required class="form-control">
                </td>
                <td>
                    <input type="time" id="end_time" name="end_time" required class="form-control">
                </td>
                <td>
                    <?php
                    include 'config/connect.php'; 
                    $branch_id = $_SESSION['branch_id'];
                    $sql = "SELECT user_id, username FROM users WHERE branch_id = ? AND role = 'Proctor' AND account_status = 'Active'";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $branch_id);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    ?>
                    <select id="invigilator1" name="invigilator1" required class="form-control">
                        <option value="">Select Invigilator</option>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
                            }
                        } else {
                            echo '<option value="">No Invigilators Available</option>';
                        }
                        ?>
                    </select>
                </td>
                <td>
                    <select id="invigilator2" name="invigilator2" class="form-control">
                        <option value="">Select Invigilator (Optional)</option>
                        <?php
                        // إعادة استخدام الاستعلام السابق لجلب المراقبين مع التحقق
                        $selected_invigilator1 = isset($_POST['invigilator1']) ? intval($_POST['invigilator1']) : 0;
                        $sql = "SELECT user_id, username FROM users WHERE branch_id = ? AND role = 'Proctor' AND account_status = 'Active' AND user_id != ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("ii", $branch_id, $selected_invigilator1);
                        $stmt->execute();
                        $result = $stmt->get_result();
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
                            }
                        } else {
                            echo '<option value="">No Invigilators Available</option>';
                        }
                        ?>
                    </select>
                </td>
                <td>
      
                    <input type="submit" value="Submit" class="btn btn-primary">
                </td>
            </form>
        </tr>
    </tbody>
</table>

<script>
function validateInvigilators() {
    const invigilator1 = document.getElementById('invigilator1').value;
    const invigilator2 = document.getElementById('invigilator2').value;

    if (invigilator1 && invigilator1 === invigilator2) {
        alert('Invigilator 2 cannot be the same as Invigilator 1.');
        return false; // يمنع إرسال النموذج
    }
    return true; // يسمح بإرسال النموذج
}
</script>


                          
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $(document).ready(function() {
        var branchId = <?php echo isset($_SESSION['branch_id']) ? intval($_SESSION['branch_id']) : 0; ?>;

        $('#exam_id').change(function() {
            var examId = $(this).val();

            // تأكد من أن examId صالح
            if (examId != 0) {
                $.ajax({
                    url: 'get_courses.php', // ملف PHP لجلب المواد
                    type: 'POST',
                    data: { exam_id: examId, branch_id: branchId },
                    success: function(response) {
                        // تحديث قائمة المواد
                        $('#course_id').html(response);
                    }
                });
            } else {
                // إعادة تعيين قائمة المواد في حالة عدم اختيار امتحان
                $('#course_id').html('<option value="">Select Course</option>');
            }
        });
    });


    function fetchExamDetails() {
    var courseId = document.getElementById("course_id").value;
    var branchId = <?php echo json_encode($branch_id); ?>;

    if (courseId) {
        // إنشاء طلب AJAX
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_exam_details.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                
                // التأكد من استلام البيانات وتحديث الحقول
                if (response.success) {
                    document.getElementById("assignment_date").value = response.exam_date_start;
                    document.getElementById("start_time").value = response.start_time;
                    document.getElementById("end_time").value = response.end_time;
                } else {
                    alert("No exam details found for the selected course.");
                }
            }
        };

        // إرسال بيانات المادة وbranch_id إلى ملف PHP
        xhr.send("course_id=" + courseId + "&branch_id=" + branchId);
    }
}

    </script>


        <script>
            let invigilatorsData = []; // Array to hold the data

            function fetchInvigilators() {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'fetch_invigilators.php', true);
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            var data = JSON.parse(xhr.responseText);
                            var tbody = document.querySelector('#invigilatorsTable tbody');
                            tbody.innerHTML = ''; // Clear previous data

                            if (data.error) {
                                alert(data.error);
                                return;
                            }

                            // Store invigilators data
                            invigilatorsData = []; // Reset the array

                            // Append new rows
                            data.forEach(function(invigilator) {
                                var row = document.createElement('tr');
                                row.innerHTML = `
                                    <td>${invigilator.course_name}</td>
                                    <td>${invigilator.room_name}</td>
                                    <td>${invigilator.exam_date}</td>
                                    <td>${invigilator.start_time}</td>
                                    <td>${invigilator.end_time}</td>
                                    <td>${invigilator.invigilator_1}</td>
                                    <td>${invigilator.invigilator_2}</td>
                                `;

                                invigilatorsData.push({
                                    exam_id: invigilator.exam_id,
                                    invigilator_1_id: invigilator.invigilator_1_id,
                                    invigilator_2_id: invigilator.invigilator_2_id,
                                    branch_id: invigilator.branch_id,
                                    room_id: invigilator.room_id,
                                    course_id: invigilator.course_id,
                                    exam_date: invigilator.exam_date,
                                    start_time: invigilator.start_time,
                                    end_time: invigilator.end_time
                                });
                                tbody.appendChild(row);
                            });
                        } else {
                            alert('Error fetching data: ' + xhr.status);
                        }
                    }
                };
                xhr.send();
            }

            // Fetch invigilators on page load
            fetchInvigilators();

            // Reassign button click
            document.getElementById('reassignBtn').addEventListener('click', function() {
                fetchInvigilators(); // Re-fetch and update table
            });

            function approveDistribution() {
                if (typeof invigilatorsData !== 'undefined' && invigilatorsData.length > 0) {
                    let allRequests = []; // Store all requests to send later

                    for (let invigilator of invigilatorsData) {
                        let dataToSend = {
                            exam_id: invigilator.exam_id || '',
                            invigilator_1_id: invigilator.invigilator_1_id || '',
                            invigilator_2_id: invigilator.invigilator_2_id || '',
                            branch_id: invigilator.branch_id || '',
                            room_id: invigilator.room_id || '',
                            course_id: invigilator.course_id || '',
                            assignment_date: invigilator.exam_date,
                            start_time: invigilator.start_time,
                            end_time: invigilator.end_time
                        };
                        console.log("Sending data:", dataToSend); // Log data for review

                        const request = new Promise((resolve, reject) => {
                            const xhr = new XMLHttpRequest();
                            xhr.open('POST', 'add_invigilators.php', true);
                            xhr.setRequestHeader('Content-Type', 'application/json');
                            xhr.onload = function() {
                                if (xhr.status >= 200 && xhr.status < 300) {
                                    resolve(xhr.responseText); // Resolve the promise
                                } else {
                                    reject('Request failed with status ' + xhr.status); // Reject the promise
                                }
                            };
                            xhr.send(JSON.stringify(dataToSend));
                        });
                        allRequests.push(request); // Add to array
                    }

                    Promise.all(allRequests)
                        .then((responses) => {
                            console.log('All requests completed successfully:', responses);
                            document.getElementById('messageDiv').innerHTML = '<div class="alert alert-success">Invigilators assigned successfully!</div>';
                            document.getElementById('messageDiv').style.display = 'block';
                        })
                        .catch((error) => {
                            console.error('One or more requests failed:', error);
                            document.getElementById('messageDiv').innerHTML = '<div class="alert alert-danger">Error assigning invigilators.</div>';
                            document.getElementById('messageDiv').style.display = 'block';
                        });
                } else {
                    console.error('No invigilators data available to send.');
                    document.getElementById('messageDiv').innerHTML = '<div class="alert alert-warning">No data to send.</div>';
                    document.getElementById('messageDiv').style.display = 'block';
                }
            }

            document.querySelector('.btn-success').addEventListener('click', approveDistribution);
        </script>
    </body>

    </html>
