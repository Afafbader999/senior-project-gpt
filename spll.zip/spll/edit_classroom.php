<?php
session_start();
// الاتصال بقاعدة البيانات
require_once('config/connect.php');

// التحقق من وجود room_id في الرابط
if (isset($_GET['id'])) {
    $room_id = $_GET['id'];

    // جلب بيانات الغرفة من قاعدة البيانات بناءً على room_id
    $sql = "SELECT * FROM classrooms WHERE room_id = $room_id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Classroom not found.";
        exit();
    }
}

// التحقق من إرسال النموذج
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // استخدام mysqli_real_escape_string لحماية المدخلات
    $room_name = mysqli_real_escape_string($conn, $_POST['room_name']);
    $building_name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $capacity = mysqli_real_escape_string($conn, $_POST['capacity']);
    $floor = mysqli_real_escape_string($conn, $_POST['floor']);
    $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
    $branch_id = mysqli_real_escape_string($conn, $_POST['branch_id']);

    // استعلام التعديل
    $sql = "UPDATE classrooms 
            SET room_name = '$room_name', building_name = '$building_name', capacity = '$capacity', floor = '$floor', room_type = '$room_type', branch_id = '$branch_id' 
            WHERE room_id = $room_id";
if (mysqli_query($conn, $sql)) {
    $_SESSION['message'] = 'Classroom data updated successfully.';
    header("Location: dashboard.php?msg=success");
    exit();
} else {
    $_SESSION['message'] = 'An error occurred while updating the classroom data: ' . mysqli_error($conn);
    header("Location: dashboard.php?msg=nocchange");
    exit();
}

}


// إغلاق الاتصال بقاعدة البيانات
mysqli_close($conn);
?>


<!-- HTML FORM لعرض وتعديل بيانات الغرفة -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Classroom</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Classroom</h2>
    <form action="" method="POST">
        <div class="mb-3">
            <label for="room_name" class="form-label">Room Name</label>
            <input type="text" class="form-control" id="room_name" name="room_name" value="<?php echo $row['room_name']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="building_name" class="form-label">Building Name</label>
            <select class="form-control" id="building_name" name="building_name" required>
                <option value="Female' Building" <?php echo ($row['building_name'] == "Female' Building") ? "selected" : ""; ?>>Female' Building</option>
                <option value="Male' Building" <?php echo ($row['building_name'] == "Male' Building") ? "selected" : ""; ?>>Male' Building</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="capacity" class="form-label">Capacity</label>
            <input type="number" class="form-control" id="capacity" name="capacity" value="<?php echo $row['capacity']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="floor" class="form-label">Floor</label>
            <input type="number" class="form-control" id="floor" name="floor" value="<?php echo $row['floor']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="room_type" class="form-label">Room Type</label>
            <input type="text" class="form-control" id="room_type" name="room_type" value="<?php echo $row['room_type']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="branch_id" class="form-label">Branch ID</label>
            <input type="number" class="form-control" id="branch_id" name="branch_id" value="<?php echo $row['branch_id']; ?>" required>
        </div>
        <button type="submit" class="btn btn-secondary">Update Classroom</button>
    </form>
</div>
</body>
</html>
