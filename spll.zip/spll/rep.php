<?php
session_start();
include 'config/connect.php'; // Database connection

// Ensure the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
include 'lang.php';
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; 
$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// Fetch the username based on the user_id
$user_query = "SELECT username FROM users WHERE user_id = ?";
$stmt = $conn->prepare($user_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username);
$stmt->fetch();
$stmt->close();

// Verify the user has the necessary permissions
if ($role !== 'Admin') {
    echo "You do not have permission to view this page.";
    exit();
}

// Fetch incident reports specific to the user's branch
$reports_query = "
    SELECT rp.report_id, rp.type_problem, rp.description, rp.Attachments, rp.created_at, u.username
    FROM report_problems rp
    JOIN users u ON rp.reported_by_user = u.user_id
    WHERE rp.branch_id = $branch_id
    ORDER BY rp.created_at DESC
";
$reports_result = $conn->query($reports_query);

// Fetch service evaluations specific to the user's branch
$evaluations_query = "
    SELECT se.evaluation_id, se.rating, se.feedback, u.username
    FROM service_evaluations se
    JOIN users u ON se.user_id = u.user_id
    WHERE se.branch_id = $branch_id
    ORDER BY se.evaluation_id DESC
";
$evaluations_result = $conn->query($evaluations_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Branch Reports</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }

        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            left: 0; /* Sidebar on the left */
            width: 250px;
            transition: width 0.3s;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .dashboard-content {
            margin-left: 250px; /* Adjust margin for left sidebar */
            margin-top: 20px; /* Space above content */
            padding: 20px; /* Padding inside content */
            transition: margin 0.3s;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
            /* ضبط محاذاة النص */
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>margin-left: 15px;
            /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>margin-right: 15px;
            /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .navbar .dropdown-menu a {
            color: black;
        }

        h1 {
            margin-top: 20px;
            text-align: center;
        }

        table {
            margin-top: 20px;
        }

        @media (max-width: 768px) {
            .sidebar {
                display: none; /* Hide sidebar on small screens */
            }

            .dashboard-content {
                margin: 0; /* Reset margin for mobile */
                padding: 20px; /* Ensure padding remains */
            }
        }
        .nav-tabs .nav-link {
    color: black; /* Set text color to black */
}

.nav-tabs .nav-link.active {
    color: white; /* Optional: Change active tab text color */
    background-color: #000; /* Optional: Change active tab background color */
}
    </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="dashboard-content">
    

    <h1>Branch Reports</h1>

    <ul class="nav nav-tabs" id="branchTabs" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="incident-reports-tab" data-bs-toggle="tab" href="#incident-reports" role="tab" aria-controls="incident-reports" aria-selected="true">Incident Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="service-evaluations-tab" data-bs-toggle="tab" href="#service-evaluations" role="tab" aria-controls="service-evaluations" aria-selected="false">Service Evaluations</a>
        </li>
    </ul>

    <div class="tab-content" id="branchTabsContent">
        <div class="tab-pane fade show active" id="incident-reports" role="tabpanel" aria-labelledby="incident-reports-tab">
            <h3 class="mt-4">Incident Reports for Your Branch</h3>
            <?php if ($reports_result->num_rows > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Report ID</th>
                            <th>Type of Problem</th>
                            <th>Description</th>
                            <th>Attachment</th>
                            <th>Reported By</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $reports_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['report_id'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['type_problem'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td>
                                    <?php if ($row['Attachments']): ?>
                                        <a href="<?php echo htmlspecialchars($row['Attachments'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank">View Attachment</a>
                                    <?php else: ?>
                                        No Attachment
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No incident reports available for your branch.</p>
            <?php endif; ?>
        </div>

        <div class="tab-pane fade" id="service-evaluations" role="tabpanel" aria-labelledby="service-evaluations-tab">
            <h3 class="mt-4">Service Evaluations</h3>
            <?php if ($evaluations_result->num_rows > 0): ?>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Evaluation ID</th>
                            <th>Rating</th>
                            <th>Feedback</th>
                            <th>Submitted By</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $evaluations_result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['evaluation_id'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['rating'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['feedback'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($row['username'], ENT_QUOTES, 'UTF-8'); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No service evaluations available for your branch.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>