    <?php

    session_start();
    // الاتصال بقاعدة البيانات
    require_once('config/connect.php');

    // التحقق من إرسال البيانات
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // الحصول على القيم من النموذج
        $branch_name = $_POST['branch_name'];
        $city = $_POST['city'];
        $address = $_POST['address'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];

        // استعلام SQL لإدخال البيانات
        $sql = "INSERT INTO branches (branch_name, city, address, phone_number, email) 
                VALUES ('$branch_name', '$city', '$address', '$phone_number', '$email')";

        // تنفيذ الاستعلام والتحقق
    // عملية إضافة الفرع
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = 'Branch added successfully';
        header("Location: dashboardadminsup.php");
        exit();
    } else {
        $_SESSION['message'] = 'An error occurred while adding the branch';
        header("Location: dashboardadminsup.php");
        exit();
    }
        
        // إغلاق الاتصال بقاعدة البيانات
        mysqli_close($conn);
    }
    ?>
