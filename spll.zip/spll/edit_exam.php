<?php
session_start();
include 'config/connect.php';

// تحقق من أن schedule_id تم تمريره عبر URL
if (!isset($_GET['id'])) {
    $_SESSION['message'] = 'Invalid Schedule ID.';
    header("Location: dashboard.php?msg=error");
    exit();
}

// جلب schedule_id من الـ URL
$schedule_id = $_GET['id'];

// استعلام لجلب بيانات الامتحان بناءً على schedule_id
$sql = "SELECT * FROM exam_schedules WHERE schedule_id = '$schedule_id'";
$result = mysqli_query($conn, $sql);

// تحقق من أن السجل موجود
if (mysqli_num_rows($result) == 1) {
    $exam = mysqli_fetch_assoc($result);
} else {
    $_SESSION['message'] = 'Schedule not found.';
    header("Location: dashboard.php?msg=error");
    exit();
}

// إذا تم تقديم النموذج لتحديث البيانات
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $exam_id = $_POST['exam_id'];
    $branch_id = $_POST['branch_id'];
    $room_id = $_POST['room_id'];
    $course_id = $_POST['course_id'];
    $exam_date = $_POST['exam_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $semester = $_POST['semester'];

    // استعلام التحديث
    $update_sql = "UPDATE exam_schedules 
                   SET exam_id = '$exam_id', branch_id = '$branch_id', room_id = '$room_id', 
                       course_id = '$course_id', exam_date = '$exam_date', start_time = '$start_time', 
                       end_time = '$end_time', semester = '$semester'
                   WHERE schedule_id = '$schedule_id'";

    if (mysqli_query($conn, $update_sql)) {
        $_SESSION['message'] = 'Exam updated successfully.';
        header("Location: dashboard.php?msg=success");
    } else {
        $_SESSION['message'] = 'Error updating exam.';
        header("Location: dashboard.php?msg=error");
    }
    exit();
}

// جلب البيانات من الجداول المطلوبة
// جلب الفروع
$branches_sql = "SELECT branch_id, branch_name FROM branches";
$branches_result = mysqli_query($conn, $branches_sql);

// جلب الغرف
$rooms_sql = "SELECT room_id, room_name FROM classrooms WHERE branch_id = '{$exam['branch_id']}'";
$rooms_result = mysqli_query($conn, $rooms_sql);

// جلب الدورات
$courses_sql = "SELECT course_id, course_name FROM courses";
$courses_result = mysqli_query($conn, $courses_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Exam Schedule</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h2>Edit Exam Schedule</h2>

    <?php
    if (isset($_SESSION['message'])) {
        echo "<div class='alert alert-info'>" . $_SESSION['message'] . "</div>";
        unset($_SESSION['message']);
    }
    ?>

    <form method="POST">
        <div class="mb-3">
            <label for="exam_id" class="form-label">Exam ID</label>
            <input type="text" class="form-control" id="exam_id" name="exam_id" value="<?php echo $exam['exam_id']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="branch_id" class="form-label">Branch</label>
            <select class="form-select" id="branch_id" name="branch_id" onchange="fetchRooms(this.value)">
                <option value="">Select Branch</option>
                <?php while ($branch = mysqli_fetch_assoc($branches_result)) { ?>
                    <option value="<?php echo $branch['branch_id']; ?>" <?php echo ($branch['branch_id'] == $exam['branch_id']) ? 'selected' : ''; ?>>
                        <?php echo $branch['branch_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="room_id" class="form-label">Room</label>
            <select class="form-select" id="room_id" name="room_id">
                <option value="">Select Room</option>
                <?php while ($room = mysqli_fetch_assoc($rooms_result)) { ?>
                    <option value="<?php echo $room['room_id']; ?>" <?php echo ($room['room_id'] == $exam['room_id']) ? 'selected' : ''; ?>>
                        <?php echo $room['room_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="course_id" class="form-label">Course</label>
            <select class="form-select" id="course_id" name="course_id">
                <option value="">Select Course</option>
                <?php while ($course = mysqli_fetch_assoc($courses_result)) { ?>
                    <option value="<?php echo $course['course_id']; ?>" <?php echo ($course['course_id'] == $exam['course_id']) ? 'selected' : ''; ?>>
                        <?php echo $course['course_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="exam_date" class="form-label">Exam Date</label>
            <input type="date" class="form-control" id="exam_date" name="exam_date" value="<?php echo $exam['exam_date']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="start_time" class="form-label">Start Time</label>
            <input type="time" class="form-control" id="start_time" name="start_time" value="<?php echo $exam['start_time']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="end_time" class="form-label">End Time</label>
            <input type="time" class="form-control" id="end_time" name="end_time" value="<?php echo $exam['end_time']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="semester" class="form-label">Semester</label>
            <select id="semester" name="semester" class="form-select">
                <option value="1" <?php echo ($exam['semester'] == 1) ? 'selected' : ''; ?>>First Semester</option>
                <option value="2" <?php echo ($exam['semester'] == 2) ? 'selected' : ''; ?>>Second Semester</option>
                <option value="3" <?php echo ($exam['semester'] == 3) ? 'selected' : ''; ?>>Summer Semester</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Exam</button>
    </form>
</div>

<script>
// وظيفة لجلب الغرف بناءً على الفرع المحدد
function fetchRooms(branchId) {
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "fetch_rooms.php?branch_id=" + branchId, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById("room_id").innerHTML = xhr.responseText;
        }
    };
    xhr.send();
}
</script>
</body>
</html>
