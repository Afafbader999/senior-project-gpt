<?php
 
    
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

// Create an instance of PHPMailer
$mail = new PHPMailer();

$mail->isSMTP();
$mail->Host       = 'smtp.gmail.com';                                  
$mail->SMTPAuth   = true;                                  
$mail->Username   = 'e.exam.proctor.website@gmail.com';                          
$mail->Password   = 'ewwq zdyw yugc lskr'; // Use App Password if 2FA is enabled
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Use PHPMailer::ENCRYPTION_STARTTLS if you prefer that
$mail->Port       = 465; // Use 587 for TLS
$mail->setFrom('e.exam.proctor.website@gmail.com', 'E-exam Proctor Support');
$mail->isHTML(false);
$mail->CharSet = "UTF-8";

// Start session and connect to the database
session_start();
require_once('config/connect.php');

// Check session
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect to login page
    exit();
}

// Include language file
include 'lang.php';

// Set language
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

// Retrieve suspended users
$sql = "SELECT username FROM users WHERE user_id = '".$_SESSION['user_id']."'";
$result = $conn->query($sql);
$username = $result->fetch_assoc()['username'];

// Handle account status change
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];

    if ($action === 'activate') {
        $update_sql = "UPDATE users SET account_status = 'Active' WHERE user_id = $user_id";
    } elseif ($action === 'suspend') {
        $update_sql = "UPDATE users SET account_status = 'Suspended' WHERE user_id = $user_id";
    }

    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success dashboard-content'>Account status updated successfully</div>";
        
        // Retrieve email of the user
        $email_sql = "SELECT email FROM users WHERE user_id = $user_id";
        $email_result = $conn->query($email_sql);
        if ($email_result->num_rows > 0) {
            $user_email = $email_result->fetch_assoc()['email'];
            
            // Send email
            $mail->addAddress($user_email);
            $mail->Subject = 'Account Activation';
            $mail->Body    = 'Your account has been activated successfully.';
            
            if ($mail->send()) {
                echo "<div class='alert alert-info dashboard-content'>Activation email sent to $user_email.</div>";
            } else {
                echo "<div class='alert alert-danger dashboard-content'>Failed to send email: " . $mail->ErrorInfo . "</div>";
            }
        }
        
        header("Refresh:3"); // Refresh the page to reflect changes
    } else {
        echo "<div class='alert alert-danger'>Error updating account status: " . $conn->error . "</div>";
    }
}
 

?>

<!DOCTYPE html>
<html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('Security', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
 <style>
      body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }
        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
           text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
            transition: width 0.3s;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .dashboard-header {
            background-color: #000;
            color: white;
            padding: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }
        .dashboard-content {
            margin-top: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }
        .content-section {
            padding: 20px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }
            .dashboard-header, .dashboard-content {
                margin: 0;
            }
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>; /* ضبط محاذاة النص */
        }
        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>
                margin-left: 15px; /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>
                margin-right: 15px; /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }
        .navbar .dropdown-menu a {
            color: black;
        }
 
        .btn-custom {
            background-color: black;
            color: white;
        }
        form {
        border: 1px solid #ced4da; /* Light gray border */
        padding: 20px; /* Space inside the border */
        border-radius: 5px; /* Rounded corners */
        background-color: #fff; /* White background */
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Optional: slight shadow for depth */
    }
    .nav-link:hover {
            background-color: #0000;
            /* لون أزرق غامق عند التحويم */
            color: #ffffff;
            /* تأكيد على بقاء النص باللون الأبيض */
        }
        .nav-link{
            color:#ffffff;
        }

 
 </style>
  
</head>
<body>

    <!-- Navbar للجوال والعرض الكبير -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="dashboardadminsup.php"><?php echo getTranslation('dashboard', $lang, $translations); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link d-lg-none" href="Securityadminsup.php"><?php echo getTranslation('Security', $lang, $translations); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-lg-none" href="ordersby.php"><?php echo getTranslation('reports', $lang, $translations); ?></a>
                    </li>
                    <!-- <li class="nav-item">
                        <a class="nav-link d-lg-none" href="#"><?php echo getTranslation('settings', $lang, $translations); ?></a>
                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link d-lg-none" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <!-- قائمة اللغة -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo ($lang == 'ar') ? 'العربية' : 'English'; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                            <li><a class="dropdown-item" href="?lang=en">English</a></li>
                            <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                        </ul>
                    </li>
                    <!-- اسم المستخدم -->
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo $username; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><?php echo getTranslation('profile', $lang, $translations); ?></a></li>
                            <li><a class="dropdown-item" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Sidebar لسطح المكتب -->
    <div class="sidebar">
        <h3 class="text-center"><?php echo getTranslation('dashboard', $lang, $translations); ?></h3>
        <a href="dashboardadminsup.php"><?php echo getTranslation('dashboard', $lang, $translations); ?></a>
        <a href="Securityadminsup.php"><?php echo getTranslation('Security', $lang, $translations); ?></a>
        <!-- <a href="#"><?php echo getTranslation('reports', $lang, $translations); ?></a>
        <a href="#"><?php echo getTranslation('settings', $lang, $translations); ?></a> -->
        <a href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a>
    </div>

    <!-- Header -->
 

    <!-- Content -->
    <div class="container dashboard-content">
        <div class="row">
            <div class="col-md-9 content-section">


            
        <!-- Nav Tabs -->
        <ul class="nav nav-tabs p-1 text-white shadow bg-dark rounded" id="myTab" role="tablist" style="border-width: 4px; border-style: solid;">
            <li class="nav-item" role="presentation">
                <a class="nav-link active" id="Suspended-tab" data-bs-toggle="tab" href="#Suspended" role="tab" aria-controls="Suspended" aria-selected="true">Suspended</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="admin-tab" data-bs-toggle="tab" href="#admin" role="tab" aria-controls="admin" aria-selected="false">Add admin</a>
            </li>
            <!-- <li class="nav-item" role="presentation">
                <a class="nav-link" id="courses-tab" data-bs-toggle="tab" href="#courses" role="tab" aria-controls="courses" aria-selected="false">empty</a>
            </li>
            <li class="nav-item" role="presentation">
                <a class="nav-link" id="exam_schedules-tab" data-bs-toggle="tab" href="#exam_schedules" role="tab" aria-controls="exam_schedules" aria-selected="false">empty2</a>
            </li> -->
        </ul>

        <div class="tab-content mt-4" id="myTabContent">
            <!-- Suspended Form -->
            <div class="tab-pane fade show active" id="Suspended" role="tabpanel" aria-labelledby="Suspended-tab">
                <h2>Suspended Users</h2>

                <!-- Users Table -->
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
if (isset($_SESSION['branch_id'])) {
    $branch_id = $_SESSION['branch_id'];

    // الاستعلام عن المستخدمين الذين تم تعليق حساباتهم في فرع معين
    $query = "SELECT * FROM users WHERE account_status = 'Suspended'";
    $result = mysqli_query($conn, $query);
}

if ($result->num_rows > 0): ?>
    <?php while ($user = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $user['user_id']; ?></td>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
            <td>
                <!-- You can add actions specific to suspended users here -->
                <form method="post" action="" style="display:inline;">
                    <input type="hidden" name="user_id" value="<?php echo $user['user_id']; ?>">
                    <button type="submit" name="action" value="activate" class="btn btn-custom">Activate</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr>
        <td colspan="4">No suspended users found.</td>
    </tr>
<?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
                  
         </div>
            </div>
            </div>

            <div class="tab-content mt-4" id="myTabContent">
            <!-- Suspended Form -->
            <div class="tab-pane fade" id="admin" role="tabpanel" aria-labelledby="admin-tab">
            <?php
// Connect to the database
require_once('config/connect.php');

// Fetch branches from the database
$branchesQuery = "SELECT branch_id, branch_name FROM branches ";
$result = $conn->query($branchesQuery);
?>

<h2 class="text-center">Add New Admin User</h2>
<form method="POST" action="add_admin.php">
    <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" required>
    </div>
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
    </div>
    <div class="form-group">
        <label for="confirmPassword">Confirm Password</label>
        <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
    </div>
    <div class="form-group">
        <label for="role">User Role</label>
        <select class="form-control" id="role" name="role" required>
            <option value="Admin">Admin</option>
        </select>
    </div>
    <div class="form-group">
        <label for="branch_id">Branch</label>
        <select class="form-control" id="branch_id" name="branch_id" required>
            <option value="">Select a Branch</option>
            <?php
            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo '<option value="' . $row['branch_id'] . '">' . $row['branch_name'] . '</option>';
                }
            } else {
                echo '<option value="">No branches available</option>';
            }
            ?>
        </select>
    </div>
    <div class="form-group">
        <label for="gender">Gender</label>
        <select class="form-control" id="gender" name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            
        </select>
    </div>
    <br>
    <button type="submit" class="btn btn-primary">Add</button>
</form>

</div>
</div>
</div>


</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</html>