
<!-- 
<header class="bg-navbar navbar-dark">
    <nav class="navbar navbar-expand-lg text-light">
        <div class="container-fluid">
            <!-- Brand -->
            <a class="navbar-brand text-light text-uppercase" href="index.php"><?php echo getTranslation('brand', $lang, $translations); ?></a>
            <!-- Toggler for mobile -->
            <button class="navbar-toggler text-light" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <!-- Check if session variables are set -->
                    <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
                        <!-- Show profile and exam assignments links in a dropdown -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo $_SESSION['username']; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="profile.php"><?php echo getTranslation('profile', $lang, $translations); ?></a></li>
                                <li><a class="dropdown-item" href="exam_assignments.php"><?php echo getTranslation('exam_assignments', $lang, $translations); ?></a></li>
                                <li><a class="dropdown-item" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a></li>
                            </ul>
                        </li>
                    <?php else: ?>
                        <!-- Hide index and register links if on index.php -->
                        <?php if (basename($_SERVER['PHP_SELF']) != "index.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="index.php"><?php echo getTranslation('index', $lang, $translations); ?></a></li>
                            <?php if (basename($_SERVER['PHP_SELF']) != "register.php"): ?>
                                <li class="nav-item"><a class="nav-link text-light" href="register.php"><?php echo getTranslation('signup', $lang, $translations); ?></a></li>
                            <?php endif; ?>
                        <?php endif; ?>

                        <!-- Hide login link if on login.php -->
                        <?php if (basename($_SERVER['PHP_SELF']) != "login.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="login.php"><?php echo getTranslation('login', $lang, $translations); ?></a></li>
                        <?php endif; ?>

                        <!-- Hide about link if on about.php -->
                        <?php if (basename($_SERVER['PHP_SELF']) != "about.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="about.php"><?php echo getTranslation('about', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Language Dropdown -->
            <ul class="navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo ($lang == 'ar') ? 'العربية' : 'English'; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                        <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header> -->
