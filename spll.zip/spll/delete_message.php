<?php
//delete_message.php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تأكيد أن المستخدم مسجل الدخول
    if (!isset($_SESSION['user_id'])) {
        exit(); // الخروج بدون عرض أي رسالة
    }

    $chat_id = $_POST['chat_id'];
    $user_id = $_SESSION['user_id'];

    // حذف الرسالة من قاعدة البيانات
    $stmt = $conn->prepare("DELETE FROM chats WHERE chat_id = ? AND sender_user_id = ?");
    $stmt->bind_param("ii", $chat_id, $user_id);
    $stmt->execute();
    $stmt->close();

    exit(); // الخروج بدون عرض أي رسالة
} else {
    exit(); // الخروج بدون عرض أي رسالة
}

