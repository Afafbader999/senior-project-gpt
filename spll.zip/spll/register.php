<?php
session_start();

// تضمين ملف الترجمات
include 'lang.php';
include 'config/connect.php';

// تعيين اللغة الافتراضية
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('signup', $lang, $translations); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        .form-container {
            margin-bottom: 50px;
        }
        footer {
            margin-top: 30px;
        }
    </style>
</head>
<body dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
<?php include 'config/header.php'; ?>
    <div class="container mt-3">
        <div class="form-container mt-3" dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
            <h2 class="text-center"><?php echo getTranslation('signup', $lang, $translations); ?></h2>
            <form id="signupForm" action="signup.php" method="POST" onsubmit="return validateForm()">

                <!-- حقل اختيار الفرع -->
                <div class="form-group">
                    <label for="branch_id" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('branch', $lang, $translations); ?></label>
                    <select name="branch_id" id="branch_id" class="form-control" required>
                        <?php
                        $result = mysqli_query($conn, "SELECT branch_id, branch_name FROM branches WHERE lang = '$lang'"); 
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value=\"{$row['branch_id']}\">{$row['branch_name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- حقل اسم المستخدم -->
                <div class="form-group">
                    <label for="username" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('username', $lang, $translations); ?></label>
                    <input type="text" name="username" id="username" class="form-control" required>
                </div>

                <!-- حقل البريد الإلكتروني -->
                <div class="form-group">
                    <label for="email" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('email', $lang, $translations); ?></label>
                    <input type="email" name="email" id="email" class="form-control" required>
                    <span id="emailError" class="text-danger"></span>
                </div>

                <!-- حقل اختيار الجنس -->
                <div class="form-group">
        <label for="gender">Gender</label>
        <select class="form-control" id="gender" name="gender" required>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            
        </select>
        </div>

                <!-- حقل كلمة المرور -->
                <div class="form-group">
                    <label for="password" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('password', $lang, $translations); ?></label>
                    <div class="input-group">
                        <input type="password" name="password" id="password" class="form-control" required>
                        <div class="input-group-append">
                            <span class="input-group-text" id="togglePassword">
                                <i class="fas fa-eye"></i>
                            </span>
                        </div>
                    </div>
                    <span id="passwordError" class="text-danger"></span>
                </div>

                <!-- حقل تأكيد كلمة المرور -->
                <div class="form-group">
                    <label for="confirmPassword" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('confirmPassword', $lang, $translations); ?></label>
                    <input type="password" name="confirmPassword" id="confirmPassword" class="form-control" required>
                    <span id="confirmPasswordError" class="text-danger"></span>
                </div>

                <!-- حقل اختيار دور المستخدم -->
                <div class="form-group">
                    <label for="role" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('role', $lang, $translations); ?></label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="Proctor"><?php echo getTranslation('proctor', $lang, $translations); ?></option>
                        <option value="IT-Support"><?php echo getTranslation('it_support', $lang, $translations); ?></option>
                    </select>
                </div>

                <!-- زر إرسال النموذج -->
                <button type="submit" class="btn btn-primary btn-block"><?php echo getTranslation('signup', $lang, $translations); ?></button>
            </form>

            <!-- سكريبت التحقق -->
            <script>
            function validateForm() {
                var email = document.getElementById("email").value;
                var password = document.getElementById("password").value;
                var confirmPassword = document.getElementById("confirmPassword").value;

                document.getElementById("emailError").textContent = "";
                document.getElementById("passwordError").textContent = "";
                document.getElementById("confirmPasswordError").textContent = "";

                var emailPattern = /^[a-zA-Z0-9._%+-]+@seu\.edu\.sa$/;
                if (!emailPattern.test(email)) {
                    document.getElementById("emailError").textContent = "Please enter a valid @seu.edu.sa email address.";
                    return false;
                }

                if (password !== confirmPassword) {
                    document.getElementById("confirmPasswordError").textContent = "Passwords do not match. Please re-enter.";
                    return false;
                }

                var upperCasePattern = /[A-Z]/;
                if (!upperCasePattern.test(password)) {
                    document.getElementById("passwordError").textContent = "Password must contain at least one uppercase letter.";
                    return false;
                }

                var lowerCasePattern = /[a-z]/;
                if (!lowerCasePattern.test(password)) {
                    document.getElementById("passwordError").textContent = "Password must contain at least one lowercase letter.";
                    return false;
                }

                var numberPattern = /[0-9]/;
                if (!numberPattern.test(password)) {
                    document.getElementById("passwordError").textContent = "Password must contain at least one number.";
                    return false;
                }

                var specialCharPattern = /[\W_]/;
                if (!specialCharPattern.test(password)) {
                    document.getElementById("passwordError").textContent = "Password must contain at least one special character.";
                    return false;
                }

                return true;
            }

            document.getElementById("togglePassword").addEventListener("click", function() {
                var passwordField = document.getElementById("password");
                var confirmPasswordField = document.getElementById("confirmPassword");
                var icon = this.querySelector("i");

                if (passwordField.type === "password") {
                    passwordField.type = "text";
                    confirmPasswordField.type = "text";
                    icon.classList.remove("fa-eye");
                    icon.classList.add("fa-eye-slash");
                } else {
                    passwordField.type = "password";
                    confirmPasswordField.type = "password";
                    icon.classList.remove("fa-eye-slash");
                    icon.classList.add("fa-eye");
                }
            });
            </script>

            <div class="text-center mt-3">
                <p><?php echo getTranslation('already_have_account', $lang, $translations); ?> <a href="login.php"><?php echo getTranslation('login', $lang, $translations); ?></a></p>
            </div>

            <div class="text-center mt-3">
                <a href="?lang=ar"><?php echo getTranslation('arabic', $lang, $translations); ?></a> | <a href="?lang=en"><?php echo getTranslation('english', $lang, $translations); ?></a>
            </div>
        </div>
    </div>

<?php include 'config/footer.php'; ?>
</body>
</html>