<?php
// بدء الجلسة
session_start();

// الاتصال بقاعدة البيانات
require_once('config/connect.php');

// التحقق من أن معرف الدورة قد تم تمريره عبر الرابط
if (isset($_GET['id'])) {
    $course_id = $_GET['id'];

    // جلب بيانات الدورة من قاعدة البيانات
    $sql = "SELECT * FROM courses WHERE course_id = $course_id";
    $result = mysqli_query($conn, $sql);

    // التحقق من وجود الدورة
    if (mysqli_num_rows($result) > 0) {
        $course = mysqli_fetch_assoc($result);
    } else {
        $_SESSION['message'] = 'Course not found.';
        header("Location: dashboard.php");
        exit();
    }
} else {
    $_SESSION['message'] = 'No course ID specified.';
    header("Location: dashboard.php");
    exit();
}

// التحقق من إرسال النموذج لتحديث البيانات
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];

    // استعلام تحديث بيانات الدورة
    $sql = "UPDATE courses SET course_name = '$course_name' ,course_code='$course_code' WHERE course_id = $course_id";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['message'] = 'Course updated successfully.';
        header("Location: dashboard.php?msg=success");
        exit();
    } else {
        $_SESSION['message'] = 'An error occurred while updating the course: ' . mysqli_error($conn);
        header("Location: dashboard.php?msg=error");
        exit();
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h2>Edit Course</h2>

    <!-- نموذج تعديل بيانات الدورة -->
    <form action="edit_course.php?id=<?php echo $course_id; ?>" method="POST">
    <div class="mb-3">
            <label for="course_code" class="form-label">Course code</label>
            <input type="text" class="form-control" id="course_code" name="course_code" value="<?php echo $course['course_code']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="course_name" class="form-label">Course Name</label>
            <input type="text" class="form-control" id="course_name" name="course_name" value="<?php echo $course['course_name']; ?>" required>
        </div>

        <button type="submit" class="btn btn-secondary">Update Course</button>
    </form>
</div>

</body>
</html>
