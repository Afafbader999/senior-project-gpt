<?php
session_start();
include 'config/connect.php'; // Connect to the database

// Check if session ID is provided
if (isset($_GET['session_id'])) {
    $session_id = $_GET['session_id'];

    // Prepare the SQL statement to prevent SQL injection
    $query = "
        SELECT 
            c.chat_id,
            c.message_content, 
            c.sent_at, 
            u.username, 
            c.sender_user_id
        FROM 
            chats c
        JOIN 
            users u ON c.sender_user_id = u.user_id
        WHERE 
            c.session_id = ?
        ORDER BY 
            c.sent_at ASC
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $session_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $message_class = ($row['sender_user_id'] == $_SESSION['user_id']) ? 'message-sent' : 'message-received';
            echo '<div class="message ' . $message_class . '">';
            echo '<strong>' . htmlspecialchars($row['username']) . ':</strong> ';
            echo htmlspecialchars($row['message_content']);
            echo '<br><small>' . htmlspecialchars($row['sent_at']) . '</small>';

            // Add edit and delete options for the sender
            if ($row['sender_user_id'] == $_SESSION['user_id']) {
                echo '<br>';
                echo '<button class="btn btn-warning btn-sm edit-message" data-chat-id="' . $row['chat_id'] . '">Edit</button>';
                echo '<button class="btn btn-danger btn-sm delete-message" data-chat-id="' . $row['chat_id'] . '">Delete</button>';
            } else {
                // Reply button for messages from the other user
                echo '<button class="btn btn-info btn-sm reply-message" data-chat-id="' . $row['chat_id'] . '">Reply</button>';
            }

            echo '</div>';
        }
    } else {
        echo 'No messages yet.';
    }

    $stmt->close(); // Close the prepared statement
} else {
    echo 'Session ID not provided.';
}
?>