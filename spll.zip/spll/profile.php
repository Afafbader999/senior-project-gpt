<?php
session_start();
require_once('config/connect.php');
require_once('lang.php');

// Verify session and redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch user data from the database
$user_id = $_SESSION['user_id'];
$sql = "SELECT role, username, email, password_hash, branch_id FROM users WHERE user_id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    $role = $user['role']; 
} else {
    echo "User not found";
    exit();
}

// Variable to hold update messages
$updateMessage = "";

// Handle profile update (username, email, branch)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['username']) && isset($_POST['email']) && isset($_POST['branch_id'])) {
    $new_username = $conn->real_escape_string($_POST['username']);
    $new_email = $conn->real_escape_string($_POST['email']);
    $new_branch_id = $conn->real_escape_string($_POST['branch_id']);

    // Update username, email, and branch in the database
    $update_sql = "UPDATE users SET username = '$new_username', email = '$new_email', branch_id = '$new_branch_id' WHERE user_id = $user_id";
    if ($conn->query($update_sql) === TRUE) {
        $updateMessage = "Profile updated successfully";
        header("Refresh:0"); // Refresh page to reflect updated profile
    } else {
        $updateMessage = "Error updating profile: " . $conn->error;
    }
}

// Handle password update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['current-password']) && isset($_POST['new-password'])) {
    $current_password = $_POST['current-password'];
    $new_password = $_POST['new-password'];

    // Verify current password
    if (password_verify($current_password, $user['password_hash'])) {
        // Hash the new password
        $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);

        // Update the password in the database
        $update_password_sql = "UPDATE users SET password_hash = '$new_password_hashed' WHERE user_id = $user_id";
        if ($conn->query($update_password_sql) === TRUE) {
            $updateMessage = "Password updated successfully";
        } else {
            $updateMessage = "Error updating password: " . $conn->error;
        }
    } else {
        $updateMessage = "Current password is incorrect";
    }
}

// Determine the language and set the direction
$lang = isset($_GET['lang']) && $_GET['lang'] == 'ar' ? 'ar' : 'en';
$dir = $lang == 'ar' ? 'rtl' : 'ltr';

?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('profile_title', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        .editable {
            pointer-events: none;
            opacity: 0.6;
        }
        .btn-btncustomer {
            background-color: #000;
            color: #fff;
        }
        .btn-btncustomer:hover {
            background-color: #333;
            color: #fff;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="#"><?php echo getTranslation('brand', $lang, $translations); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if ($role == 'superadmin'): ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboardadminsup.php"><?php echo getTranslation('dashboard', $lang, $translations); ?></a>
                        </li>
                    <?php elseif ($role == 'Admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="dashboard.php"><?php echo getTranslation('dashboard', $lang, $translations); ?></a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="index.php"><?php echo getTranslation('index', $lang, $translations); ?></a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="?lang=en">English</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="?lang=ar">العربية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#"><?php echo htmlspecialchars($role); ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4"><?php echo getTranslation('profile_title', $lang, $translations); ?></h1>

        <?php if ($updateMessage): ?>
            <div class="alert alert-info"><?php echo $updateMessage; ?></div>
        <?php endif; ?>
        
        <!-- Profile Form -->
        <form method="post" action="">
            <!-- User Name -->
            <div class="mb-3">
                <label for="username" class="form-label"><?php echo getTranslation('username', $lang, $translations); ?></label>
                <input type="text" class="form-control editable" id="username" name="username" 
                       value="<?php echo htmlspecialchars($user['username']); ?>" required disabled>
            </div>

            <!-- Email -->
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo getTranslation('email', $lang, $translations); ?></label>
                <input type="email" class="form-control editable" id="email" name="email" 
                       value="<?php echo htmlspecialchars($user['email']); ?>" required disabled>
            </div>

            <!-- Branch -->
            <div class="mb-3">
                <label for="branch_id" class="form-label"><?php echo getTranslation('branch', $lang, $translations); ?></label>
                <select class="form-control editable" id="branch_id" name="branch_id" required disabled>
                    <?php
                    $branch_result = mysqli_query($conn, "SELECT branch_id, branch_name FROM branches WHERE lang = '$lang'");
                    while ($row = mysqli_fetch_assoc($branch_result)) {
                        $selected = ($user['branch_id'] == $row['branch_id']) ? 'selected' : '';
                        echo "<option value=\"{$row['branch_id']}\" $selected>{$row['branch_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <!-- Control Buttons -->
            <button type="button" class="btn btn-btncustomer" id="edit-btn"><?php echo getTranslation('edit_button', $lang, $translations); ?></button>
            <button type="submit" class="btn btn-btncustomer d-none" id="save-btn"><?php echo getTranslation('save_button', $lang, $translations); ?></button>
            <button type="button" class="btn btn-btncustomer" id="change-password-btn"><?php echo getTranslation('change_password', $lang, $translations); ?></button>
        </form>
    </div>

    <!-- Password Modal -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="changePasswordModalLabel"><?php echo getTranslation('change_password', $lang, $translations); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="change-password-form" method="post" action="">
                        <div class="mb-3">
                            <label for="current-password" class="form-label"><?php echo getTranslation('current_password', $lang, $translations); ?></label>
                            <input type="password" class="form-control" id="current-password" name="current-password" required>
                        </div>
                        <div class="mb-3">
                            <label for="new-password" class="form-label"><?php echo getTranslation('new_password', $lang, $translations); ?></label>
                            <input type="password" class="form-control" id="new-password" name="new-password" required>
                        </div>
                        <button type="submit" class="btn btn-primary p-3"><?php echo getTranslation('save_password', $lang, $translations); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const editBtn = document.getElementById('edit-btn');
        const saveBtn = document.getElementById('save-btn');
        const changePasswordBtn = document.getElementById('change-password-btn');
        const editableFields = document.querySelectorAll('.editable');
        const changePasswordForm = document.getElementById('change-password-form');

        // Enable form fields on edit button click
        editBtn.addEventListener('click', function () {
            editableFields.forEach(field => {
                field.disabled = false;
                field.classList.remove('editable');
            });
            editBtn.classList.add('d-none');
            saveBtn.classList.remove('d-none');
        });

        // Show password modal
        changePasswordBtn.addEventListener('click', function () {
            const modal = new bootstrap.Modal(document.getElementById('changePasswordModal'));
            modal.show();
        });

        // Validate password on form submission
        changePasswordForm.addEventListener('submit', function (event) {
            const newPassword = document.getElementById('new-password').value;

            // Regular expression for password validation
            const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

            if (!passwordPattern.test(newPassword)) {
                event.preventDefault(); // Prevent form submission
                alert("Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.");
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
<br><br>
    
</body>
</html>