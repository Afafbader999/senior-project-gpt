<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// التأكد أن المستخدم هو مراقب
/* if ($role !== 'Proctor') {
    echo "You do not have permission to submit a help request.";
    exit();
} */
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('brand', $lang, $translations); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <!-- Include jQuery -->
    <style>
       footer {
    height: 80px;
    background-color: #ffffff; /* Set the footer background color */
    padding: 10px; /* Padding inside the footer */
    text-align: center; /* Center the footer text */
    color: white; /* Change text color to white */
}
html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1; /* This allows the container to grow and fill the available space */
}
.btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }
        .btn-primary:hover {
    background-color: #000; /* Keep background color black on hover */
    color: #fff; /* Keep text color white on hover */
    opacity: 0.8; /* Optional: Change opacity on hover for effect */
}
    </style>
</head>
<body>
    
<?php
include 'config/header.php';
include 'config/connect.php'; // Include database connection
 

 

 

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = isset($_POST['rating']) ? intval($_POST['rating']) : null;
    $feedback = isset($_POST['feedback']) ? trim($_POST['feedback']) : null;

    // Validation
    if ($rating < 1 || $rating > 5) {
        echo '<div class="alert alert-danger">Invalid rating. Please provide a value between 1 and 5.</div>';
    } else {
        // Insert evaluation into the database
        $query = "INSERT INTO service_evaluations (user_id, rating, feedback, branch_id) 
                  VALUES ($user_id, $rating, '$feedback', $branch_id)";
        if (mysqli_query($conn, $query)) {
            echo '<div class="alert alert-success">Thank you for your evaluation!</div>';
        } else {
            echo '<div class="alert alert-danger">Error submitting your evaluation. Please try again.</div>';
        }
    }
}
?>

<div class="container mt-5">
    <h2>Website Evaluation</h2>
    <form method="POST" action="">
        <div class="form-group">
            <label for="rating">Rating (1-5)</label>
            <select class="form-control" id="rating" name="rating" required>
                <option value="">Select</option>
                <option value="1">1 - Very Poor</option>
                <option value="2">2 - Poor</option>
                <option value="3">3 - Average</option>
                <option value="4">4 - Good</option>
                <option value="5">5 - Excellent</option>
            </select>
        </div>
        <div class="form-group">
            <label for="feedback">Feedback  (If you have any issues on the site, please let us know so we can improve it!)</label>
            <textarea class="form-control" id="feedback" name="feedback" rows="4"></textarea>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Submit Evaluation</button>
    </form>
</div>

 

<br>
<br>
<?php include 'config/footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#helpRequestForm').on('submit', function(event) {
            event.preventDefault(); // منع إعادة تحميل الصفحة
            
            $.ajax({
                url: 'submit_help_request.php', // صفحة معالجة الطلب
                type: 'POST',
                data: $(this).serialize(), // تحويل بيانات النموذج إلى سلسلة
                success: function(response) {
                    $('#response_message').html(response); // عرض الاستجابة
                },
                error: function() {
                    $('#response_message').html('<div class="alert alert-danger">Error submitting request.</div>');
                }
            });
        });
    });
</script>

</body>
</html>
