<?php
session_start();
// الاتصال بقاعدة البيانات
require_once('config/connect.php');

// التحقق من إرسال البيانات
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على القيم من النموذج
    $room_name = mysqli_real_escape_string($conn, $_POST['room_name']);
    $building_name = mysqli_real_escape_string($conn, $_POST['building_name']);
    $capacity = (int)$_POST['capacity']; // تحويل القيمة إلى عدد صحيح
    $floor = (int)$_POST['floor']; // تحويل القيمة إلى عدد صحيح
    $room_type = mysqli_real_escape_string($conn, $_POST['room_type']);
    $branch_id = (int)$_POST['branch_id']; // تحويل القيمة إلى عدد صحيح

    // استعلام SQL لإدخال البيانات
    $sql = "INSERT INTO classrooms (room_name, building_name, capacity, floor, room_type, branch_id) 
            VALUES ('$room_name', '$building_name', '$capacity', '$floor', '$room_type', '$branch_id')";

    // تنفيذ الاستعلام والتحقق
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = 'Classroom added successfully.';
        header("Location: dashboard.php");
        exit();
    } else {
        $_SESSION['message'] = 'An error occurred while adding the classroom.';
        header("Location: dashboard.php");
        exit();
    }
    
    // إغلاق الاتصال بقاعدة البيانات
    mysqli_close($conn);
}
?>
