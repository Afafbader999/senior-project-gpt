<?php
session_start();

// Check if the reset code is set in the session
if (!isset($_SESSION['reset_code'])) {
    echo "<div class='alert alert-danger'>Reset code not found.</div>";
    exit;
}

$reset_code = $_SESSION['reset_code'];
$email = isset($_SESSION['email']);
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['verification_code'])) {
        $verification_code = $_POST['verification_code'];

        // Compare the verification code with the reset code
        if ($verification_code == $reset_code) {
            // Code matches, allow the user to reset their password
            header("Location: reset_password.php");
            exit;
        } else {
            $error_message = "Invalid verification code.";
        }
    } else {
        $error_message = "Verification code is required.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Reset Code</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-black {
            background-color: #000000; /* لون الزر الأسود */
            color: #ffffff;
        }
        .btn-black:hover {
            background-color: #444444;
            color: #ffffff; /* لون أسود فاتح عند التمرير */
        }
    </style>
</head>
<body class="bg-light d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h2 class="text-center mb-4">Verify Reset Code</h2>
                        <p class="text-center mb-4">An email with a verification code has been sent to your email address. Please enter the code below:</p>
                        <?php if (isset($_SESSION['email'])): ?>
                            <p class="text-center mb-4"><strong>Email:</strong> <?php echo $_SESSION['email']; ?></p>
                        <?php endif; ?>
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <?php if (!empty($error_message)): ?>
                                <div class="alert alert-danger"><?php echo $error_message; ?></div>
                            <?php endif; ?>
                            <div class="form-group">
                                <label for="verification_code">Verification Code:</label>
                                <input type="text" id="verification_code" name="verification_code" class="form-control" required>
                            </div>
                            <button type="submit" class="btn btn-black btn-block">Verify Code</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>