<?php
session_start();
include 'config/connect.php';

if (!isset($_GET['session_link'])) {
    echo "Invalid session link.";
    exit();
}

$session_link = $_GET['session_link'];
$query = "SELECT * FROM sessions WHERE session_link = ? AND is_sharing = 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $session_link);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Session not found or inactive.";
    exit();
}

$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Session View</title>
</head>
<body>
    <h1>Proctor Screen</h1>
    <p>Proctor ID: <?php echo $row['proctor_id']; ?></p>
    <p>Session ID: <?php echo $row['session_id']; ?></p>
    <video id="screenVideo" autoplay></video>

    <script>
        // هذا يعتمد على مشاركة الشاشة التي يتم بثها باستخدام WebRTC أو خدمات أخرى.
    </script>
</body>
</html>
