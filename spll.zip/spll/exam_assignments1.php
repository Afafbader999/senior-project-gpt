<?php
session_start();
// تضمين ملف الترجمات
include 'lang.php';

// تعيين اللغة الافتراضية
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation(' ', $lang, $translations); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }
        /* إضافة قواعد CSS لضبط المحاذاة بناءً على اتجاه الكتابة */
body[dir="rtl"] {
    text-align: right;
}

body[dir="ltr"] {
    text-align: left;
}

header, footer {
    text-align: center;
}

ul {
    list-style-type: circle;
    margin-left: 20px;
}

body[dir="rtl"] ul {
    margin-left: 0;
    margin-right: 20px;
}

        header {
            background-color: #000;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        header a {
            color: #4ca8f8;
            text-decoration: none;
        }
        header a:hover {
            text-decoration: underline;
        }
        section {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #ffffff;
        }
        h2 {
            color: #054e9d;
        }
        ul {
            list-style-type: circle;
            margin-left: 20px;
        }
        .team-member {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .team-member img {
            border-radius: 50%;
            width: 50px;
            height: 50px;
            margin-right: 15px;
        }
        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
        }


        .exam-box {
    border: 1px solid #ccc;
    padding: 20px;
    margin-bottom: 20px;
    background-color: #f9f9f9;
    border-radius: 8px;
}

.exam-box h3 {
    margin-top: 0;
}

.exam-box button {
    margin-top: 10px;
}
.exam-container {
    display: flex;
    flex-wrap: wrap; /* Allows wrapping of items */
    justify-content: space-between; /* Distributes space evenly */
    margin: 20px; /* Margin around the container */
}

.exam-details {
    background-color: #f8f9fa; /* Light background for exam details */
    border: 1px solid #ddd; /* Border around each exam detail */
    border-radius: 5px; /* Rounded corners */
    padding: 15px; /* Padding inside each detail */
    margin: 10px; /* Margin between details */
    flex: 1 1 calc(30% - 20px); /* Responsive width, adjusts to 3 items per row */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

.exam-details h3 {
    margin: 0 0 10px; /* Margin for the heading */
}

.btn {
    margin-top: 10px; /* Space above the button */
    background-color: #000;
}

    </style>
</head>
<body dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">


    <?php include 'config/header.php'; ?>
    <?php 
require_once('config/connect.php');

// Assuming branch_id is obtained from session or user input
$branch_id = $_SESSION['branch_id'];
$porit_id = $_SESSION['user_id']; // Retrieve porit_id from session
$role = $_SESSION['role']; // Retrieve role from session 

// Prepare the query
$query = "SELECT es.exam_id, c.course_name, cr.room_name, cr.floor, es.exam_date, es.start_time, es.end_time, es.course_id, es.room_id
          FROM exam_schedules es 
          JOIN courses c ON es.course_id = c.course_id 
          JOIN classrooms cr ON es.room_id = cr.room_id 
          WHERE es.branch_id = $branch_id";

// Execute the query
$result = $conn->query($query);

// Display results in a div
if ($result->num_rows > 0) {
    echo '<div class="exam-container">'; // Start of the container for exams
    while ($row = $result->fetch_assoc()) {
        echo '<div class="exam-details">';
        echo '<h3>Course: ' . $row['course_name'] . '</h3>';
        echo '<p>Room: ' . $row['room_name'] . ' (Floor: ' . $row['floor'] . ')</p>';
        echo '<p>Exam Date: ' . $row['exam_date'] . '</p>';
        echo '<p>Start Time: ' . $row['start_time'] . '</p>';
        echo '<p>End Time: ' . $row['end_time'] . '</p>';
        
        // Add button for adding assignments using AJAX
        echo '<button class="btn btn-primary" 
                    onclick="addToMyTasks(' . $row['exam_id'] . ', ' . $porit_id . ', \'' . $role . '\', ' . $branch_id . ', ' . $row['room_id'] . ', ' . $row['course_id'] . ', \'' . $row['exam_date'] . '\', \'' . $row['start_time'] . '\', \'' . $row['end_time'] . '\')">Add to My Tasks</button>';
        
        echo '</div>'; // End of exam-details div
    }
    echo '</div>'; // End of the container
} else {
    echo '<p>No exams found for this branch.</p>';
}

$conn->close();
?>

<script>
function addToMyTasks(examId, poritId, role, branchId, roomId, courseId, examDate, startTime, endTime) {
    // Make an AJAX request to add the exam to the assignments table
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "add_assignment.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            alert("Exam added to your tasks!");
        }
    };
    xhr.send("exam_id=" + examId + "&porit_id=" + poritId + "&role=" + encodeURIComponent(role) + "&branch_id=" + branchId + "&room_id=" + roomId + "&course_id=" + courseId + "&assignment_date=" + examDate + "&start_time=" + startTime + "&end_time=" + endTime);
}
</script>




    <?php include 'config/footer.php'; ?>

</body>
</html>
