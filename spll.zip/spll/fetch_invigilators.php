<?php
/*
 // Include the database connection file
session_start();
require_once('config/connect.php');
header('Content-Type: application/json');
// Get the branch_id from the session
$branch_id = isset($_SESSION['branch_id']) ? mysqli_real_escape_string($conn, $_SESSION['branch_id']) : null;

if ($branch_id === null) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}

// Query exam schedules for the logged-in user's branch
// Query exam schedules for the logged-in user's branch
$query = "
SELECT es.*, c.course_name, r.room_name
FROM exam_schedules es
JOIN courses c ON es.course_id = c.course_id
JOIN classrooms r ON es.room_id = r.room_id
WHERE es.branch_id = '$branch_id'";

$result = mysqli_query($conn, $query);
if (!$result) {
    die("Query Failed: " . mysqli_error($conn)); // Debugging line
}

if (mysqli_num_rows($result) === 0) {
    echo json_encode(["error" => "No exam schedules found for this branch."]);
    exit();
}

// Fetch invigilators (Proctors) for the branch from the users table
$invigilators_query = "SELECT user_id, username FROM users WHERE branch_id = '$branch_id' AND role = 'Proctor'";
$invigilators_result = mysqli_query($conn, $invigilators_query);

// Store invigilators in an array
$invigilators = [];
while ($row = mysqli_fetch_assoc($invigilators_result)) {
    $invigilators[$row['user_id']] = $row['username']; // Store user_id and name
}

// Check if there are enough invigilators
if (count($invigilators) < 2) {
    echo json_encode(["error" => "Not enough invigilators available for this branch."]);
    exit();
}

// Assign invigilators randomly to exam schedules
$assigned_invigilators = [];
while ($row = mysqli_fetch_assoc($result)) {
    $invigilator_ids = array_keys($invigilators);
    shuffle($invigilator_ids); // Shuffle to get random assignment
    $assigned_invigilators[] = [
        'exam_id' => $row['exam_id'], // Add exam_id
        'course_name' => $row['course_name'],
        'room_name' => $row['room_name'],
        'exam_date' => $row['exam_date'],
        'start_time' => $row['start_time'],
        'end_time' => $row['end_time'],
        'room_id' => $row['room_id'], // Add room_id
        'course_id' => $row['course_id'], // Add course_id
        'branch_id' => $branch_id, // Add branch_id
        'invigilator_1_id' => $invigilator_ids[0], // ID of Invigilator 1
        'invigilator_2_id' => $invigilator_ids[1], // ID of Invigilator 2
        'invigilator_1' => $invigilators[$invigilator_ids[0]], // Name of Invigilator 1
        'invigilator_2' => $invigilators[$invigilator_ids[1]], // Name of Invigilator 2
    ];
} */

// Include the database connection file
session_start();
require_once('config/connect.php');
header('Content-Type: application/json');

// Check if the session is valid
if (!isset($_SESSION['branch_id'])) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}

// Get the branch ID from the session
$branch_id = intval($_SESSION['branch_id']);

// Query exam schedules for the logged-in user's branch
$stmt = $conn->prepare("SELECT es.*, c.course_name, r.room_name FROM exam_schedules es JOIN courses c ON es.course_id = c.course_id JOIN classrooms r ON es.room_id = r.room_id WHERE es.branch_id = ?");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["error" => "No exam schedules found for this branch."]);
    exit();
}

// Fetch invigilators (Proctors) for the branch from the users table
$stmt = $conn->prepare("SELECT user_id, username FROM users WHERE branch_id = ? AND role = 'Proctor'");
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$invigilators_result = $stmt->get_result();

// Store invigilators in an array
$invigilators = [];
while ($row = $invigilators_result->fetch_assoc()) {
    $invigilators[$row['user_id']] = $row['username']; // Store user_id and name
}

// Check if there are enough invigilators
if (count($invigilators) < 1) {
    echo json_encode(["error" => "Not enough invigilators available for this branch."]);
    exit();
}

// Assign invigilators randomly to exam schedules
$assigned_invigilators = [];
while ($row = $result->fetch_assoc()) {
    $invigilator_ids = array_keys($invigilators);
    shuffle($invigilator_ids); // Shuffle to get random assignment
    $assigned_invigilators[] = [
        'exam_id' => $row['exam_id'], // Add exam_id
        'course_name' => $row['course_name'],
        'room_name' => $row['room_name'],
        'exam_date' => $row['exam_date'],
        'start_time' => $row['start_time'],
        'end_time' => $row['end_time'],
        'room_id' => $row['room_id'], // Add room_id
        'course_id' => $row['course_id'], // Add course_id
        'branch_id' => $branch_id, // Add branch_id
        'invigilator_1_id' => $invigilator_ids[0], // ID of Invigilator 1
        'invigilator_2_id' => $invigilator_ids[1], // ID of Invigilator 2
        'invigilator_1' => $invigilators[$invigilator_ids[0]], // Name of Invigilator 1
        'invigilator_2' => $invigilators[$invigilator_ids[1]], // Name of Invigilator 2
    ];
}

 

// Return the assigned invigilators as JSON


echo json_encode($assigned_invigilators);
?>