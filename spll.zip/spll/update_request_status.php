<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    exit(json_encode(['success' => false, 'message' => 'Not logged in']));
}

$user_id = $_SESSION['user_id']; // رقم المستخدم الحالي (IT-Support)
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// التأكد أن المستخدم هو IT-Support
if ($role !== 'IT-Support') {
    exit(json_encode(['success' => false, 'message' => 'Permission denied']));
}

// تحديث حالة الطلب عند النقر على الزر
if (isset($_POST['request_id']) && isset($_POST['new_status'])) {
    $request_id = $_POST['request_id'];
    $new_status = $_POST['new_status'];

    // تحديث حالة الطلب وتعيين المستخدم الحالي كالدعم المسؤول
    $update_query = "
        UPDATE help_requests 
        SET status = '$new_status', assigned_to_user = $user_id 
        WHERE request_id = $request_id AND branch_id = $branch_id
    ";

    if ($conn->query($update_query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update status.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>
