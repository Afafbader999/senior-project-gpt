<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

 
?>

<?php
require_once('config/connect.php');
// عرض قائمة المستخدمين من جدول المستخدمين بناءً على دور IT-Support
$query_support_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ?"; 
$stmt = $conn->prepare($query_support_users);
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result_support_users = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screen Sharing with Support</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        footer {
            text-align: center;
            background-color: #000;
            color: #fff;
            padding: 10px;
        }

        h1 {
            color: #333;
        }

        button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #startShare {
            background-color: #4CAF50;
            color: white;
        }

        #stopShare {
            background-color: #f44336;
            color: white;
        }

        button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        video {
            margin-top: 20px;
            width: 80%;
            max-width: 600px;
            border: 2px solid #ddd;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <h1>Screen Sharing with IT-Support</h1>

    <!-- اختيار الدعم -->
    <div class="form-group">
        <label for="supportUser">Select IT-Support:</label>
        <select class="form-control" id="supportUser" name="support_user">
            <?php
            // عرض قائمة المستخدمين
            while ($row = $result_support_users->fetch_assoc()) {
                echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
            }
            ?>
        </select>
    </div>

    <!-- أزرار التحكم -->
    <button id="startShare" disabled>Start Screen Sharing</button>
    <button id="stopShare" disabled>Stop Sharing</button>

    <video id="screenVideo" autoplay></video>
</div>

<script>
    const startShareBtn = document.getElementById("startShare");
    const stopShareBtn = document.getElementById("stopShare");
    const screenVideo = document.getElementById("screenVideo");
    const supportUserSelect = document.getElementById("supportUser");
    let screenStream;

    // تمكين زر بدء المشاركة بعد اختيار المستخدم
    supportUserSelect.addEventListener('change', () => {
        if (supportUserSelect.value) {
            startShareBtn.disabled = false;
        } else {
            startShareBtn.disabled = true;
        }
    });

    startShareBtn.onclick = async () => {
        try {
            if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
                alert("Screen sharing is not supported in this browser.");
                return;
            }

            screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            screenVideo.srcObject = screenStream;

            // تحديث حالة الأزرار
            startShareBtn.disabled = true;
            stopShareBtn.disabled = false;
        } catch (err) {
            console.error("Error during screen sharing:", err);
            let message = "An error occurred while sharing the screen.";
            if (err.name === 'NotAllowedError') {
                message = "Screen sharing permission was denied.";
            } else if (err.name === 'NotFoundError') {
                message = "No screen found to share.";
            } else if (err.name === 'AbortError') {
                message = "Screen sharing request was canceled.";
            }
            alert(message);
        }
    };

    stopShareBtn.onclick = () => {
        if (screenStream) {
            screenStream.getTracks().forEach(track => track.stop());
            screenVideo.srcObject = null;

            // تحديث حالة الأزرار
            startShareBtn.disabled = false;
            stopShareBtn.disabled = true;
        }
    };
</script>
</body>
</html>
