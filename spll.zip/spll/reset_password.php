<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 500px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #cccccc;
            border-radius: 3px;
            box-sizing: border-box;
        }

        button[type="submit"] {
            width: 100%;
            background-color: #000000;
            color: #ffffff;
            padding: 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button[type="submit"]:hover {
            background-color: #444444;
        }

        .success-message {
            text-align: center;
            color: #4CAF50;
            margin-top: 10px;
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    require_once('config/connect.php');

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
            $new_password = $_POST['new_password'];
            $confirm_password = $_POST['confirm_password'];

            // Check if passwords match
            if ($new_password == $confirm_password) {
                // Retrieve email from session
                if (isset($_SESSION['email'])) {
                    $email = $_SESSION['email'];

                    // Hash the new password
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                    // Update the user's password in the database
                    $sql = "UPDATE users SET password_hash = '$hashed_password' WHERE email = '$email'";
                    if ($conn->query($sql) === TRUE) {
                        // Password updated successfully
                        echo '<div class="success-message">Your password has been changed successfully.</div>';
                        header("Location: login.php");
                        exit;
                    } else {
                        echo "Error updating password: " . $conn->error;
                    }
                } else {
                    echo "Email not found in session.";
                }
            } else {
                echo '<div class="error-message">Passwords do not match.</div>';
            }
        } else {
            echo '<div class="error-message">Both new password and confirm password are required.</div>';
        }
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" onsubmit="return validatePassword();">
        <h2>Reset Password</h2>
        <label for="new_password">New Password:</label>
        <input type="password" id="new_password" name="new_password" required>
        <br>
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required>
        <br>
        <button type="submit">Reset Password</button>
        <div id="error-message" class="error-message" style="display: none;"></div>
    </form>

    <script>
        function validatePassword() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const errorMessageDiv = document.getElementById('error-message');
            errorMessageDiv.style.display = 'none'; // Reset error message display

            // Regular expression for password validation
            const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*()_+[\]{};":\\|,.<>?~`]).{8,}$/;

            // Validate passwords
            if (!passwordPattern.test(newPassword)) {
                errorMessageDiv.textContent = "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.";
                errorMessageDiv.style.display = 'block';
                return false; // Prevent form submission
            }

            if (newPassword !== confirmPassword) {
                errorMessageDiv.textContent = "Passwords do not match.";
                errorMessageDiv.style.display = 'block';
                return false; // Prevent form submission
            }

            return true; // Allow form submission
        }
    </script>
</body>
</html>