<?php
// بدء الجلسة
session_start();

// الاتصال بقاعدة البيانات
require_once('config/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على القيم من النموذج
    $exam_id = $_POST['exam_id'];
    $branch_id = $_POST['branch_id'];
    $room_id = $_POST['classroom_id'];
    $course_id = $_POST['course_id'];
    $semester = $_POST['semester'];
    $exam_date = $_POST['exam_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // التحقق من وجود امتحان في نفس القاعة والتاريخ والوقت
    $checkQuery = "SELECT * FROM exam_schedules 
                   WHERE branch_id='$branch_id' 
                   AND room_id='$room_id' 
                   AND exam_date='$exam_date' 
                   AND ('$start_time' < end_time or '$end_time' > start_time)";

    $result = $conn->query($checkQuery);

    if ($result->num_rows > 0) {
        // إذا كان هناك تعارض، عرض رسالة خطأ
        $_SESSION['message'] = 'The classroom is occupied at this time. Please choose another classroom.';
        header("Location: dashboard.php");
        exit();
    } else {
        // إذا لم يكن هناك تعارض، إضافة الامتحان
        $sql = "INSERT INTO exam_schedules (exam_id, branch_id, course_id, semester, exam_date, start_time, end_time) 
                VALUES ('$exam_id', '$branch_id', '$course_id', '$semester', '$exam_date', '$start_time', '$end_time')";

        // تنفيذ الاستعلام والتحقق
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = 'Exam schedule added successfully';
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['message'] = 'An error occurred while adding the exam schedule: ' . mysqli_error($conn);
            header("Location: dashboard.php");
            exit();
        }
    }

    // إغلاق الاتصال بقاعدة البيانات
    mysqli_close($conn);
}
?>
