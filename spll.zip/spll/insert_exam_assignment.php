<?php
session_start();
include 'config/connect.php'; // تضمين ملف الاتصال بقاعدة البيانات
$branchid = intval($_SESSION['branch_id']);

// التحقق من وجود بيانات POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // الحصول على البيانات من النموذج
    $exam_id = intval($_POST['exam_id']);
    $porit_id1 = intval($_POST['invigilator1']);
    $porit_id2 = isset($_POST['invigilator2']) ? intval($_POST['invigilator2']) : null; // يمكن أن يكون فارغاً
    $branch_id = $branchid;
    $room_id = intval($_POST['room_id']);
    $course_id = intval($_POST['course_id']);
    $assignment_date = $_POST['assignment_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // التحقق من أن الوقت النهائي أكبر من الوقت الابتدائي
    if ($start_time >= $end_time) {
        $_SESSION['message'] = "End time must be greater than start time.";
        header("Location: invigilators.php");
        exit();
    }

    // إعداد استعلام إدخال بيانات المراقب الأول
    $sql1 = "INSERT INTO exam_assignments (exam_id, porit_id, role, branch_id, room_id, course_id, assignment_date, start_time, end_time) 
             VALUES ($exam_id, $porit_id1, 'Proctor', $branch_id, $room_id, $course_id, '$assignment_date', '$start_time', '$end_time')";

    // تنفيذ الاستعلام لإدخال بيانات المراقب الأول
    if ($conn->query($sql1) === TRUE) {
        $_SESSION['message'] = 'Exam assignment added successfully for Invigilator 1.';
    } else {
        $_SESSION['message'] = 'Error adding Exam assignment for Invigilator 1: ' . $conn->error;
    }

    // إذا تم إدخال المراقب الثاني، يتم إدخاله كإدخال منفصل
    if ($porit_id2 !== null) {
        // إعداد استعلام إدخال بيانات المراقب الثاني
        $sql2 = "INSERT INTO exam_assignments (exam_id, porit_id, role, branch_id, room_id, course_id, assignment_date, start_time, end_time) 
                 VALUES ($exam_id, $porit_id2, 'Proctor', $branch_id, $room_id, $course_id, '$assignment_date', '$start_time', '$end_time')";

        // تنفيذ الاستعلام لإدخال بيانات المراقب الثاني
        if ($conn->query($sql2) === TRUE) {
            $_SESSION['message'] .= " Exam assignment added successfully for Invigilator 2.";
        } else {
            $_SESSION['message'] .= " Error adding Exam assignment for Invigilator 2: " . $conn->error;
        }
    }

    // إعادة توجيه إلى صفحة المراقبين مع عرض الرسالة
    header("Location: invigilators.php");
    exit();
}

// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>