<?php
// Include the database connection file
session_start();
require_once('config/connect.php');
header('Content-Type: application/json');

// Check if the session is valid
if (!isset($_SESSION['branch_id'])) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}

// Get the branch ID from the session
$branch_id = intval($_SESSION['branch_id']);

// Query exam schedules for the logged-in user's branch
$schedule_query = "SELECT es.*, c.course_name, r.room_name 
                   FROM exam_schedules es 
                   JOIN courses c ON es.course_id = c.course_id 
                   JOIN classrooms r ON es.room_id = r.room_id";

$schedule_result = mysqli_query($conn, $schedule_query);

if (mysqli_num_rows($schedule_result) === 0) {
    echo json_encode(["error" => "No exam schedules found for this branch."]);
    exit();
}

// Fetch invigilators (Proctors) for the branch from the users table
$invigilator_query = "SELECT user_id, username FROM users   role = 'Proctor'";
$invigilators_result = mysqli_query($conn, $invigilator_query);

// Store invigilators in an array
$invigilators = [];
while ($row = mysqli_fetch_assoc($invigilators_result)) {
    $invigilators[$row['user_id']] = $row['username']; // Store user_id and name
}

// Check if there are enough invigilators
if (count($invigilators) < 2) {
    echo json_encode(["error" => "Not enough invigilators available for this branch."]);
    exit();
}

// Assign invigilators randomly to exam schedules
$assigned_invigilators = [];
while ($row = mysqli_fetch_assoc($schedule_result)) {
    $invigilator_ids = array_keys($invigilators); // Get all invigilator ids
    shuffle($invigilator_ids); // Shuffle for random assignment

    // Loop through invigilators to find suitable ones
    $selected_invigilators = [];
    foreach ($invigilator_ids as $invigilator_id) {
        // Check if this invigilator has already been assigned for the same course, branch, date, and time
        $check_query = "SELECT * FROM exam_assignments WHERE porit_id = $invigilator_id 
                        AND branch_id = {$row['branch_id']} 
                        AND room_id = {$row['room_id']} 
                        AND course_id = {$row['course_id']}
                        AND assignment_date = '{$row['exam_date']}' 
                        AND start_time = '{$row['start_time']}' 
                        AND end_time = '{$row['end_time']}'";

        $check_result = mysqli_query($conn, $check_query);

        // If no conflict found, assign this invigilator
        if (mysqli_num_rows($check_result) == 0) {
            $selected_invigilators[] = $invigilator_id;
            if (count($selected_invigilators) == 2) {
                break; // Stop once two invigilators are selected
            }
        }
    }

    // Ensure two invigilators are selected, otherwise handle the error
    if (count($selected_invigilators) < 2) {
        echo json_encode(["error" => "Not enough available invigilators for exam ID: " . $row['exam_id']]);
        exit();
    }

    // Add the assignment details to the assigned invigilators array
    $assigned_invigilators[] = [
        'exam_id' => $row['exam_id'],
        'course_name' => $row['course_name'],
        'room_name' => $row['room_name'],
        'exam_date' => $row['exam_date'],
        'start_time' => $row['start_time'],
        'end_time' => $row['end_time'],
        'room_id' => $row['room_id'],
        'course_id' => $row['course_id'],
        'branch_id' => $branch_id,
        'invigilator_1_id' => $selected_invigilators[0], // ID of Invigilator 1
        'invigilator_2_id' => $selected_invigilators[1], // ID of Invigilator 2
        'invigilator_1' => $invigilators[$selected_invigilators[0]], // Name of Invigilator 1
        'invigilator_2' => $invigilators[$selected_invigilators[1]], // Name of Invigilator 2
    ];
}

// Return the assigned invigilators as JSON
echo json_encode($assigned_invigilators);

?>
