<?php
//update_message.php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // تأكيد أن المستخدم مسجل الدخول
    if (!isset($_SESSION['user_id'])) {
        exit(); // الخروج بدون عرض أي رسالة
    }

    $chat_id = $_POST['chat_id'];
    $message_content = $_POST['message_content'];
    $user_id = $_SESSION['user_id'];

    // تحديث الرسالة في قاعدة البيانات
    $stmt = $conn->prepare("UPDATE chats SET message_content = ? WHERE chat_id = ? AND sender_user_id = ?");
    $stmt->bind_param("sii", $message_content, $chat_id, $user_id);
    $stmt->execute();
    $stmt->close();

    exit(); // الخروج بدون عرض أي رسالة
} else {
    exit(); // الخروج بدون عرض أي رسالة
}
