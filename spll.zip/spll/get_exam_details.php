<?php
include 'config/connect.php';

$course_id = isset($_POST['course_id']) ? intval($_POST['course_id']) : 0;
$branch_id = isset($_POST['branch_id']) ? intval($_POST['branch_id']) : 0;

$response = ["success" => false];

if ($course_id && $branch_id) {
    $sql = "SELECT exam_date_start, start_time, end_time 
            FROM exam_schedules 
            WHERE course_id = ? AND branch_id = ?
            LIMIT 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $course_id, $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = [
            "success" => true,
            "exam_date_start" => $row['exam_date_start'],
            "start_time" => $row['start_time'],
            "end_time" => $row['end_time']
        ];
    }
}

echo json_encode($response);
?>
