<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id']; // الحصول على رقم الفرع من الجلسة

// الحصول على بيانات الجلسة من الجدول باستخدام session_id و branch_id من الجلسة
$query_session_check = "SELECT * FROM sessions WHERE (proctor_id = ? OR support_id = ?) AND branch_id = ?";
$stmt = $conn->prepare($query_session_check);
$stmt->bind_param("iii", $user_id, $user_id, $branch_id); // ربط البيانات باستخدام المعلمات
$stmt->execute();
$result_session = $stmt->get_result();

if ($result_session->num_rows > 0) {
    $session = $result_session->fetch_assoc();
    
    // التحقق من أن المستخدم هو الدعم الفني أو البروكتور بناءً على role
    if ($_SESSION['role'] == 'IT-Support' && $user_id == $session['support_id']) {
        // إذا كان المستخدم دعم فني وتطابق support_id
        $is_valid_session = true;
    } elseif ($_SESSION['role'] == 'Proctor' && $user_id == $session['proctor_id']) {
        // إذا كان المستخدم بروكتور وتطابق proctor_id
        $is_valid_session = true;
    } else {
        $is_valid_session = false;
        $error_message = "You are not authorized to access this session.";
    }
} else {
    $is_valid_session = false;
    $error_message = "Invalid session or branch mismatch.";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screen Share Session</title>
</head>
<body>
    <h1>Screen Sharing Session</h1>
    
    <?php if ($is_valid_session): ?>
        <h3>Session Link: <?php echo $session['session_link']; ?></h3>
        <button id="startShare">Start Screen Sharing</button>
        <button id="stopShare" disabled>Stop Sharing</button>
        
        <video id="screenVideo" autoplay></video>

        <script>
            const startShareBtn = document.getElementById('startShare');
            const stopShareBtn = document.getElementById('stopShare');
            const screenVideo = document.getElementById('screenVideo');
            let screenStream;

            startShareBtn.onclick = async () => {
                try {
                    screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                    screenVideo.srcObject = screenStream;

                    startShareBtn.disabled = true;
                    stopShareBtn.disabled = false;
                } catch (err) {
                    console.error('Error sharing screen:', err);
                    alert("Failed to start screen sharing.");
                }
            };

            stopShareBtn.onclick = () => {
                if (screenStream) {
                    screenStream.getTracks().forEach(track => track.stop());
                    screenVideo.srcObject = null;

                    startShareBtn.disabled = false;
                    stopShareBtn.disabled = true;
                }
            };
        </script>
    <?php else: ?>
        <p style="color: red;"><?php echo $error_message; ?></p>
    <?php endif; ?>
</body>
</html>
