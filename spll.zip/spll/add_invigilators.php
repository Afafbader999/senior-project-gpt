<?php
// Include the database connection file
session_start();
require_once('config/connect.php');

header('Content-Type: application/json');

// Get the posted data
$data = json_decode(file_get_contents('php://input'), true);

// Check if the expected keys exist in the received data
if (isset($data['exam_id']) && 
    isset($data['invigilator_1_id']) && 
    isset($data['invigilator_2_id']) && 
    isset($data['branch_id']) && 
    isset($data['room_id']) && 
    isset($data['course_id']) && 
    isset($data['assignment_date']) && 
    isset($data['start_time']) && 
    isset($data['end_time'])) {

    // Get the values from the decoded data
    $exam_id = $data['exam_id'];
    $invigilator_1_id = $data['invigilator_1_id'];
    $invigilator_2_id = $data['invigilator_2_id'];
    $branch_id = $data['branch_id'];
    $room_id = $data['room_id'];
    $course_id = $data['course_id'];
    $assignment_date = $data['assignment_date'];
    $start_time = $data['start_time'];
    $end_time = $data['end_time'];

    $response = ['messages' => [], 'errors' => []];

    // Insert data for Invigilator 1
    $insert_query_1 = "INSERT INTO exam_assignments (exam_id, porit_id, role, branch_id, room_id, course_id, assignment_date, start_time, end_time) VALUES ('$exam_id', '$invigilator_1_id', 'Proctor', '$branch_id', '$room_id', '$course_id', '$assignment_date', '$start_time', '$end_time')";
    
    if (mysqli_query($conn, $insert_query_1)) {
        $response['messages'][] = "Data for Invigilator 1 added successfully.";
    } else {
        $response['errors'][] = "Error for Invigilator 1: " . mysqli_error($conn);
    }

    // Insert data for Invigilator 2
    $insert_query_2 = "INSERT INTO exam_assignments (exam_id, porit_id, role, branch_id, room_id, course_id, assignment_date, start_time, end_time) VALUES ('$exam_id', '$invigilator_2_id', 'Proctor', '$branch_id', '$room_id', '$course_id', '$assignment_date', '$start_time', '$end_time')";
    
    if (mysqli_query($conn, $insert_query_2)) {
        $response['messages'][] = "Data for Invigilator 2 added successfully.";
    } else {
        $response['errors'][] = "Error for Invigilator 2: " . mysqli_error($conn);
    }

    // Return the response as JSON
    echo json_encode($response);
    exit();

} else {
    echo json_encode(["error" => "Required fields are missing"]);
    exit();
}
?>
