<?php
// Start the session to access session variables
session_start();

// Include the database connection file
require_once('config/connect.php');

// Get the branch_id from the session
$branch_id = $_SESSION['branch_id'];

// Query exam schedules for the logged-in user's branch
$query = "
    SELECT es.*, c.course_name 
    FROM exam_schedules es
    JOIN courses c ON es.course_id = c.course_id
    WHERE es.branch_id = $branch_id";
$result = mysqli_query($conn, $query);

// Fetch invigilators (Proctors) for the branch from the users table
$invigilators_query = "SELECT * FROM users WHERE branch_id = $branch_id AND role = 'Proctor'";
$invigilators_result = mysqli_query($conn, $invigilators_query);

// Store invigilators in an array
$invigilators = [];
while ($row = mysqli_fetch_assoc($invigilators_result)) {
    $invigilators[] = $row;
}

// Check if invigilators are available
if (count($invigilators) < 2) {
    die("Not enough invigilators available for this branch.");
}

// Initialize invigilator assignment index
$invigilator_index = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invigilator Distribution</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1>Invigilator Distribution - Branch <?php echo $branch_id; ?></h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Course Name</th>
                <th>Room</th>
                <th>Exam Date</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Invigilator 1</th>
                <th>Invigilator 2</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?php echo $row['course_name']; ?></td>
                <td><?php echo $row['room_id']; ?></td>
                <td><?php echo $row['exam_date']; ?></td>
                <td><?php echo $row['start_time']; ?></td>
                <td><?php echo $row['end_time']; ?></td>
                <td>
                    <?php
                    // Assign first invigilator
                    echo $invigilators[$invigilator_index]['username']; // Use username instead of name
                    $invigilator_index = ($invigilator_index + 1) % count($invigilators);
                    ?>
                </td>
                <td>
                    <?php
                    // Assign second invigilator
                    echo $invigilators[$invigilator_index]['username']; // Use username instead of name
                    $invigilator_index = ($invigilator_index + 1) % count($invigilators);
                    ?>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>

<?php
// Close the connection
mysqli_close($conn);
?>
