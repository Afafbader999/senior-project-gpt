<?php 
session_start();
// تضمين ملف الترجمات
include 'lang.php';

// تعيين اللغة الافتراضية
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

require_once('config/connect.php');

// استرجاع branch_id و porit_id من الجلسة
$branch_id = $_SESSION['branch_id'];
$porit_id = $_SESSION['user_id']; 
$role = $_SESSION['role'];

// تحديد الشهر والسنة الحاليين
$current_month = date('m');
$current_year = date('Y');

// جلب التوزيعات الخاصة بالمراقب للشهر الحالي
$query = "
    SELECT 
        ea.assignment_date, 
        ea.start_time, 
        ea.end_time, 
        c.course_name,
        cl.room_name,
        cl.building_name,
        cl.floor
    FROM 
        exam_assignments ea
    JOIN 
        courses c ON ea.course_id = c.course_id
    JOIN 
        classrooms cl ON ea.room_id = cl.room_id
    WHERE 
        ea.branch_id = ? AND 
        ea.porit_id = ? AND 
        MONTH(ea.assignment_date) = ? AND 
        YEAR(ea.assignment_date) = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param('iiis', $branch_id, $porit_id, $current_month, $current_year);
$stmt->execute();
$result = $stmt->get_result();

$assignments = [];
while ($row = $result->fetch_assoc()) {
    $date = $row['assignment_date'];
    $assignments[$date][] = [
        'start_time' => $row['start_time'],
        'end_time' => $row['end_time'],
        'course_name' => $row['course_name'],
        'room_name' => $row['room_name'],
        'building_name' => $row['building_name'],
        'floor' => $row['floor']
    ];
}

// إغلاق الاتصال بقاعدة البيانات
$stmt->close();
?>


<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('calendar_title', $lang, $translations); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f5f5f5;
        }
        .calendar {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
            margin: 20px 0;
        }
        .day {
            border-radius: 8px;
            padding: 15px;
            height: 100px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            position: relative;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }
        .day h5 {
            margin: 0;
            font-size: 1.2em;
            color: #333;
            font-weight: bold;
        }
        .day.exam-day {
            background-color: #C9E9D2; /* Light blue background for exam days */
            text-align: center;
            border: #000 solid 1px;
        }
        .popup {
            display: none;
            position: absolute;
            top: 120%;
            left: 50%;
            transform: translateX(-50%);
            background-color: #fff;
            border: 1px solid #007bff;
            padding: 10px;
            z-index: 100;
            width: 200px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .day.exam-day:hover .popup {
            display: block; /* Show on hover */
        }

        .close-btn {
            color: #007bff;
            float: right;
            cursor: pointer;
        }

        @media (max-width: 768px) {
            .calendar {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        @media (max-width: 576px) {
            .calendar {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
    <?php include 'config/header.php';?>

    <div class="container mt-5">
        <h1 class="text-center mb-4"><?php echo getTranslation('calendar_title', $lang, $translations); ?> <?php echo date('F Y'); ?></h1>

        <div class="calendar">
            <?php
            // Generate the calendar
            $first_day_of_month = new DateTime("{$current_year}-{$current_month}-01");
            $last_day_of_month = new DateTime("{$current_year}-{$current_month}-" . $first_day_of_month->format('t'));

            // Fill the empty cells at the start of the month
            for ($i = 1; $i < $first_day_of_month->format('N'); $i++) {
                echo '<div class="day"></div>';
            }

            // Display each day of the month
            for ($day = 1; $day <= $last_day_of_month->format('t'); $day++) {
                $current_date = "{$current_year}-{$current_month}-" . str_pad($day, 2, '0', STR_PAD_LEFT);
                $day_class = '';
                $exam_info = '';

                // Check if there are assignments for this day
                if (isset($assignments[$current_date])) {
                    $day_class = 'exam-day'; // Apply the class for days with exams

                    // Collect exam information for the popup
                    foreach ($assignments[$current_date] as $assignment) {
                        $exam_info .= "<strong>" . getTranslation('course', $lang, $translations) . ":</strong> " . htmlspecialchars($assignment['course_name']) . "<br>";
                        $exam_info .= "<strong>" . getTranslation('time', $lang, $translations) . ":</strong> " . htmlspecialchars($assignment['start_time']) . " - " . htmlspecialchars($assignment['end_time']) . "<br>";
                        $exam_info .= "<strong>" . getTranslation('room', $lang, $translations) . ":</strong> " . htmlspecialchars($assignment['room_name']) . "<br>";
                        $exam_info .= "<strong>" . getTranslation('building', $lang, $translations) . ":</strong> " . htmlspecialchars($assignment['building_name']) . "<br>";
                        $exam_info .= "<strong>" . getTranslation('floor', $lang, $translations) . ":</strong> " . htmlspecialchars($assignment['floor']) . "<br>";
                    }
                }

                echo '<div class="day ' . $day_class . '" onclick="togglePopup(this)" data-exam-info="' . htmlspecialchars($exam_info) . '">';
                echo '<h5>' . $day . '</h5>';
                
                if ($day_class) {
                    echo '<div class="popup">';
                    echo '<span class="close-btn" onclick="closePopup(this)">×</span>';
                    echo $exam_info;
                    echo '</div>';
                }

                echo '</div>';
            }
            ?>
        </div>
    </div>

    <?php include 'config/footer.php'; ?>

    <script>
        // Function to show/hide the popup on click
        function togglePopup(dayElement) {
            const popup = dayElement.querySelector('.popup');
            const allPopups = document.querySelectorAll('.popup');
            
            // Close all other open popups
            allPopups.forEach(p => {
                if (p !== popup) {
                    p.style.display = 'none';
                }
            });

            // Toggle the current popup
            if (popup.style.display === 'block') {
                popup.style.display = 'none';
            } else {
                popup.style.display = 'block';
            }
        }

        // Function to close the popup when close button is clicked
        function closePopup(closeBtn) {
            const popup = closeBtn.parentElement;
            popup.style.display = 'none';
        }

        // Optional: close popup if clicked outside of it
        window.addEventListener('click', function(event) {
            const popups = document.querySelectorAll('.popup');
            popups.forEach(popup => {
                if (!popup.contains(event.target) && !event.target.classList.contains('day')) {
                    popup.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
