<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Advanced Tabs</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* جعل المحتوى في التبويبات متجاوب بالكامل */
        .tab-content {
            margin-top: 20px;
        }
        .tab-pane {
            min-height: 300px; /* لتجنب الارتجاج في التبويبات عند تبديل المحتويات */
        }
        iframe {
            width: 100%;
            height: 400px;
            border: none;
        }
        @media (max-width: 576px) {
            /* تحسين عرض التبويبات على الشاشات الصغيرة */
            .nav-tabs {
                flex-wrap: wrap;
            }
            .nav-tabs .nav-item {
                width: 100%; /* عرض التبويبات كاملة بعرض الشاشة */
            }
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <!-- Nav Tabs -->
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Home</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="messages-tab" data-bs-toggle="tab" href="#messages" role="tab" aria-controls="messages" aria-selected="false">Messages</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link disabled" id="disabled-tab" aria-disabled="true">Disabled</a>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content" id="myTabContent">
        <!-- Home Tab -->
        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
            <h3>Home</h3>
            <p>This is the home tab content. You can add any content you like here.</p>
            <iframe src="https://example.com"></iframe> <!-- Example external page -->
        </div>

        <!-- Profile Tab -->
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
            <h3>Profile</h3>
            <p>This is the profile tab content. You can load dynamic content here.</p>
            <iframe src="https://example.com"></iframe> <!-- Example external page -->
        </div>

        <!-- Messages Tab -->
        <div class="tab-pane fade" id="messages" role="tabpanel" aria-labelledby="messages-tab">
            <h3>Messages</h3>
            <p>This is the messages tab content. Customize this section with your content.</p>
            <iframe src="https://example.com"></iframe> <!-- Example external page -->
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
