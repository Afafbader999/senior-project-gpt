<?php
session_start();
include 'config/connect.php'; // تضمين إعدادات الاتصال بقاعدة البيانات

// تحقق مما إذا تم تمرير branch_id عبر GET
if (isset($_GET['branch_id'])) {
    $branch_id = $_GET['branch_id'];

    // استعلام لجلب الغرف المرتبطة بالفرع المحدد
    $sql = "SELECT room_id, room_name FROM classrooms WHERE branch_id = '$branch_id'";
    $result = mysqli_query($conn, $sql);

    // تحقق من وجود نتائج
    if (mysqli_num_rows($result) > 0) {
        // إنشاء الخيارات للغرف
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<option value='" . $row['room_id'] . "'>" . $row['room_name'] . "</option>";
        }
    } else {
        // إذا لم توجد غرف، قم بإرجاع خيار فارغ
        echo "<option value=''>No rooms available</option>";
    }
} else {
    // إذا لم يتم تمرير branch_id، قم بإرجاع خيار فارغ
    echo "<option value=''>Invalid Branch ID</option>";
}

// إغلاق اتصال قاعدة البيانات
mysqli_close($conn);
?>
