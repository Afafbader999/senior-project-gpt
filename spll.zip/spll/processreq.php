<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
 
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id']; // رقم المستخدم الحالي (IT-Support)
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];
$gender = $_SESSION['gender']; // إضافة متغير الجنس

// التأكد أن المستخدم هو IT-Support
if ($role !== 'IT-Support') {
    echo "You do not have permission to view this page.";
    exit();
}

// بناء شرط استعلام للحصول على الطلبات بناءً على الجنس
if ($gender === 'Female') {
    // إذا كان الدعم من الإناث، عرض الطلبات الخاصة بالإناث فقط
    $gender_condition = "AND u.gender = 'Female'";
} else if ($gender === 'male') {
    // إذا كان الدعم من الذكور، عرض الطلبات الخاصة بالذكور فقط
    $gender_condition = "AND u.gender = 'male'";
} else {
    $gender_condition = ""; // في حالة عدم وجود جنس محدد
}

// الحصول على جميع الطلبات في نفس الفرع مع شرط الجنس
$query = "SELECT hr.request_id, hr.description, hr.type_help, hr.status, hr.created_at, u.username, 
       c.room_name, c.building_name, c.floor, c.room_type
FROM help_requests hr
JOIN users u ON hr.user_id = u.user_id
JOIN exam_assignments ea ON ea.porit_id = u.user_id
JOIN classrooms c ON ea.room_id = c.room_id
WHERE u.branch_id = $branch_id AND hr.status != 'Completed' $gender_condition
GROUP BY hr.request_id  -- Group by the request_id to avoid duplicates
ORDER BY hr.created_at ASC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('brand', $lang, $translations); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alfa+Slab+One&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <!-- Include jQuery -->
    <style>
    html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1; /* This allows the container to grow and fill the available space */
}

footer {
    height: 80px;
    background-color: #ffffff; /* Set the footer background color */
    padding: 10px; /* Padding inside the footer */
    text-align: center; /* Center the footer text */
    color: white; /* Change text color to white */
}
    </style>
</head>
<body>
    
<?php include 'config/header.php'; ?>
    <div class="container mt-5">
        <h2>Help Requests</h2>

        <?php if ($result->num_rows > 0): ?>
    
            <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="table-dark">
                    <tr>
                        <th>Proctor Name</th>
                        <th>Help Type</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Room Name</th>
                        <th>Building</th>
                        <th>Floor</th>
                        <th>Room Type</th>
                        <th>Created At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr data-request-id="<?php echo $row['request_id']; ?>">
                            <td><?php echo htmlspecialchars($row['username']); ?></td>
                            <td><?php echo htmlspecialchars($row['type_help']); ?></td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            <td class="status"><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['room_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['building_name']); ?></td>
                            <td><?php echo htmlspecialchars($row['floor']); ?></td>
                            <td><?php echo htmlspecialchars($row['room_type']); ?></td>
                            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                            <td>
                                <button class="btn btn-warning btn-sm update-status" data-status="In Progress">In Progress</button>
                                <button class="btn btn-success btn-sm update-status" data-status="Completed">Completed</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-warning">No help requests found in your branch.</div>
        <?php endif; ?>
    </div>
    </div>

    <?php include 'config/footer.php'; ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.update-status').click(function() {
                const row = $(this).closest('tr');
                const requestId = row.data('request-id');
                const newStatus = $(this).data('status');

                $.ajax({
                    url: 'update_request_status.php',
                    type: 'POST',
                    data: {
                        request_id: requestId,
                        new_status: newStatus
                    },
                    success: function(response) {
                        const data = JSON.parse(response);
                        if (data.success) {
                            row.find('.status').text(newStatus); // Update status in the table
                            alert('Status updated successfully!');
                        } else {
                            alert('Failed to update status. Please try again.');
                        }
                    },
                    error: function() {
                        alert('An error occurred. Please try again.');
                    }
                });
            });
        });
    </script>
</body>
</html>
