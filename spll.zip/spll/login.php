<?php
session_start();
require_once('config/connect.php');

// تضمين ملف الترجمات
include 'lang.php';

// تعيين اللغة الافتراضية
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

// متغير لتخزين الرسائل
$message = '';

// التحقق من الكوكيز لتذكر المستخدم
if (isset($_COOKIE['remember_user'])) {
    $user_data = json_decode($_COOKIE['remember_user'], true);
    $_SESSION['user_id'] = $user_data['user_id'];
    $_SESSION['username'] = $user_data['username'];
    $_SESSION['email'] = $user_data['email'];
    $_SESSION['role'] = $user_data['role'];
    $_SESSION['branch_id'] = $user_data['branch_id'];
    $_SESSION['gender'] = $user_data['gender'];

    // التوجيه بناءً على دور المستخدم
    switch ($_SESSION['role']) {
        case 'superadmin':
            header("Location: dashboardadminsup.php");
            exit;
        case 'Admin':
            header("Location: dashboard.php");
            exit;
        case 'Proctor':
            header("Location: index.php");
            exit;
        case 'IT-Support':
            header("Location: index.php");
            exit;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // التحقق مما إذا كان اسم المستخدم أو البريد الإلكتروني موجودًا
        $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // التحقق من كلمة المرور
            if (password_verify($password, $user['password_hash'])) {
                // التحقق من حالة الحساب
                if ($user['account_status'] == 'Active') {
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['branch_id'] = $user['branch_id'];
                    $_SESSION['gender'] = $user['gender'];

                    // التحقق مما إذا كان المستخدم يريد التذكر
                    if (isset($_POST['remember_me'])) {
                        // تخزين بيانات المستخدم في الكوكيز لمدة 7 أيام
                        $cookie_data = json_encode([
                            'user_id' => $user['user_id'],
                            'username' => $user['username'],
                            'email' => $user['email'],
                            'role' => $user['role'],
                            'branch_id' => $user['branch_id'],
                            'gender' => $user['gender']
                        ]);
                        setcookie('remember_user', $cookie_data, time() + (86400 * 7), "/"); // 86400 = 1 يوم
                    }

                    // التوجيه بناءً على دور المستخدم
                    switch ($user['role']) {
                        case 'superadmin':
                            header("Location: dashboardadminsup.php");
                            exit;
                        case 'Admin':
                            header("Location: dashboard.php");
                            exit;
                        case 'Proctor':
                            header("Location: index.php");
                            exit;
                        case 'IT-Support':
                            header("Location: index.php");
                            exit;
                    }
                } else {
                    $message = getTranslation('account_suspended', $lang, $translations);
                }
            } else {
                $message = getTranslation('invalid_credentials', $lang, $translations);
            }
        } else {
            $message = getTranslation('username_not_exist', $lang, $translations);
        }
    } else {
        $message = getTranslation('missing_credentials', $lang, $translations);
    }
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('login', $lang, $translations); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">

    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Cairo', sans-serif;
        }
       
        .form-container {
            margin-top: 50px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        footer {
            text-align: center;
            background-color: #000;
            color: #fff;
            padding: 10px;
            margin-top: 14%;
        }
    </style>
</head>
<body dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
<?php include 'config/header.php'; ?>
<div class="container">
    <div class="form-container" dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">
        <h2 class="text-center"><?php echo getTranslation('login', $lang, $translations); ?></h2>
        <?php if (!empty($message)) { ?>
            <div class="alert alert-danger text-center">
                <?php echo $message; ?>
            </div>
        <?php } ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <!-- حقل اسم المستخدم أو البريد الإلكتروني -->
            <div class="form-group">
                <label for="username" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('username', $lang, $translations); ?> / <?php echo getTranslation('email', $lang, $translations); ?></label>
                <input type="text" name="username" id="username" class="form-control" required>
            </div>
            <!-- حقل كلمة المرور -->
            <div class="form-group">
                <label for="password" style="text-align: <?php echo $lang == 'ar' ? 'right' : 'left'; ?>;"><?php echo getTranslation('password', $lang, $translations); ?></label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <!-- حقل تذكرني -->
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" name="remember_me" id="remember_me">
                <label class="form-check-label ml-2 mr-4" for="remember_me"><?php echo getTranslation('remember_me', $lang, $translations); ?></label>
            </div>

            <!-- زر إرسال النموذج -->
            <button type="submit" class="btn btn-primary btn-block"><?php echo getTranslation('submit', $lang, $translations); ?></button>
        </form>
        <div class="text-center mt-3">
            <a href="register.php"><?php echo getTranslation('register', $lang, $translations); ?></a> | 
            <a href="forgot_password.php"><?php echo getTranslation('forgot_password', $lang, $translations); ?></a>
        </div>
        <div class="text-center mt-3">
            <a href="?lang=ar"><?php echo getTranslation('arabic', $lang, $translations); ?></a> | 
            <a href="?lang=en"><?php echo getTranslation('english', $lang, $translations); ?></a>
        </div>
    </div>
</div>
<?php include 'config/footer.php'; ?>
</body>
</html>
