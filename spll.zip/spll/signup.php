<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

$mail = new PHPMailer();

// Enable SMTP debugging
$mail->SMTPDebug = SMTP::DEBUG_SERVER; // Set to 0 in production
$mail->isSMTP();
$mail->Host       = 'smtp.gmail.com';                                  
$mail->SMTPAuth   = true;                                  
$mail->Username   = 'e.exam.proctor.website@gmail.com';                          
$mail->Password   = 'ewwq zdyw yugc lskr'; // Use App Password if 2FA is enabled
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Use PHPMailer::ENCRYPTION_STARTTLS if you prefer that
$mail->Port       = 465; // Use 587 for TLS
$mail->setFrom('e.exam.proctor.website@gmail.com', 'E-exam Proctor Support');
$mail->isHTML(true);
$mail->CharSet = "UTF-8";

session_start();
require_once('config/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Debugging output
    echo "Received data:<br>";
    echo "Gender: " . htmlspecialchars(trim($_POST['gender'])) . "<br>";

    if (isset($_POST['username'], $_POST['email'], $_POST['password'], $_POST['confirmPassword'], $_POST['role'], $_POST['branch_id'], $_POST['gender'])) {
        $username = mysqli_real_escape_string($conn, trim($_POST['username']));
        $email = mysqli_real_escape_string($conn, trim($_POST['email']));
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];
        $role = mysqli_real_escape_string($conn, $_POST['role']);
        $branch_id = intval($_POST['branch_id']);
        
        // Normalize gender to match ENUM values
        $gender = ($_POST['gender'] === 'Male') ? 'male' : 'Female';

        // Debugging output after normalization
        echo "Normalized Gender: " . $gender . "<br>";

        // Check if passwords match
        if ($password !== $confirmPassword) {
            echo "Passwords do not match.";
        } else {
            // Check if email already exists
            $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $checkEmailQuery);

            if ($result && mysqli_num_rows($result) > 0) {
                echo "Email is already registered.";
                echo '<meta http-equiv="refresh" content="3;url=register.php" />';
            } else {
                // Hash the password
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                
                // Generate verification code (6 digits)
                $verification = mt_rand(100000, 999999);

                // Add the new user to the database
                $sql = "INSERT INTO users (username, email, password_hash, role, account_status, verification, branch_id, gender) 
                        VALUES ('$username', '$email', '$hashedPassword', '$role', 'Suspended', '$verification', $branch_id, '$gender')";

                if (mysqli_query($conn, $sql)) {
                    $mail->addAddress($email);
                    $mail->Subject = 'Verification Code';
                    $mail->Body    = 'Your verification code is: ' . $verification;
                    $mail->AltBody = 'Your verification code is: ' . $verification;

                    if (!$mail->send()) {
                        echo "Mailer Error: " . $mail->ErrorInfo;
                        file_put_contents('mail_log.txt', date('Y-m-d H:i:s') . " - Error sending email: " . $mail->ErrorInfo . "\n", FILE_APPEND);
                    } else {
                        $_SESSION['email'] = $email;
                        header("Location: verification.php");
                        exit;
                    }
                } else {
                    echo "Error: " . mysqli_error($conn); // Print the error if insertion fails
                }
            }
        }
    } else {
        echo "All fields are required.";
    }
}
?>