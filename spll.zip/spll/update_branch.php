<?php
session_start();
include 'config/connect.php';

// التحقق من وجود معرف الفرع في الرابط
if (isset($_GET['id'])) {
    $branch_id = $_GET['id'];

    // التحقق من وجود بيانات POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $branch_name = $_POST['branch_name'];
        $city = $_POST['city'];
        $address = $_POST['address'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email'];

        // استعلام لتحديث بيانات الفرع
        $sql = "UPDATE branches SET branch_name = '$branch_name', city = '$city', address = '$address', phone_number = '$phone_number', email = '$email' WHERE branch_id = $branch_id";

        // تنفيذ الاستعلام والتحقق من النجاح
        if (mysqli_query($conn, $sql)) {
            $_SESSION['message'] = 'Branch data updated successfully.';
            header("Location: dashboard.php?msg=success");
            exit();
        } else {
            $_SESSION['message'] = 'An error occurred while updating the data: ' . mysqli_error($conn);
            header("Location: dashboard.php?msg=nocchange");
            exit();
        }
        } else {
            echo "No branch ID specified.";
        }

    }
        
// إغلاق الاتصال بقاعدة البيانات
mysqli_close($conn);
?>
