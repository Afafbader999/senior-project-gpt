<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo "You must be logged in to submit a help request.";
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// التأكد أن المستخدم هو مراقب
if ($role !== 'Proctor') {
    echo "You do not have permission to submit a help request.";
    exit();
}

// معالجة طلب المساعدة
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $type_help = $_POST['type_help'];
    $description = $_POST['description'];

    // إدخال الطلب إلى قاعدة البيانات
    $query = "INSERT INTO help_requests (user_id, description, type_help, branch_id, status) 
              VALUES ($user_id, '$description', '$type_help', $branch_id, 'Pending')";
    
    if ($conn->query($query) === TRUE) {
        echo "<div class='alert alert-success'>Help request submitted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error submitting request: " . $conn->error . "</div>";
    }
}
?>
