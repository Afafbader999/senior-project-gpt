<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'vendor/autoload.php';

// Setting up PHPMailer
$mail = new PHPMailer();
$mail->isSMTP();
$mail->Host       = 'smtp.gmail.com';                                
$mail->SMTPAuth   = true;                                  
$mail->Username   = 'e.exam.proctor.website@gmail.com';                          
$mail->Password   = 'ewwq zdyw yugc lskr'; // Update with your actual password
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
$mail->Port       = 465;
$mail->setFrom('e.exam.proctor.website@gmail.com', 'E-exam Proctor Support');
$mail->isHTML(true);
$mail->CharSet = "UTF-8";

session_start();
require_once('config/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']) && 
        isset($_POST['confirmPassword']) && isset($_POST['role']) && 
        isset($_POST['branch_id']) && isset($_POST['gender'])) {
        
        // Receiving form data
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirmPassword'];
        $role = $_POST['role'];
        $branch_id = intval($_POST['branch_id']); // Convert branch ID to numeric value
        $gender = $_POST['gender']; // Get gender value

        // Check if the password and confirmation match
        if ($password != $confirmPassword) {
            echo "Password and confirmation do not match.";
        } else {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Invalid email address.";
            } else {
                // Check if the email is already registered
                $checkEmailQuery = "SELECT * FROM users WHERE email = '$email'";
                $result = $conn->query($checkEmailQuery);

                if ($result && $result->num_rows > 0) {
                    echo "Email is already registered.";
                } else {
                    // Hash the password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                    // Set account status to 'Active'
                    $account_status = 'Active';

                    // Add the new user to the database
                    $sql = "INSERT INTO users (username, email, password_hash, role, account_status, branch_id, gender) 
                            VALUES ('$username', '$email', '$hashedPassword', '$role', '$account_status', '$branch_id', '$gender')";

                    if ($conn->query($sql) === TRUE) {
                        // Fetch the branch name from the database
                        $branchQuery = "SELECT branch_name FROM branches WHERE branch_id = '$branch_id'";
                        $branchResult = $conn->query($branchQuery);
                        $branch_name = '';
                        if ($branchResult && $branchResult->num_rows > 0) {
                            $branchRow = $branchResult->fetch_assoc();
                            $branch_name = $branchRow['branch_name']; // Get the branch name
                        }

                        // Send all user data via email
                        $mail->addAddress($email);
                        $mail->Subject = 'Your Admin Account Details';
                        $mail->Body    = "
                            <h1>Welcome, $username!</h1>
                            <p>Your admin account has been created with the following details:</p>
                            <ul>
                                <li>Username: $username</li>
                                <li>Email: $email</li>
                                <li>Password: $password</li> <!-- Note: Avoid sending plaintext passwords in emails -->
                                <li>Role: $role</li>
                                <li>Branch: $branch_name</li> <!-- Display branch name instead of the number -->
                                <li>Gender: $gender</li> <!-- Include gender in the email -->
                            </ul>
                            <p>You can now log in with your credentials.</p>";

                        if ($mail->send()) {
                            echo "Admin added and email sent successfully!";
                            header("Location: Securityadminsup.php");
                            exit();
                        } else {
                            echo "Failed to send email.";
                        }
                    } else {
                        echo "Error adding user: " . $conn->error;
                    }
                }
            }
        }
    } else {
        echo "Please fill in all required fields.";
    }
}
?>