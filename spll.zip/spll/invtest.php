<?php
//invigilators.php
session_start();

// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // إعادة توجيه المستخدم لصفحة تسجيل الدخول
    exit();
}

// تضمين ملف الترجمة
include 'lang.php';

// تحديد اللغة
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; // افتراضياً اللغة الإنجليزية
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';


// Check if the session is valid
if (!isset($_SESSION['branch_id'])) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}

// Get the branch ID from the session
$branch_id = intval($_SESSION['branch_id']);
?>
<!DOCTYPE html>
<html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('dashboard', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }

        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
            transition: width 0.3s;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .dashboard-content {
            margin-left: 250px; /* Adjust margin based on sidebar width */
            margin-top: 20px; /* Space above content */
            padding: 20px; /* Padding inside content */
            transition: margin 0.3s;
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>
                margin-left: 15px; /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>
                margin-right: 15px; /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar {
                display: none; /* Hide sidebar on small screens */
            }

            .dashboard-content {
                margin: 0; /* Reset margin for mobile */
                padding: 20px; /* Ensure padding remains */
            }
        }

        /* Toast styles */
        .message {
            display: none;
            margin: 10px 0;
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>

<body>
    <?php include 'sidebar.php'; ?>

    <div class="dashboard-content">
        <h1 class="text-center">Exam Invigilator Management</h1>

        <div id="messageDiv" style='display:none;' class="message"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered" id="invigilatorsTable">
                            <thead class="table-dark">
                                <tr>
                                    <th>Course Name</th>
                                    <th>Room Name</th>
                                    <th>Exam Date</th>
                                    <th>Start Time</th>
                                    <th>End Time</th>
                                    <th>Invigilator 1</th>
                                    <th>Invigilator 2</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                require_once('config/connect.php');

                                $query = "SELECT es.*, c.course_name, r.room_name, r.building_name, b.branch_name
                                FROM exam_schedules es
                                JOIN courses c ON es.course_id = c.course_id
                                JOIN classrooms r ON es.branch_id = r.branch_id
                                JOIN branches b ON es.branch_id = b.branch_id
                                JOIN department d ON es.Department = d.Department_id
                                WHERE es.branch_id = $branch_id
                                ORDER BY b.branch_name, d.Department, r.room_name";

                                $result = mysqli_query($conn, $query);

                                if (!$result) {
                                    die("Query failed: " . mysqli_error($conn));
                                }

                                if (mysqli_num_rows($result) === 0) {
                                    echo "<tr><td colspan='7'>No exam schedules found for this branch.</td></tr>";
                                } else {
                                    $invigilators_query = "SELECT user_id, username, gender FROM users WHERE branch_id = $branch_id AND role = 'Proctor'";
                                    $invigilators_result = mysqli_query($conn, $invigilators_query);

                                    if (!$invigilators_result) {
                                        die("Invigilators query failed: " . mysqli_error($conn));
                                    }

                                    $male_invigilators = [];
                                    $female_invigilators = [];
                                    while ($row = mysqli_fetch_assoc($invigilators_result)) {
                                        if ($row['gender'] === 'male') {
                                            $male_invigilators[$row['user_id']] = $row['username'];
                                        } else {
                                            $female_invigilators[$row['user_id']] = $row['username'];
                                        }
                                    }

                                    if (count($male_invigilators) < 1 || count($female_invigilators) < 1) {
                                        echo "<tr><td colspan='7'>Not enough invigilators available for this branch.</td></tr>";
                                    } else {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            $invigilator_1 = null;
                                            $invigilator_2 = null;

                                            if ($row['building_name'] == 'Male Building') {
                                                $invigilator_ids = array_keys($male_invigilators);
                                                shuffle($invigilator_ids);
                                                $invigilator_1 = $male_invigilators[$invigilator_ids[0]];
                                                $invigilator_2 = isset($invigilator_ids[1]) ? $male_invigilators[$invigilator_ids[1]] : 'N/A';
                                            } elseif ($row['building_name'] == 'Female Building') {
                                                $invigilator_ids = array_keys($female_invigilators);
                                                shuffle($invigilator_ids);
                                                $invigilator_1 = $female_invigilators[$invigilator_ids[0]];
                                                $invigilator_2 = isset($invigilator_ids[1]) ? $female_invigilators[$invigilator_ids[1]] : 'N/A';
                                            }

                                            echo "<tr>
                                                    <td>" . htmlspecialchars($row['course_name']) . "</td>
                                                    <td>" . htmlspecialchars($row['room_name']) . "</td>
                                                    <td>" . htmlspecialchars($row['exam_date_start']) . "</td>
                                                    <td>" . htmlspecialchars($row['start_time']) . "</td>
                                                    <td>" . htmlspecialchars($row['end_time']) . "</td>
                                                    <td>" . htmlspecialchars($invigilator_1) . "</td>
                                                    <td>" . htmlspecialchars($invigilator_2) . "</td>
                                                  </tr>";
                                        }
                                    }
                                }

                                mysqli_free_result($result);
                                if (isset($invigilators_result)) {
                                    mysqli_free_result($invigilators_result);
                                }
                                mysqli_close($conn);
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <button id="reassignBtn" class="btn btn-primary mt-3">Refresh Invigilators</button>
        <button name="approve_distribution" class="btn btn-success mt-3">Approve Distribution</button>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let invigilatorsData = []; // Array to hold the data

        function fetchInvigilators() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'fetch_invigilators.php', true);
            xhr.onreadystatechange = function() {
                if (xhr.readyState === XMLHttpRequest.DONE) {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        var tbody = document.querySelector('#invigilatorsTable tbody');
                        tbody.innerHTML = ''; // Clear previous data

                        if (data.error) {
                            alert(data.error);
                            return;
                        }

                        invigilatorsData = []; // Reset the array

                        data.forEach(function(invigilator) {
                            var row = document.createElement('tr');
                            row.innerHTML = `
                                <td>${invigilator.course_name}</td>
                                <td>${invigilator.room_name}</td>
                                <td>${invigilator.exam_date}</td>
                                <td>${invigilator.start_time}</td>
                                <td>${invigilator.end_time}</td>
                                <td>${invigilator.invigilator_1}</td>
                                <td>${invigilator.invigilator_2}</td>
                            `;

                            invigilatorsData.push({
                                exam_id: invigilator.exam_id,
                                invigilator_1_id: invigilator.invigilator_1_id,
                                invigilator_2_id: invigilator.invigilator_2_id,
                                branch_id: invigilator.branch_id,
                                room_id: invigilator.room_id,
                                course_id: invigilator.course_id,
                                exam_date: invigilator.exam_date,
                                start_time: invigilator.start_time,
                                end_time: invigilator.end_time
                            });
                            tbody.appendChild(row);
                        });
                    } else {
                        alert('Error fetching data: ' + xhr.status);
                    }
                }
            };
            xhr.send();
        }

        fetchInvigilators();

        document.getElementById('reassignBtn').addEventListener('click', function() {
            fetchInvigilators();
        });

        function approveDistribution() {
            if (typeof invigilatorsData !== 'undefined' && invigilatorsData.length > 0) {
                let allRequests = [];

                for (let invigilator of invigilatorsData) {
                    let dataToSend = {
                        exam_id: invigilator.exam_id || '',
                        invigilator_1_id: invigilator.invigilator_1_id || '',
                        invigilator_2_id: invigilator.invigilator_2_id || '',
                        branch_id: invigilator.branch_id || '',
                        course_id: invigilator.course_id || '',
                        assignment_date: invigilator.exam_date,
                        start_time: invigilator.start_time,
                        end_time: invigilator.end_time
                    };
                    console.log("Sending data:", dataToSend);

                    const request = new Promise((resolve, reject) => {
                        const xhr = new XMLHttpRequest();
                        xhr.open('POST', 'add_invigilators.php', true);
                        xhr.setRequestHeader('Content-Type', 'application/json');
                        xhr.onload = function() {
                            if (xhr.status >= 200 && xhr.status < 300) {
                                resolve(xhr.responseText);
                            } else {
                                reject('Request failed with status ' + xhr.status);
                            }
                        };
                        xhr.send(JSON.stringify(dataToSend));
                    });
                    allRequests.push(request);
                }

                Promise.all(allRequests)
                    .then((responses) => {
                        console.log('All requests completed successfully:', responses);
                        document.getElementById('messageDiv').innerHTML = '<div class="alert alert-success">Invigilators assigned successfully!</div>';
                        document.getElementById('messageDiv').style.display = 'block';
                    })
                    .catch((error) => {
                        console.error('One or more requests failed:', error);
                        document.getElementById('messageDiv').innerHTML = '<div class="alert alert-danger">Error assigning invigilators.</div>';
                        document.getElementById('messageDiv').style.display = 'block';
                    });
            } else {
                console.error('No invigilators data available to send.');
                document.getElementById('messageDiv').innerHTML = '<div class="alert alert-warning">No data to send.</div>';
                document.getElementById('messageDiv').style.display = 'block';
            }
        }

        document.querySelector('.btn-success').addEventListener('click', approveDistribution);
    </script>
</body>

</html>