<?php
session_start();
require_once('config/connect.php');
require_once('lang.php');

// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");


    exit();


}

// استرجاع بيانات المستخدم
$user_id = $_SESSION['user_id'];
$sql = "SELECT username, email, password_hash FROM users WHERE user_id = $user_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found";
    exit();
}

// إشعار التحديث
$updateMessage = "";

// معالجة تغيير كلمة المرور
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['current-password']) && isset($_POST['new-password'])) {
    $current_password = $_POST['current-password'];
    $new_password = $_POST['new-password'];

    // التحقق من كلمة المرور الحالية
    if (password_verify($current_password, $user['password_hash'])) {
        // تشفير كلمة المرور الجديدة
        $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);

        // تحديث كلمة المرور
        $update_password_sql = "UPDATE users SET password_hash = '$new_password_hashed' WHERE user_id = $user_id";
        if ($conn->query($update_password_sql) === TRUE) {
            $updateMessage = "Password updated successfully";
        } else {
            $updateMessage = "Error updating password: " . $conn->error;
        }
    } else {
        $updateMessage = "Current password is incorrect";
    }
}

// معالجة تحديث البيانات الأخرى
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['current-password']) && !isset($_POST['new-password'])) {
    $new_username = $conn->real_escape_string($_POST['username']);
    $new_email = $conn->real_escape_string($_POST['email']);

    // تحديث بيانات المستخدم
    $update_sql = "UPDATE users SET username = '$new_username', email = '$new_email' WHERE user_id = $user_id";
    if ($conn->query($update_sql) === TRUE) {
        $updateMessage = "Profile updated successfully";
        header("Refresh:0");
    } else {
        $updateMessage = "Error updating profile: " . $conn->error;
    }
}

// تحديد اللغة
$lang = isset($_GET['lang']) && $_GET['lang'] == 'ar' ? 'ar' : 'en';
$dir = $lang == 'ar' ? 'rtl' : 'ltr';

$role = isset($_SESSION['role']) ? $_SESSION['role'] : null;
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo $dir; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('profile_title', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .editable {
            pointer-events: none;
            opacity: 0.6;
        }
          /* تنسيق الأزرار */
          .btn-btncustomer {
            background-color: #000; /* خلفية سوداء */
            color: #fff; /* نص أبيض */
        }
        .btn-btncustomer:hover {
            background-color: #333; /* لون خلفية داكن عند التمرير */
            color: #fff; /* نص أبيض */
        }
    </style>
</head>
<body>

    <!-- Navbar with Language Switcher, Dashboard Link, and Logout -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand text-white" href="#"><?php echo getTranslation('brand', $lang, $translations); ?></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <!-- Link to Dashboard -->
                    <li class="nav-item">
                        <a class="nav-link text-white" href="index.php"><?php echo getTranslation('index', $lang, $translations); ?></a>
                    </li>
                    <!-- Language Switch -->
                    <li class="nav-item">
                        <a class="nav-link text-white" href="?lang=en">English</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="?lang=ar">العربية</a>
                    </li>
                    <!-- Logout Button -->
                    <li class="nav-item">
                        <a class="nav-link text-white" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="mb-4"><?php echo getTranslation('profile_title', $lang, $translations); ?></h1>

        <!-- Display update message -->
        <?php if ($updateMessage) : ?>
            <div class="alert alert-info"><?php echo $updateMessage; ?></div>
        <?php endif; ?>

        <form method="post" action="">
            <div class="mb-3">
                <label for="username" class="form-label"><?php echo getTranslation('username', $lang, $translations); ?></label>
                <input type="text" class="form-control editable" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required disabled>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo getTranslation('email', $lang, $translations); ?></label>
                <input type="email" class="form-control editable" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required disabled>
            </div>
            </div>
            <button type="button" class="btn btn-btncustomer" id="edit-btn"><?php echo getTranslation('edit_button', $lang, $translations); ?></button>
            <button type="submit" class="btn btn-btncustomer d-none" id="save-btn"><?php echo getTranslation('save_button', $lang, $translations); ?></button>
            <button type="button" class="btn btn-btncustomer" id="change-password-btn"><?php echo getTranslation('change_password', $lang, $translations); ?></button>
     
        </form>
    </div>

    <!-- Modal for Changing Password -->
    <div class="modal fade" id="changePasswordModal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="changePasswordModalLabel"><?php echo getTranslation('change_password', $lang, $translations); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="change-password-form" method="post" action="">
                        <div class="mb-3">
                            <label for="current-password" class="form-label"><?php echo getTranslation('current_password', $lang, $translations); ?></label>
                            <input type="password" class="form-control" id="current-password" name="current-password" required>
                        </div>
                        <div class="mb-3">
                            <label for="new-password" class="form-label"><?php echo getTranslation('new_password', $lang, $translations); ?></label>
                            <input type="password" class="form-control" id="new-password" name="new-password" required>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo getTranslation('save_password', $lang, $translations); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        const editBtn = document.getElementById('edit-btn');
        const saveBtn = document.getElementById('save-btn');
        const changePasswordBtn = document.getElementById('change-password-btn');
        const editableFields = document.querySelectorAll('.editable');

        // Enable form fields on edit button click
        editBtn.addEventListener('click', function () {
            editableFields.forEach(field => {
                field.disabled = false;
                field.classList.remove('editable');
            });
            editBtn.classList.add('d-none');
            saveBtn.classList.remove('d-none');
        });

        // Show password modal
        changePasswordBtn.addEventListener('click', function () {
            const modal = new bootstrap.Modal(document.getElementById('changePasswordModal'));
            modal.show();
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
