<?php
// تضمين ملف الترجمات
include 'lang.php';

// تعيين اللغة الافتراضية
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('about_us', $lang, $translations); ?></title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <style>
        html {
            height: 100%;
        }
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f5f5f5;
            color: #333;
        }
        /* إضافة قواعد CSS لضبط المحاذاة بناءً على اتجاه الكتابة */
body[dir="rtl"] {
    text-align: right;
}

body[dir="ltr"] {
    text-align: left;
}

header, footer {
    text-align: center;
}

ul {
    list-style-type: circle;
    margin-left: 20px;
}

body[dir="rtl"] ul {
    margin-left: 0;
    margin-right: 20px;
}

        header {
            background-color: #000;
            color: #fff;
            padding: 20px;
            text-align: center;
            height: inherit;
        }
       
        section {
            background-color: #fff;
            padding: 20px;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
       
        ul {
            list-style-type: circle;
            margin-left: 20px;
        }
        .team-member {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .team-member img {
            border-radius: 50%;
            width: 50px;
            height: 50px;
            margin-right: 15px;
        }
        footer {
            text-align: center;
            padding: 20px;
            background-color: #000;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body dir="<?php echo $lang == 'ar' ? 'rtl' : 'ltr'; ?>">


    <?php include 'config/header.php'; ?>
      



    <section>
        <h2><?php echo getTranslation('our_mission', $lang, $translations); ?></h2>
        <p><?php echo getTranslation('mission_description', $lang, $translations); ?></p>
    </section>

    <section>
        <h2><?php echo getTranslation('our_history', $lang, $translations); ?></h2>
        <p><?php echo getTranslation('history_description', $lang, $translations); ?></p>
    </section>

    <section>
        <h2><?php echo getTranslation('our_values', $lang, $translations); ?></h2>
        <ul>
            <li><?php echo getTranslation('value_student_focused', $lang, $translations); ?></li>
            <li><?php echo getTranslation('value_innovation', $lang, $translations); ?></li>
            <li><?php echo getTranslation('value_excellence', $lang, $translations); ?></li>
        </ul>
    </section>

    <section>
        <h2><?php echo getTranslation('the_team', $lang, $translations); ?> ✧</h2>
        <ul>
            <li><?php echo getTranslation('team_member_rawan', $lang, $translations); ?></li>
            <li><?php echo getTranslation('team_member_shahad', $lang, $translations); ?></li>
            <li><?php echo getTranslation('team_member_afaf', $lang, $translations); ?></li>
        </ul>
    </section>

    <?php include 'config/footer.php'; ?>

</body>
</html>
