
    <style>
        
        body {
            background: linear-gradient(45deg, #ffffff, #054e9d, #b2d6ff, #602424);
            background-size: 300% 300%;
            animation: color 12s ease-in-out infinite;
        }
        @keyframes color {
            0%, 100% { background-position: 0 50%; }
            50% { background-position: 100% 50%; }
        }
       
        .container {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 columns layout */
            gap: 20px;
            padding: 50px;
            max-width: 1440px;
            margin: auto;
            flex-grow: 1; /* Allow the container to grow */
        }
        .card {
            display: flex;
            flex-direction: column; /* Stack children vertically */
            align-items: center; /* Center children horizontally */
            justify-content: center; /* Center children vertically */
            background: white;
            border-radius: 10px;
            padding: 10px;
            text-align: center;
            box-shadow: 15px 15px 4px rgba(0, 0, 0, 0.25);
        }
        .card img {
            width: 50px; /* Image size */
            height: auto; /* Maintain aspect ratio */
            margin: 10px 0; /* Space above and below the image */
        }
        .button {
            background: #054E9D;
            color: white;
            padding: 10px 20px;
            border-radius: 22px;
            border: none;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }
        .button:hover {
            background: #043D7D;
        }
    
        .service-title {
            grid-column: 1 / -1; /* Full width for title */
            text-align: center;
            font-size: 40px;
            margin-top: 30px;
        }
        @media (max-width: 768px) {
            .container {
                grid-template-columns: repeat(2, 1fr); /* 2 columns on smaller screens */
            }
        }
        @media (max-width: 480px) {
            .container {
                grid-template-columns: 1fr; /* 1 column on mobile */
            }
        }
    </style>
 
</head>
<body>
    <?php
$role = $_SESSION['role']; ?>

    <div class="container">
        <div class="service-title">Choose your service!</div>
        <div class="card">
            <h2>Chat</h2>
            <img src="imge/chat.png" alt="Chat Image"> <!-- Placeholder for chat image -->
            <a href="selectit.php">
                <button class="button">Start</button>
            </a> <!-- Link to Proctor Chat page -->
        </div>
        <?php if ($role === 'Proctor'): ?>
        <div class="card">
            <h2>Help Request</h2>
            <a href="help_request.php">
                <img src="imge/hhelp.png" alt="Help Image"> <!-- Placeholder for help image -->
                <button class="button">Start</button>
            </a>
        </div>
    <?php elseif ($role === 'IT-Support'): ?>
        <div class="card">
            <h2>Help Request</h2>
            <a href="processreq.php">
                <img src="imge/hhelp.png" alt="Help Image"> <!-- Placeholder for help image -->
                <button class="button">Start</button>
            </a>
        </div>
    <?php else: ?>
        <div class="alert alert-warning">Unauthorized access.</div>
    <?php endif; ?>
    <?php if ($_SESSION['role'] !== 'IT-Support'): ?>
        <div class="card">
   
            <h2>Tracking Issue</h2> 
             <a href="Tracking_Issue.php">
            <img src="imge/tracking.png" alt="Tracking Image"> <!-- Placeholder for tracking image -->
            <button class="button">Start</button> 
            </a>
        </div>
        <?php endif; ?>
    
        <?php if ($_SESSION['role'] !== 'IT-Support'): ?>
    <div class="card">
        <a href="ExamInc_Report.php">
            <h2>Exam Incident Report</h2>
            <img src="imge/report.png" alt="Incident Report Image"> <!-- Placeholder for report image -->
            <button class="button">Start</button>
        </a>
    </div>
<?php endif; ?>

        <div class="card">
        <a href="Evaluation.php">
            <h2>Evaluate the Service</h2>
            <img src="imge/stars.png" alt="Evaluation Image"> <!-- Placeholder for evaluation image -->
            <button class="button">Evaluate</button>
            </a>
        </div>

 
        <?php if ($_SESSION['role'] === 'IT-Support'): ?>
            <!-- رابط لمستخدمي IT-Support للانتقال إلى صفحة مشاركة الشاشة -->
            <div class="card">
                <a href="secreen.php">
                    <h2>Screen-sharing</h2>
                    <img src="imge/share.png" alt="Screen Sharing Image"> <!-- Placeholder for screen sharing image -->
                    <button class="button">Start</button>
                </a>
            </div>
        <?php elseif ($_SESSION['role'] === 'Proctor'): ?>
            <!-- رابط لمستخدمي Proctor للانتقال إلى صفحة توليد الـ QR -->
            <div class="card">
            <a href="secreen.php">
                    <h2>Screen Sharing</h2>
                    
                    <button class="button">Generate</button>
                </a>
            </div>
        <?php endif; ?>
  
    </div>
 