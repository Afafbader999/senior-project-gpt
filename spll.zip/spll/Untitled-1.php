exam_schedules<!-- Exam Schedules Form -->
<div class="tab-pane fade" id="exam_schedules" role="tabpanel" aria-labelledby="exam_schedules-tab">
    <div class="col-md-9">
        <form action="add_exam_schedule.php" method="POST">
            <div class="mb-3">
                <label for="exam_id" class="form-label">Exam ID</label>
                <input type="number" class="form-control" id="exam_id" name="exam_id">
            </div>

            <div class="mb-3">
                <label for="branch_id" class="form-label">Branch ID</label>
                <select class="form-control" id="branch_id" name="branch_id" required onchange="fetchClassrooms(this.value)">
                    <option value=""><?php echo getTranslation('select_branch', $lang, $translations); ?></option>
                    <?php
                    // استعلام لجلب الفروع من قاعدة البيانات
                    $result = mysqli_query($conn, "SELECT branch_id, branch_name FROM branches WHERE lang = '$lang'");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value=\"{$row['branch_id']}\">{$row['branch_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3" id="classroom-container" style="display:none;">
                <label for="classroom_id" class="form-label">Classrooms</label>
                <select class="form-control" id="classroom_id" name="classroom_id">
                    <!-- سيتم ملء الغرف هنا -->
                </select>
            </div>

            <div class="mb-3">
                <label for="course_id" class="form-label">Course</label>
                <select class="form-control" id="course_id" name="course_id" required>
                    <option value=""><?php echo getTranslation('select_course', $lang, $translations); ?></option>
                    <?php
                    // استعلام لجلب الكورسات من قاعدة البيانات
                    $result = mysqli_query($conn, "SELECT course_id, course_name FROM courses");
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value=\"{$row['course_id']}\">{$row['course_name']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="semester" class="form-label"><?php echo getTranslation('semester', $lang, $translations); ?></label>
                <select class="form-control" id="semester" name="semester" required>
                    <option value=""><?php echo getTranslation('select_semester', $lang, $translations); ?></option>
                    <option value="1"><?php echo $lang == 'ar' ? 'الفصل الأول' : 'First Semester'; ?></option>
                    <option value="2"><?php echo $lang == 'ar' ? 'الفصل الثاني' : 'Second Semester'; ?></option>
                    <option value="3"><?php echo $lang == 'ar' ? 'الفصل الصيفي' : 'Summer Semester'; ?></option>
                </select>
            </div>

            <div class="mb-3">
                <label for="exam_date" class="form-label">Exam Date</label>
                <input type="date" class="form-control" id="exam_date" name="exam_date" required>
            </div>

            <div class="mb-3">
                <label for="start_time" class="form-label">Start Time</label>
                <input type="time" class="form-control" id="start_time" name="start_time" required>
            </div>

            <div class="mb-3">
                <label for="end_time" class="form-label">End Time</label>
                <input type="time" class="form-control" id="end_time" name="end_time" required>
            </div>

            <button type="submit" class="btn btn-primary mb-3">Add Exam Schedule</button>
        </form>

        <!-- Exam Schedules Table -->
        <table class="table table-striped table-hover table-responsive">
            <thead class="thead-dark">
                <tr>
                    <th>Exam ID</th>
                    <th>Branch</th>
                    <th>Classroom</th>
                    <th>Course</th>
                    <th>Semester</th>
                    <th>Exam Date</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // استعلام لجلب بيانات الاختبارات من قاعدة البيانات
                $sql = "SELECT exams.exam_id, branches.branch_name, classrooms.room_name, courses.course_name, 
                exams.semester, exams.exam_date, exams.start_time, exams.end_time 
                FROM exam_schedules as exams 
                INNER JOIN branches ON exams.branch_id = branches.branch_id 
                INNER JOIN classrooms ON exams.room_id = classrooms.room_id 
                INNER JOIN courses ON exams.course_id = courses.course_id";
        

                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['exam_id'] . "</td>";
                        echo "<td>" . $row['branch_name'] . "</td>";
                        echo "<td>" . $row['room_name'] . "</td>";
                        echo "<td>" . $row['course_name'] . "</td>";
                        echo "<td>" . ($row['semester'] == 1 ? 'First Semester' : ($row['semester'] == 2 ? 'Second Semester' : 'Summer Semester')) . "</td>";
                        echo "<td>" . $row['exam_date'] . "</td>";
                        echo "<td>" . $row['start_time'] . "</td>";
                        echo "<td>" . $row['end_time'] . "</td>";
                        echo "<td>
                                <a href='edit_exam.php?id=" . $row['exam_id'] . "' class='btn btn-secondary btn-sm'>Edit</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No exam schedules available</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
