<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];
$gender = $_SESSION['gender'];  // يتم تحديد الجنس هنا من الجلسة

// استعلام لاختيار المستخدمين بناءً على الدور والجنس
if ($role === 'IT-Support') {
    // إذا كان المستخدم هو دعم تقني، عرض المراقبين من نفس الفرع
    if ($gender == 'Female') {
        $query_users = "SELECT user_id, username FROM users WHERE role = 'Proctor' AND branch_id = ? AND gender = 'Female'";
    } else {
        $query_users = "SELECT user_id, username FROM users WHERE role = 'Proctor' AND branch_id = ?";
    }
} else {
    // إذا كان المستخدم مراقبًا، عرض دعم تكنولوجيا المعلومات من نفس الفرع
    if ($gender == 'Female') {
        $query_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ? AND gender = 'Female'";
    } else {
        $query_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ?";
    }
}

$stmt = $conn->prepare($query_users);
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result_users = $stmt->get_result();

// استعلام للحصول على حالة مشاركة الشاشة
$session_link = isset($_GET['session_link']) ? $_GET['session_link'] : ''; // الحصول على الرابط من الرابط
$query_session = "SELECT is_sharing FROM sessions WHERE session_link = ?";
$stmt_session = $conn->prepare($query_session);
$stmt_session->bind_param("s", $session_link);
$stmt_session->execute();
$result_session = $stmt_session->get_result();
$session_data = $result_session->fetch_assoc();
$is_sharing = $session_data ? $session_data['is_sharing'] : 0;  // إذا كانت المشاركة قيد التشغيل، ستعود 1
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Screen Sharing with Support</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        footer {
            text-align: center;
            background-color: #000;
            color: #fff;
            padding: 10px;
        }

        h1 {
            color: #333;
        }

        button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #startShare {
            background-color: #4CAF50;
            color: white;
        }

        #stopShare {
            background-color: #f44336;
            color: white;
        }

        #joinShare {
            background-color: #008CBA;
            color: white;
        }

        button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        video {
            margin-top: 20px;
            width: 80%;
            max-width: 600px;
            border: 2px solid #ddd;
            border-radius: 10px;
        }

        .alert {
            margin-top: 20px;
            color: red;
            font-weight: bold;
        }

        .info {
            margin-top: 20px;
            color: #4CAF50;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <?php include 'config/header.php'; ?> 
    <div class="container mt-5">
        <h1>Screen Sharing with Support</h1>

        <!-- اختيار الدعم -->
        <div class="form-group">
            <label for="supportUser">Select :</label>
            <select class="form-control" id="supportUser" name="support_user">
                <?php
                // عرض قائمة المراقبين
                while ($row = $result_users->fetch_assoc()) {
                    echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
                }
                ?>
            </select>
        </div>

        <!-- أزرار التحكم -->
        <button id="startShare" disabled>Start Screen Sharing</button>
        <button id="stopShare" disabled>Stop Sharing</button>
        <?php
        // عرض زر "Join" فقط إذا كانت المشاركة قيد التشغيل
        if ($is_sharing == 1) {
            echo '<button id="joinShare">Join Session</button>';
        } else {
            echo '<button id="joinShare" disabled>Join Session</button>';
        }
        ?>

        <video id="screenVideo" autoplay></video>

        <!-- رسائل التنبيه -->
        <div id="errorMessage" class="alert" style="display: none;"></div>
        <div id="infoMessage" class="info" style="display: none;"></div>
    </div>

    <script>
        const startShareBtn = document.getElementById("startShare");
        const stopShareBtn = document.getElementById("stopShare");
        const joinShareBtn = document.getElementById("joinShare");
        const screenVideo = document.getElementById("screenVideo");
        const supportUserSelect = document.getElementById("supportUser");
        const errorMessageDiv = document.getElementById("errorMessage");
        const infoMessageDiv = document.getElementById("infoMessage");
        let screenStream;

        // تمكين زر بدء المشاركة بعد اختيار المستخدم
        supportUserSelect.addEventListener('change', () => {
            if (supportUserSelect.value) {
                startShareBtn.disabled = false;
                infoMessageDiv.style.display = 'block';
                infoMessageDiv.textContent = "Proctor has been selected. Click 'Start Screen Sharing' to begin.";
            } else {
                startShareBtn.disabled = true;
                infoMessageDiv.style.display = 'none';
            }
        });

        // عرض رسائل الخطأ للمستخدم
        function showError(message) {
            errorMessageDiv.style.display = 'block';
            errorMessageDiv.textContent = message;
        }

        // بدء المشاركة
        startShareBtn.onclick = async () => {
            try {
                if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
                    showError("Screen sharing is not supported in this browser.");
                    return;
                }

                screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                screenVideo.srcObject = screenStream;

                // تحديث حالة الأزرار
                startShareBtn.disabled = true;
                stopShareBtn.disabled = false;
                joinShareBtn.disabled = false;
            } catch (err) {
                console.error("Error during screen sharing:", err);
                let message = "An error occurred while sharing the screen.";
                if (err.name === 'NotAllowedError') {
                    message = "Screen sharing permission was denied.";
                } else if (err.name === 'NotFoundError') {
                    message = "No screen found to share.";
                } else if (err.name === 'AbortError') {
                    message = "Screen sharing request was canceled.";
                }
                showError(message);
            }
        };

        // التوقف عن المشاركة
        stopShareBtn.onclick = () => {
            if (screenStream) {
                screenStream.getTracks().forEach(track => track.stop());
                screenVideo.srcObject = null;

                // تحديث حالة الأزرار
                startShareBtn.disabled = false;
                stopShareBtn.disabled = true;
                joinShareBtn.disabled = true;
            }
        };

        // الضغط على زر "Join" لعرض شاشة البروكتر
        joinShareBtn.onclick = () => {
            alert("Joining screen share session.");
        };
    </script>

    <?php include 'config/footer.php'; ?>
</body>
</html>