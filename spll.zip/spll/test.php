<?php
session_start();
$room_id = 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Call - Room <?php echo htmlspecialchars($room_id); ?></title>
    <script src="https://cdn.socket.io/4.0.0/socket.io.min.js"></script>
    <style>
        /* Basic styling for video elements and buttons */
        video {
            width: 45%;
            margin: 10px;
        }
        .controls {
            margin-top: 20px;
        }
        button {
            margin: 5px;
            padding: 10px 20px;
        }
    </style>
</head>
<body>
    <h2>Video Call - مكالمة فديو <?php echo htmlspecialchars($room_id); ?></h2>
    <div class="video-container">
        <video id="localVideo" autoplay playsinline></video>
        <video id="remoteVideo" autoplay playsinline></video>
    </div>
    <div class="controls">
        <button id="startCallBtn">Start Call</button>
        <button id="stopCallBtn">Stop Call</button>
    </div>

    <script>
        // JavaScript code for WebRTC
        const roomId = "<?php echo $room_id; ?>";
        const localVideo = document.getElementById('localVideo');
        const remoteVideo = document.getElementById('remoteVideo');
        const startCallBtn = document.getElementById('startCallBtn');
        const stopCallBtn = document.getElementById('stopCallBtn');
        
        // Initialize variables
        let localStream;
        let peerConnection;
        const socket = io.connect('http://localhost:3000'); // Connect to the signaling server

        // Disable the Stop button initially
        stopCallBtn.disabled = true;

        // Function to start the video call
        function startCall() {
            navigator.mediaDevices.getUserMedia({ video: true, audio: true })
                .then(stream => {
                    localVideo.srcObject = stream;
                    localStream = stream;
                    
                    // Enable Stop button and disable Start button
                    startCallBtn.disabled = true;
                    stopCallBtn.disabled = false;

                    // Join the room via signaling server
                    socket.emit('join', roomId);
                })
                .catch(error => {
                    console.error('Error accessing media devices.', error);
                });
        }

        // Function to stop the video call
        function stopCall() {
            if (localStream) {
                // Stop all media tracks
                localStream.getTracks().forEach(track => track.stop());
                localVideo.srcObject = null;
                
                // Close the peer connection if it exists
                if (peerConnection) {
                    peerConnection.close();
                    peerConnection = null;
                }

                // Leave the room
                socket.emit('leave', roomId);

                // Enable Start button and disable Stop button
                startCallBtn.disabled = false;
                stopCallBtn.disabled = true;
            }
        }

        // Handle signaling for joining the room
        socket.on('offer', (offer) => {
            peerConnection = createPeerConnection();
            peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
            
            localStream.getTracks().forEach(track => {
                peerConnection.addTrack(track, localStream);
            });

            peerConnection.createAnswer()
                .then(answer => {
                    peerConnection.setLocalDescription(answer);
                    socket.emit('answer', { answer, roomId });
                });
        });

        socket.on('answer', (answer) => {
            peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
        });

        socket.on('candidate', (candidate) => {
            peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
        });

        // Create a new PeerConnection
        function createPeerConnection() {
            const config = {
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' } // Google's public STUN server
                ]
            };
            const pc = new RTCPeerConnection(config);

            pc.onicecandidate = (event) => {
                if (event.candidate) {
                    socket.emit('candidate', { candidate: event.candidate, roomId });
                }
            };

            pc.ontrack = (event) => {
                remoteVideo.srcObject = event.streams[0];
            };

            return pc;
        }

        // When the user joins the room, create an offer
        socket.on('joined', () => {
            if (!localStream) return;

            peerConnection = createPeerConnection();

            localStream.getTracks().forEach(track => {
                peerConnection.addTrack(track, localStream);
            });

            peerConnection.createOffer()
                .then(offer => {
                    peerConnection.setLocalDescription(offer);
                    socket.emit('offer', { offer, roomId });
                });
        });

        // Event listeners for the Start and Stop buttons
        startCallBtn.addEventListener('click', startCall);
        stopCallBtn.addEventListener('click', stopCall);

        // Handle leave event
        socket.on('leave', () => {
            if (peerConnection) {
                peerConnection.close();
                peerConnection = null;
            }
            remoteVideo.srcObject = null;
        });
    </script>
</body>
</html>
