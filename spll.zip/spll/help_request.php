<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// التأكد أن المستخدم هو مراقب
if ($role !== 'Proctor') {
    echo "You do not have permission to submit a help request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('brand', $lang, $translations); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <!-- Include jQuery -->
    <style>
       footer {
    height: 80px;
    background-color: #ffffff; /* Set the footer background color */
    padding: 10px; /* Padding inside the footer */
    text-align: center; /* Center the footer text */
    color: white; /* Change text color to white */
}
html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1; /* This allows the container to grow and fill the available space */
}
.btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }
        .btn-primary:hover {
    background-color: #000; /* Keep background color black on hover */
    color: #fff; /* Keep text color white on hover */
    opacity: 0.8; /* Optional: Change opacity on hover for effect */
}


    </style>
</head>
<body>
    
<?php include 'config/header.php'; ?>
<div class="container mt-5">
    <h2>Submit Help Request</h2>

    <div id="response_message"></div> <!-- هنا لعرض رسالة النجاح أو الخطأ -->

    <form id="helpRequestForm">
        <div class="form-group">
            <label for="type_help">Type of Help</label>
            <select class="form-control" id="type_help" name="type_help" required>
                <option value="Technical problem">Technical problem</option>
                <option value="Request papers">Request papers</option>
                <option value="Pens">Pens</option>
                <option value="Battery">Battery</option>
                <option value="Other">Other</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Submit Request</button>
        

    </form>
</div>
<br>
<br>
<?php include 'config/footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#helpRequestForm').on('submit', function(event) {
            event.preventDefault(); // منع إعادة تحميل الصفحة
            
            $.ajax({
                url: 'submit_help_request.php', // صفحة معالجة الطلب
                type: 'POST',
                data: $(this).serialize(), // تحويل بيانات النموذج إلى سلسلة
                success: function(response) {
                    $('#response_message').html(response); // عرض الاستجابة
                },
                error: function() {
                    $('#response_message').html('<div class="alert alert-danger">Error submitting request.</div>');
                }
            });
        });
    });
</script>

</body>
</html>
