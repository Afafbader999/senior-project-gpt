<?php
session_start();

// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // إعادة توجيه المستخدم لصفحة تسجيل الدخول
    exit();
}

// تضمين ملف الترجمة
include 'lang.php';

// تحديد اللغة
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; // افتراضياً اللغة الإنجليزية
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
// Check if the session is valid
if (!isset($_SESSION['branch_id'])) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}

// Get the branch ID from the session
$branch_id = intval($_SESSION['branch_id']);
?>

<!DOCTYPE html>
<html lang="<?php  
echo ($lang == 'ar') ? 'ar' : 'en'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('dashboard', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }

        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
            transition: width 0.3s;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .dashboard-header {
            background-color: #000;
            color: white;
            padding: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }

        .dashboard-content {
            margin-top: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }

        .content-section {
            padding: 20px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }

            .dashboard-header,
            .dashboard-content {
                margin: 0;
            }
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
            /* ضبط محاذاة النص */
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>margin-left: 15px;
            /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>margin-right: 15px;
            /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .navbar .dropdown-menu a {
            color: black;
        }

        .btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }

        .nav-link:hover {
            background-color: #0000;
            /* لون أزرق غامق عند التحويم */
            color: #ffffff;
            /* تأكيد على بقاء النص باللون الأبيض */
        }
    </style>
</head>

<body>

    <?php include 'sidebar.php'; ?>

    <!-- Header -->
    <div class="container dashboard-content">
        <div class="row">
        <div id="message" style="color: red;"></div>

            <!-- Toast Container -->
            <div class="toast-container position-fixed top-50 end-50 p-3">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                            <strong class="me-auto">Notification</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            <?php
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Nav Tabs -->
            <ul class="nav nav-tabs p-1 text-white shadow bg-dark rounded" id="myTab" role="tablist" style="border-width: 4px; border-style: solid;">
             
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="courses-tab" data-bs-toggle="tab" href="#courses" role="tab" aria-controls="courses" aria-selected="false">Courses</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="classrooms-tab" data-bs-toggle="tab" href="#classrooms" role="tab" aria-controls="classrooms" aria-selected="false">Classrooms</a>
                </li>
                
               
            </ul>

            <!-- Tab Content -->

            <div class="tab-content mt-4" id="myTabContent">
                <!-- Branches Form -->
         
                <!-- Classrooms Form -->
        

                <!-- Courses Form -->
                <div class="tab-pane fade show active" id="courses" role="tabpanel" aria-labelledby="courses-tab">
                    <div class="col-md-9">
                        <form action="add_course.php" method="POST">
                            <div class="mb-3">
                                <label for="course_name" class="form-label"><?php echo getTranslation('course_name', $lang, $translations); ?></label>
                                <input type="text" class="form-control" id="course_name" name="course_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="course_code" class="form-label"><?php echo getTranslation('course_code', $lang, $translations); ?></label>
                                <input type="text" class="form-control" id="course_code" name="course_code" required>
                            </div>
                            <button type="submit" class="btn btn-primary mb-3"><?php echo getTranslation('add_course', $lang, $translations); ?></button>
                        </form>
                    </div>

                    <h4 class="mt-4"><?php echo getTranslation('existing_courses', $lang, $translations); ?></h4>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th><?php echo getTranslation('course_name', $lang, $translations); ?></th>
                                    <th><?php echo getTranslation('course_code', $lang, $translations); ?></th>
                                    <th><?php echo getTranslation('actions', $lang, $translations); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // استعلام لجلب بيانات الكورسات من قاعدة البيانات
                                include 'config/connect.php';
                                $sql = "SELECT course_id, course_name, course_code FROM courses";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row['course_name'] . "</td>";
                                        echo "<td>" . $row['course_code'] . "</td>";
                                        echo "<td>
                                            <a href='edit_course.php?id=" . $row['course_id'] . "' class='btn btn-secondary btn-block'>Edit</a>
                                          </td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='3'>" . getTranslation('no_courses_found', $lang, $translations) . "</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
       

<div class="tab-pane fade" id="classrooms" role="tabpanel" aria-labelledby="classrooms-tab">
                    <div class="col-md-9">
                        <form action="add_classroom.php" method="POST">
                            <!-- Branch ID -->
                            <div class="mb-3">
                                <label for="branch_id" class="form-label">Branch ID</label>
                                <select class="form-control" id="branch_id" name="branch_id" required>
                                    <option value=""><?php echo getTranslation('select_branch', $lang, $translations); ?></option>
                                    <?php
                                    $result = mysqli_query($conn, "SELECT branch_id, branch_name FROM branches WHERE branch_id='$branch_id' and lang = '$lang'");
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<option value=\"{$row['branch_id']}\">{$row['branch_name']}</option>";
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Room Name -->
                            <div class="mb-3">
                                <label for="room_name" class="form-label">Room Name</label>
                                <input type="text" class="form-control" id="room_name" name="room_name" required>
                            </div>

                            <!-- Building Name -->
                            <div class="mb-3">
                                <label for="building_name" class="form-label"><?php echo getTranslation('building_name', $lang, $translations); ?></label>
                                <select class="form-control" id="building_name" name="building_name" required>
                                    <option value=""><?php echo getTranslation('select_building', $lang, $translations); ?></option>
                                    <?php
                                    if ($lang == 'ar') {
                                        echo '<option value="female\' Building">مبنى البنات</option>';
                                        echo '<option value="male\' Building">مبنى العيال</option>';
                                    } else {
                                        echo '<option value="female\' Building">female\' Building</option>';
                                        echo '<option value="male\' Building">male\' Building</option>';
                                    }
                                    ?>
                                </select>
                            </div>

                            <!-- Capacity -->
                            <div class="mb-3">
                                <label for="capacity" class="form-label">Capacity</label>
                                <input type="number" class="form-control" id="capacity" name="capacity" required>
                            </div>

                            <!-- Floor -->
                            <div class="mb-3">
                                <label for="floor" class="form-label"><?php echo getTranslation('floor', $lang, $translations); ?></label>
                                <select class="form-control" id="floor" name="floor" required>
                                    <option value=""><?php echo getTranslation('select_floor', $lang, $translations); ?></option>
                                    <option value="1"><?php echo ($lang == 'ar') ? 'الطابق الأول' : 'First Floor'; ?></option>
                                    <option value="2"><?php echo ($lang == 'ar') ? 'الطابق الثاني' : 'Second Floor'; ?></option>
                                    <option value="3"><?php echo ($lang == 'ar') ? 'الطابق الثالث' : 'Third Floor'; ?></option>
                                </select>
                            </div>

                            <!-- Room Type -->
                            <div class="mb-3">
                                <label for="room_type" class="form-label"><?php echo getTranslation('room_type', $lang, $translations); ?></label>
                                <select class="form-control" id="room_type" name="room_type" required>
                                    <option value=""><?php echo getTranslation('select_room_type', $lang, $translations); ?></option>
                                    <option value="Lecture Room"><?php echo ($lang == 'ar') ? 'غرفة محاضرات' : 'Lecture Room'; ?></option>
                                    <option value="Lab"><?php echo ($lang == 'ar') ? 'معمل' : 'Lab'; ?></option>
                                    <option value="Office"><?php echo ($lang == 'ar') ? 'مكتب' : 'Office'; ?></option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-secondary mb-3">Add Classroom</button>
                        </form>
                    </div>

                    <!-- عرض بيانات القاعات تحت النموذج -->
                    <div class="col-md-12 mt-5">
                        <h3>Classroom List</h3>
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered">
                                <thead class="table-dark">
                                    <tr>
                                        <th>Room Name</th>
                                        <th>Building Name</th>
                                        <th>Capacity</th>
                                        <th>Floor</th>
                                        <th>Room Type</th>
                                        <th>Branch ID</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // استعلام لجلب بيانات القاعات وأسماء الفروع من قاعدة البيانات
                                    $sql = "SELECT classrooms.room_id, classrooms.room_name, classrooms.building_name, classrooms.capacity, classrooms.floor, classrooms.room_type, branches.branch_name 
                                        FROM classrooms 
                                        INNER JOIN branches ON classrooms.branch_id = branches.branch_id
                                        WHERE branches.branch_id='$branch_id' 
                                        ";
                                    $result = mysqli_query($conn, $sql);

                                    if (mysqli_num_rows($result) > 0) {
                                        while ($row = mysqli_fetch_assoc($result)) {
                                            echo "<tr>";
                                            echo "<td>" . $row['room_name'] . "</td>";
                                            echo "<td>" . $row['building_name'] . "</td>";
                                            echo "<td>" . $row['capacity'] . "</td>";
                                            echo "<td>" . $row['floor'] . "</td>";
                                            echo "<td>" . $row['room_type'] . "</td>";
                                            // عرض اسم الفرع بدلاً من رقم الفرع
                                            echo "<td>" . $row['branch_name'] . "</td>";
                                            echo "<td>
                                                <a href='edit_classroom.php?id=" . $row['room_id'] . "' class='btn btn-secondary btn-sm'>Edit</a>
                                              </td>";
                                            echo "</tr>";
                                        }
                                    } else {
                                        echo "<tr><td colspan='7'>No classrooms available</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    </div>
                </div>
            </div>


     
 
           
                    

                    <script>
                        document.addEventListener('DOMContentLoaded', () => {
                            const toastEl = document.querySelector('.toast');
                            if (toastEl) {
                                const bsToast = new bootstrap.Toast(toastEl);
                                setTimeout(() => {
                                    bsToast.hide();
                                }, 3000);
                            }
                        });

                    </script>
                   

                    <?php include 'config/footer.php'; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
