-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2024 at 09:28 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spll_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(500) NOT NULL,
  `city` varchar(100) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`branch_id`, `branch_name`, `city`, `address`, `phone_number`, `email`, `lang`, `created_at`) VALUES
(1, 'Riyadh Branch', 'Riyadh', 'Abu Bakr Al-Siddiq Road, intersection of Prince Mohammed bin Salman Road, Main Campus', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(2, 'Jeddah Branch', 'Jeddah', 'Jeddah University Girls College, Al-Faisaliah District, Building No. 14', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(3, 'Madinah Branch', 'Madinah', 'Taibah University, Abar Ali site', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(4, 'Dammam Branch', 'Dammam', 'Saudi Electronic University, Al-Rayyan District, behind Girls College at University of Dammam', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(5, 'Qassim Branch', 'Qassim ', 'Qassim University, Al-Mulaida District, Planning Building', '', '', 'en', '2024-10-06 23:38:18'),
(6, 'Al-Ahsa Branch', 'Al-Ahsa', 'Gulf Road', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(7, 'Tabuk Branch', 'Tabuk', 'College of Energy, Research College, Tabuk University, Duba Road', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(8, 'Abha Branch', 'Abha', 'Saudi Electronic University, King Khalid University Branch, Al-Quraiqir District, Building A', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(9, 'Jazan Branch', 'Jazan', 'Saudi Electronic University branch, Al-Madinah School, Annual Plan Building', NULL, NULL, 'en', '2024-10-06 23:38:18'),
(10, 'Al-Ula Branch', 'Al-Ula  ', 'Branch headquarters University branch location in Al-Ula (male and female)', 'eeeeeeeeeeeee', 'najran@ssss.com', 'en', '2024-10-14 19:53:42'),
(11, 'Al-Qurayyat branch ', 'Al-Jawf', 'The university branch in Qurayyat was launched to create university educational opportunities and provide an academic environment using the latest modern technologies to achieve pioneering and distinguished outputs that serve the community in Qurayyat.', '', '', 'en', '2024-10-16 02:48:36'),
(12, 'Hail Branch', 'Hail ', 'The students  headquarters are located in the College of Computer Science and Engineering at Hail University', '', '', 'en', '2024-10-16 02:58:32'),
(13, 'Najran branch', 'Najran ', 'The student headquarters is located in the College of Computer Science at Najran University.', '', '', 'en', '2024-10-16 03:00:45'),
(14, 'Jubail Branch', 'Jubail ', 'Jubail University College', '', '', 'en', '2024-10-16 03:04:37'),
(15, 'Yanbu Branch', 'Yanbu ', 'Yanbu University College ', '', '', 'en', '2024-10-16 03:08:10');

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `chat_id` int(11) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `sender_user_id` int(11) DEFAULT NULL,
  `Recipient_id` int(11) NOT NULL,
  `Branch_id` int(11) NOT NULL,
  `message_content` text NOT NULL,
  `sent_at` datetime DEFAULT current_timestamp(),
  `day_date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `classrooms`
--

CREATE TABLE `classrooms` (
  `room_id` int(11) NOT NULL,
  `room_name` varchar(100) NOT NULL,
  `building_name` varchar(100) DEFAULT NULL,
  `capacity` int(11) NOT NULL,
  `floor` varchar(100) DEFAULT NULL,
  `room_type` varchar(50) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `classrooms`
--

INSERT INTO `classrooms` (`room_id`, `room_name`, `building_name`, `capacity`, `floor`, `room_type`, `branch_id`, `created_at`) VALUES
(2, 'F33', 'Female\' Building', 35, '2', 'Lecture ', 1, '2024-10-07 00:01:32'),
(3, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(4, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(5, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(6, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(7, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(8, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(9, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(10, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 1, '2024-10-07 00:01:32'),
(11, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(12, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(13, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(14, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(15, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(16, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(17, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(18, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(19, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(20, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 2, '2024-10-07 00:01:32'),
(21, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(22, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(23, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(24, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(25, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(26, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(27, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(28, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(29, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(30, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 3, '2024-10-07 00:01:32'),
(31, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(32, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(33, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(34, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(35, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(36, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(37, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(38, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(39, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(40, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 4, '2024-10-07 00:01:32'),
(41, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(42, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(43, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(44, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(45, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(46, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(47, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(48, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(49, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(50, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 5, '2024-10-07 00:01:32'),
(51, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(52, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(53, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(54, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(55, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(56, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(57, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(58, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(59, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(60, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 6, '2024-10-07 00:02:21'),
(61, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(62, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(63, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(64, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(65, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(66, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(67, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(68, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(69, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(70, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 7, '2024-10-07 00:02:21'),
(71, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(72, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(73, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(74, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(75, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(76, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(77, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(78, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(79, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(80, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 8, '2024-10-07 00:02:21'),
(81, 'F1', 'Male Building', 30, '1st Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(82, 'F2', 'Female Building', 35, '1st Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(83, 'F3', 'Male Building', 40, '2nd Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(84, 'F4', 'Female Building', 25, '2nd Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(85, 'F5', 'Male Building', 50, '3rd Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(86, 'F6', 'Female Building', 45, '3rd Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(87, 'F7', 'Male Building', 60, '4th Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(88, 'F8', 'Female Building', 55, '4th Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(89, 'F9', 'Male Building', 65, '5th Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(90, 'F10', 'Female Building', 70, '5th Floor', 'Lecture Room', 9, '2024-10-07 00:02:21'),
(92, '5', 'Female\' Building', 22, '1', 'Lecture Room', 1, '2024-12-03 20:06:52');

-- --------------------------------------------------------

--
-- Table structure for table `college`
--

CREATE TABLE `college` (
  `College_id` int(11) NOT NULL,
  `College_name` varchar(250) NOT NULL,
  `branch_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `college`
--

INSERT INTO `college` (`College_id`, `College_name`, `branch_id`) VALUES
(1, 'College of Administrative and Financial Sciences', 1),
(2, 'College of Administrative and Financial Sciences', 2),
(3, 'College of Administrative and Financial Sciences', 3),
(4, 'College of Administrative and Financial Sciences', 4),
(5, 'College of Computing and Informatics', 1),
(6, 'College of Computing and Informatics', 2),
(7, 'College of Computing and Informatics', 3),
(8, 'College of Computing and Informatics', 4),
(9, 'College of Health Sciences', 1),
(10, 'College of Health Sciences', 2),
(11, 'College of Health Sciences', 3),
(12, 'College of Health Sciences', 4),
(13, 'College of Science and Theoretical Studies', 1),
(14, 'College of Science and Theoretical Studies', 2),
(15, 'College of Science and Theoretical Studies', 3),
(16, 'College of Science and Theoretical Studies', 4);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(150) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `course_code`, `created_at`) VALUES
(1, 'English language Skills', 'ENG001', '2024-10-07 00:29:25'),
(2, 'Computer Essentials', 'CS001', '2024-10-07 00:29:25'),
(3, 'Communication Skills', 'COMM001', '2024-10-07 00:29:25'),
(4, 'Fundamentals of Math', 'MATH001', '2024-10-07 00:29:25'),
(5, 'Academic Skills', 'CI001', '2024-10-07 00:29:25'),
(6, 'Computer Programming I', 'CS140', '2024-10-07 00:29:25'),
(7, 'Introduction to IT & IS', 'IT101', '2024-10-07 00:29:25'),
(8, 'Discrete Mathematics', 'MATH150', '2024-10-07 00:29:25'),
(9, 'Technical Writing', 'ENG103', '2024-10-07 00:29:25'),
(10, 'Computer Organization', 'IT110', '2024-10-07 00:29:25'),
(11, 'Islamic Culture (1)', 'ISLM101', '2024-10-07 00:29:25'),
(12, 'Computer Programming II', 'CS141', '2024-10-07 00:29:25'),
(13, 'Linear Algebra', 'MATH251', '2024-10-07 00:29:25'),
(14, 'Software Engineering', 'IT242', '2024-10-07 00:29:25'),
(15, 'Operating Systems', 'IT241', '2024-10-07 00:29:25'),
(16, 'Principles of Management', 'MGT101', '2024-10-07 00:29:25'),
(17, 'Islamic Culture 2', 'ISLM102', '2024-10-07 00:29:25'),
(18, 'System Analysis and Design', 'IT243', '2024-10-07 00:29:25'),
(19, 'Introduction to Database', 'IT244', '2024-10-07 00:29:25'),
(20, 'Human Computer Interaction', 'IT201', '2024-10-07 00:29:25'),
(21, 'Computer Networks', 'IT210', '2024-10-07 00:29:25'),
(22, 'Statistics', 'STAT101', '2024-10-07 00:29:25'),
(23, 'Database Management Systems', 'IT344', '2024-10-07 00:29:25'),
(24, 'Web Technologies', 'IT230', '2024-10-07 00:29:25'),
(25, 'IT Project Management', 'IT270', '2024-10-07 00:29:25'),
(26, 'Network Management', 'IT340', '2024-10-07 00:29:25'),
(27, 'E-Commerce', 'E-COM101', '2024-10-07 00:29:25'),
(28, 'Islamic Culture 3', 'ISLM103', '2024-10-07 00:29:25'),
(29, 'Practical Training', 'IT499', '2024-10-07 00:29:25'),
(30, 'Senior Project I', 'IT490', '2024-10-07 00:29:25'),
(31, 'System Integration', 'IT440', '2024-10-07 00:29:25'),
(32, 'Enterprise Systems', 'IT342', '2024-10-07 00:29:25'),
(33, 'Data Mining & Data Warehousing', 'IT446', '2024-10-07 00:29:25'),
(34, 'Mobile Application Development', 'IT448', '2024-10-07 00:29:25'),
(35, 'Islamic Culture 4', 'ISLM104', '2024-10-07 00:29:25'),
(36, 'Senior Project II', 'IT491', '2024-10-07 00:29:25'),
(37, 'Decision Support Systems', 'IT445', '2024-10-07 00:29:25'),
(38, 'Multimedia Systems Development', 'IT441', '2024-10-07 00:29:25'),
(39, 'Professional Issues', 'IT407', '2024-10-07 00:29:25'),
(40, 'IT Security and Policies', 'IT409', '2024-10-07 00:29:25'),
(41, 'Mobile Computing', 'CS475', '2024-10-07 00:30:58'),
(42, 'Parallel and Distributed Computing', 'CS476', '2024-10-07 00:30:58'),
(43, 'Compiler Design', 'CS477', '2024-10-07 00:30:58'),
(44, 'Computer Graphics', 'CS478', '2024-10-07 00:30:58'),
(45, 'Game Architecture and Design', 'CS485', '2024-10-07 00:30:58'),
(46, '2D Game Programming', 'CS486', '2024-10-07 00:30:58'),
(47, '3D Game Programming', 'CS487', '2024-10-07 00:30:58'),
(48, 'Game Artificial Intelligence', 'CS488', '2024-10-07 00:30:58'),
(53, 'English Language Skills 2', 'ENG002', '2024-10-07 00:41:07'),
(55, 'General Physics 1', 'SCI 101', '2024-10-07 00:41:07'),
(56, 'Object Oriented Programming', 'DS230', '2024-10-07 00:41:07'),
(59, 'Introduction to Data Science Programming', 'DS231', '2024-10-07 00:41:07'),
(62, 'Data Structure', 'DS240', '2024-10-07 00:41:07'),
(63, 'Calculus', 'MATH241', '2024-10-07 00:41:07'),
(64, 'Advanced Data Science Programming', 'DS242', '2024-10-07 00:41:07'),
(65, 'Computer Architecture and Organization', 'DS243', '2024-10-07 00:41:07'),
(67, 'General Physics 2', 'SCI 201', '2024-10-07 00:41:07'),
(68, 'Introduction to Database', 'DS350', '2024-10-07 00:41:07'),
(69, 'Operating Systems', 'DS351', '2024-10-07 00:41:07'),
(70, 'Introduction to Statistics and Probabilities', 'STAT202', '2024-10-07 00:41:07'),
(71, 'Design and Analysis of Algorithms', 'DS352', '2024-10-07 00:41:07'),
(72, 'Project Management in Computing', 'DS353', '2024-10-07 00:41:07'),
(73, 'Computer Networks', 'DS360', '2024-10-07 00:41:07'),
(74, 'System Analysis and Design', 'DS361', '2024-10-07 00:41:07'),
(75, 'Web Programming', 'DS362', '2024-10-07 00:41:07'),
(76, 'Artificial Intelligence', 'DS363', '2024-10-07 00:41:07'),
(80, 'Data Security and Privacy', 'DS470', '2024-10-07 00:41:07'),
(81, 'Machine Learning', 'DS471', '2024-10-07 00:41:07'),
(82, 'Data Mining', 'DS472', '2024-10-07 00:41:07'),
(83, 'Senior Project 1', 'DS479', '2024-10-07 00:41:07'),
(84, 'Computer Vision', 'DS473', '2024-10-07 00:41:07'),
(85, 'Decision Support Systems', 'DS474', '2024-10-07 00:41:07'),
(86, 'Deep Learning', 'DS482', '2024-10-07 00:41:07'),
(87, 'Natural Language Processing', 'DS483', '2024-10-07 00:41:07'),
(88, 'Big Data Modelling', 'DS475', '2024-10-07 00:41:07'),
(89, 'Big Data Integration and Processing', 'DS476', '2024-10-07 00:41:07'),
(90, 'Big Data Optimization', 'DS484', '2024-10-07 00:41:07'),
(91, 'Business Intelligence', 'DS485', '2024-10-07 00:41:07'),
(92, 'a', 'aaaaa', '2024-10-21 10:12:17'),
(93, 'Islam101', '11', '2024-12-01 13:18:19');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Department_id` int(11) NOT NULL,
  `Department` varchar(300) NOT NULL,
  `collage_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Department_id`, `Department`, `collage_id`) VALUES
(1, 'Department of Business Administration', 1),
(2, 'Department of Business Administration', 2),
(3, 'Department of Business Administration', 3),
(4, 'Department of Business Administration', 4),
(5, 'Department of Accounting', 1),
(6, 'Department of Accounting', 2),
(7, 'Department of Accounting', 3),
(8, 'Department of Accounting', 4),
(9, 'Department of Finance', 1),
(10, 'Department of Finance', 2),
(11, 'Department of Finance', 3),
(12, 'Department of Finance', 4),
(13, 'Department of E-Commerce', 1),
(14, 'Department of E-Commerce', 2),
(15, 'Department of E-Commerce', 3),
(16, 'Department of E-Commerce', 4);

-- --------------------------------------------------------

--
-- Table structure for table `exam_assignments`
--

CREATE TABLE `exam_assignments` (
  `assignment_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `porit_id` int(11) NOT NULL,
  `role` varchar(30) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `assignment_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `exam_assignments`
--

INSERT INTO `exam_assignments` (`assignment_id`, `exam_id`, `porit_id`, `role`, `branch_id`, `room_id`, `course_id`, `assignment_date`, `start_time`, `end_time`) VALUES
(41, 2, 11, 'Proctor', 1, 10, 1, '2024-12-19', '18:00:00', '21:00:00'),
(43, 2, 11, 'Proctor', 1, 2, 9, '2024-12-20', '16:00:00', '17:00:00'),
(44, 2, 12, 'Proctor', 1, 2, 9, '2024-12-20', '16:00:00', '17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `exam_schedules`
--

CREATE TABLE `exam_schedules` (
  `schedule_id` int(11) NOT NULL,
  `exam_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `exam_date_start` date NOT NULL,
  `exam_date_end` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `semester` varchar(40) NOT NULL,
  `College` int(11) NOT NULL,
  `Department` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `exam_schedules`
--

INSERT INTO `exam_schedules` (`schedule_id`, `exam_id`, `branch_id`, `course_id`, `exam_date_start`, `exam_date_end`, `start_time`, `end_time`, `semester`, `College`, `Department`) VALUES
(1, 1, 1, 1, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(2, 1, 2, 2, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(3, 1, 3, 3, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(4, 1, 4, 4, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(5, 1, 1, 5, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(6, 1, 2, 6, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(7, 1, 3, 7, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(8, 1, 4, 8, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(9, 1, 1, 9, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(10, 1, 2, 10, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(11, 1, 3, 11, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(12, 1, 4, 12, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(13, 1, 1, 13, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(14, 1, 2, 14, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(15, 1, 3, 15, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(16, 1, 4, 16, '2024-10-17', '2024-10-17', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(17, 1, 1, 1, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(18, 1, 2, 2, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(19, 1, 3, 3, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(20, 1, 4, 4, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(21, 1, 1, 5, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(22, 1, 2, 6, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(23, 1, 3, 7, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(24, 1, 4, 8, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(25, 1, 1, 9, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(26, 1, 2, 10, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(27, 1, 3, 11, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(28, 1, 4, 12, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(29, 1, 1, 13, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(30, 1, 2, 14, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(31, 1, 3, 15, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(32, 1, 4, 16, '2024-10-17', '2024-10-17', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(33, 1, 1, 1, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(34, 1, 2, 2, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(35, 1, 3, 3, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(36, 1, 4, 4, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(37, 1, 1, 5, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(38, 1, 2, 6, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(39, 1, 3, 7, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(40, 1, 4, 8, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(41, 1, 1, 9, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(42, 1, 2, 10, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(43, 1, 3, 11, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(44, 1, 4, 12, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(45, 1, 1, 13, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(46, 1, 2, 14, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(47, 1, 3, 15, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(48, 1, 4, 16, '2024-10-17', '2024-10-17', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(49, 1, 1, 1, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(50, 1, 2, 2, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(51, 1, 3, 3, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(52, 1, 4, 4, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(53, 1, 1, 5, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(54, 1, 2, 6, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(55, 1, 3, 7, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(56, 1, 4, 8, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(57, 1, 1, 9, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(58, 1, 2, 10, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(59, 1, 3, 11, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(60, 1, 4, 12, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(61, 1, 1, 13, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(62, 1, 2, 14, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(63, 1, 3, 15, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(64, 1, 4, 16, '2024-10-17', '2024-10-17', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(65, 1, 1, 1, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(66, 1, 2, 2, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(67, 1, 3, 3, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(68, 1, 4, 4, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(69, 1, 1, 5, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(70, 1, 2, 6, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(71, 1, 3, 7, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(72, 1, 4, 8, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(73, 1, 1, 9, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(74, 1, 2, 10, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(75, 1, 3, 11, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(76, 1, 4, 12, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(77, 1, 1, 13, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(78, 1, 2, 14, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(79, 1, 3, 15, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(80, 1, 4, 16, '2024-10-18', '2024-10-18', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(81, 1, 1, 1, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(82, 1, 2, 2, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(83, 1, 3, 3, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(84, 1, 4, 4, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(85, 1, 1, 5, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(86, 1, 2, 6, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(87, 1, 3, 7, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(88, 1, 4, 8, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(89, 1, 1, 9, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(90, 1, 2, 10, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(91, 1, 3, 11, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(92, 1, 4, 12, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(93, 1, 1, 13, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(94, 1, 2, 14, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(95, 1, 3, 15, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(96, 1, 4, 16, '2024-10-18', '2024-10-18', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(97, 1, 1, 1, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(98, 1, 2, 2, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(99, 1, 3, 3, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(100, 1, 4, 4, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(101, 1, 1, 5, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(102, 1, 2, 6, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(103, 1, 3, 7, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(104, 1, 4, 8, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(105, 1, 1, 9, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(106, 1, 2, 10, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(107, 1, 3, 11, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(108, 1, 4, 12, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(109, 1, 1, 13, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(110, 1, 2, 14, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(111, 1, 3, 15, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(112, 1, 4, 16, '2024-10-18', '2024-10-18', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(113, 1, 1, 1, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(114, 1, 2, 2, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(115, 1, 3, 3, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(116, 1, 4, 4, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(117, 1, 1, 5, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(118, 1, 2, 6, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(119, 1, 3, 7, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(120, 1, 4, 8, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(121, 1, 1, 9, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(122, 1, 2, 10, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(123, 1, 3, 11, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(124, 1, 4, 12, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(125, 1, 1, 13, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(126, 1, 2, 14, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(127, 1, 3, 15, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(128, 1, 4, 16, '2024-10-18', '2024-10-18', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(129, 1, 1, 1, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(130, 1, 2, 2, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(131, 1, 3, 3, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(132, 1, 4, 4, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(133, 1, 1, 5, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(134, 1, 2, 6, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(135, 1, 3, 7, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(136, 1, 4, 8, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(137, 1, 1, 9, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(138, 1, 2, 10, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(139, 1, 3, 11, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(140, 1, 4, 12, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(141, 1, 1, 13, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(142, 1, 2, 14, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(143, 1, 3, 15, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(144, 1, 4, 16, '2024-10-19', '2024-10-19', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(145, 1, 1, 1, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(146, 1, 2, 2, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(147, 1, 3, 3, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(148, 1, 4, 4, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(149, 1, 1, 5, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(150, 1, 2, 6, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(151, 1, 3, 7, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(152, 1, 4, 8, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(153, 1, 1, 9, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(154, 1, 2, 10, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(155, 1, 3, 11, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(156, 1, 4, 12, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(157, 1, 1, 13, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(158, 1, 2, 14, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(159, 1, 3, 15, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(160, 1, 4, 16, '2024-10-19', '2024-10-19', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(161, 1, 1, 1, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(162, 1, 2, 2, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(163, 1, 3, 3, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(164, 1, 4, 4, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(165, 1, 1, 5, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(166, 1, 2, 6, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(167, 1, 3, 7, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(168, 1, 4, 8, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(169, 1, 1, 9, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(170, 1, 2, 10, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(171, 1, 3, 11, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(172, 1, 4, 12, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(173, 1, 1, 13, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(174, 1, 2, 14, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(175, 1, 3, 15, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(176, 1, 4, 16, '2024-10-19', '2024-10-19', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(177, 1, 1, 1, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(178, 1, 2, 2, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(179, 1, 3, 3, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(180, 1, 4, 4, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(181, 1, 1, 5, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(182, 1, 2, 6, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(183, 1, 3, 7, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(184, 1, 4, 8, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(185, 1, 1, 9, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(186, 1, 2, 10, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(187, 1, 3, 11, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(188, 1, 4, 12, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(189, 1, 1, 13, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(190, 1, 2, 14, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(191, 1, 3, 15, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(192, 1, 4, 16, '2024-10-19', '2024-10-19', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(193, 1, 1, 1, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(194, 1, 2, 2, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(195, 1, 3, 3, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(196, 1, 4, 4, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(197, 1, 1, 5, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(198, 1, 2, 6, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(199, 1, 3, 7, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(200, 1, 4, 8, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(201, 1, 1, 9, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(202, 1, 2, 10, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(203, 1, 3, 11, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(204, 1, 4, 12, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(205, 1, 1, 13, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(206, 1, 2, 14, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(207, 1, 3, 15, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(208, 1, 4, 16, '2024-10-20', '2024-10-20', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(209, 1, 1, 1, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(210, 1, 2, 2, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(211, 1, 3, 3, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(212, 1, 4, 4, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(213, 1, 1, 5, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(214, 1, 2, 6, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(215, 1, 3, 7, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(216, 1, 4, 8, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(217, 1, 1, 9, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(218, 1, 2, 10, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(219, 1, 3, 11, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(220, 1, 4, 12, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(221, 1, 1, 13, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(222, 1, 2, 14, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(223, 1, 3, 15, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(224, 1, 4, 16, '2024-10-20', '2024-10-20', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(225, 1, 1, 1, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(226, 1, 2, 2, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(227, 1, 3, 3, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(228, 1, 4, 4, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(229, 1, 1, 5, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(230, 1, 2, 6, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(231, 1, 3, 7, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(232, 1, 4, 8, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(233, 1, 1, 9, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(234, 1, 2, 10, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(235, 1, 3, 11, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(236, 1, 4, 12, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(237, 1, 1, 13, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(238, 1, 2, 14, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(239, 1, 3, 15, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(240, 1, 4, 16, '2024-10-20', '2024-10-20', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(241, 1, 1, 1, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(242, 1, 2, 2, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(243, 1, 3, 3, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(244, 1, 4, 4, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(245, 1, 1, 5, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(246, 1, 2, 6, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(247, 1, 3, 7, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(248, 1, 4, 8, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(249, 1, 1, 9, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(250, 1, 2, 10, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(251, 1, 3, 11, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(252, 1, 4, 12, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(253, 1, 1, 13, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(254, 1, 2, 14, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(255, 1, 3, 15, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(256, 1, 4, 16, '2024-10-20', '2024-10-20', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(257, 1, 1, 1, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(258, 1, 2, 2, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(259, 1, 3, 3, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(260, 1, 4, 4, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(261, 1, 1, 5, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(262, 1, 2, 6, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(263, 1, 3, 7, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(264, 1, 4, 8, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(265, 1, 1, 9, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(266, 1, 2, 10, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(267, 1, 3, 11, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(268, 1, 4, 12, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(269, 1, 1, 13, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(270, 1, 2, 14, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(271, 1, 3, 15, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(272, 1, 4, 16, '2024-10-21', '2024-10-21', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(273, 1, 1, 1, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(274, 1, 2, 2, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(275, 1, 3, 3, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(276, 1, 4, 4, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(277, 1, 1, 5, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(278, 1, 2, 6, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(279, 1, 3, 7, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(280, 1, 4, 8, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(281, 1, 1, 9, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(282, 1, 2, 10, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(283, 1, 3, 11, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(284, 1, 4, 12, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(285, 1, 1, 13, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(286, 1, 2, 14, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(287, 1, 3, 15, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(288, 1, 4, 16, '2024-10-21', '2024-10-21', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(289, 1, 1, 1, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(290, 1, 2, 2, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(291, 1, 3, 3, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(292, 1, 4, 4, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(293, 1, 1, 5, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(294, 1, 2, 6, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(295, 1, 3, 7, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(296, 1, 4, 8, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(297, 1, 1, 9, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(298, 1, 2, 10, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(299, 1, 3, 11, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(300, 1, 4, 12, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(301, 1, 1, 13, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(302, 1, 2, 14, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(303, 1, 3, 15, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(304, 1, 4, 16, '2024-10-21', '2024-10-21', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(305, 1, 1, 1, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(306, 1, 2, 2, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(307, 1, 3, 3, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(308, 1, 4, 4, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(309, 1, 1, 5, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(310, 1, 2, 6, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(311, 1, 3, 7, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(312, 1, 4, 8, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(313, 1, 1, 9, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(314, 1, 2, 10, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(315, 1, 3, 11, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(316, 1, 4, 12, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(317, 1, 1, 13, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(318, 1, 2, 14, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(319, 1, 3, 15, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(320, 1, 4, 16, '2024-10-21', '2024-10-21', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(321, 1, 1, 1, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(322, 1, 2, 2, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(323, 1, 3, 3, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(324, 1, 4, 4, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(325, 1, 1, 5, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(326, 1, 2, 6, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(327, 1, 3, 7, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(328, 1, 4, 8, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(329, 1, 1, 9, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(330, 1, 2, 10, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(331, 1, 3, 11, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(332, 1, 4, 12, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(333, 1, 1, 13, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(334, 1, 2, 14, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(335, 1, 3, 15, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(336, 1, 4, 16, '2024-10-22', '2024-10-22', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(337, 1, 1, 1, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(338, 1, 2, 2, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(339, 1, 3, 3, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(340, 1, 4, 4, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(341, 1, 1, 5, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(342, 1, 2, 6, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(343, 1, 3, 7, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(344, 1, 4, 8, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(345, 1, 1, 9, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(346, 1, 2, 10, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(347, 1, 3, 11, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(348, 1, 4, 12, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(349, 1, 1, 13, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(350, 1, 2, 14, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(351, 1, 3, 15, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(352, 1, 4, 16, '2024-10-22', '2024-10-22', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(353, 1, 1, 1, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(354, 1, 2, 2, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(355, 1, 3, 3, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(356, 1, 4, 4, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(357, 1, 1, 5, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(358, 1, 2, 6, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(359, 1, 3, 7, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(360, 1, 4, 8, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(361, 1, 1, 9, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(362, 1, 2, 10, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(363, 1, 3, 11, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(364, 1, 4, 12, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(365, 1, 1, 13, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(366, 1, 2, 14, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(367, 1, 3, 15, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(368, 1, 4, 16, '2024-10-22', '2024-10-22', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(369, 1, 1, 1, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(370, 1, 2, 2, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(371, 1, 3, 3, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(372, 1, 4, 4, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(373, 1, 1, 5, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(374, 1, 2, 6, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(375, 1, 3, 7, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(376, 1, 4, 8, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(377, 1, 1, 9, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(378, 1, 2, 10, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(379, 1, 3, 11, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(380, 1, 4, 12, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(381, 1, 1, 13, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(382, 1, 2, 14, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(383, 1, 3, 15, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(384, 1, 4, 16, '2024-10-22', '2024-10-22', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(385, 1, 1, 1, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(386, 1, 2, 2, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(387, 1, 3, 3, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(388, 1, 4, 4, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(389, 1, 1, 5, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(390, 1, 2, 6, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(391, 1, 3, 7, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(392, 1, 4, 8, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(393, 1, 1, 9, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(394, 1, 2, 10, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(395, 1, 3, 11, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(396, 1, 4, 12, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(397, 1, 1, 13, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(398, 1, 2, 14, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(399, 1, 3, 15, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(400, 1, 4, 16, '2024-10-23', '2024-10-23', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(401, 1, 1, 1, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(402, 1, 2, 2, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(403, 1, 3, 3, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(404, 1, 4, 4, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(405, 1, 1, 5, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(406, 1, 2, 6, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(407, 1, 3, 7, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(408, 1, 4, 8, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(409, 1, 1, 9, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(410, 1, 2, 10, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(411, 1, 3, 11, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(412, 1, 4, 12, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(413, 1, 1, 13, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(414, 1, 2, 14, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(415, 1, 3, 15, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(416, 1, 4, 16, '2024-10-23', '2024-10-23', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(417, 1, 1, 1, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(418, 1, 2, 2, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(419, 1, 3, 3, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(420, 1, 4, 4, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(421, 1, 1, 5, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(422, 1, 2, 6, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(423, 1, 3, 7, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(424, 1, 4, 8, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(425, 1, 1, 9, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(426, 1, 2, 10, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(427, 1, 3, 11, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(428, 1, 4, 12, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(429, 1, 1, 13, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(430, 1, 2, 14, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(431, 1, 3, 15, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(432, 1, 4, 16, '2024-10-23', '2024-10-23', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(433, 1, 1, 1, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(434, 1, 2, 2, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(435, 1, 3, 3, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(436, 1, 4, 4, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(437, 1, 1, 5, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(438, 1, 2, 6, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(439, 1, 3, 7, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(440, 1, 4, 8, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(441, 1, 1, 9, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(442, 1, 2, 10, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(443, 1, 3, 11, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(444, 1, 4, 12, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(445, 1, 1, 13, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(446, 1, 2, 14, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(447, 1, 3, 15, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(448, 1, 4, 16, '2024-10-23', '2024-10-23', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(449, 1, 1, 1, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(450, 1, 2, 2, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(451, 1, 3, 3, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(452, 1, 4, 4, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(453, 1, 1, 5, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(454, 1, 2, 6, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(455, 1, 3, 7, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(456, 1, 4, 8, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(457, 1, 1, 9, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(458, 1, 2, 10, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(459, 1, 3, 11, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(460, 1, 4, 12, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(461, 1, 1, 13, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(462, 1, 2, 14, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(463, 1, 3, 15, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(464, 1, 4, 16, '2024-10-24', '2024-10-24', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(465, 1, 1, 1, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(466, 1, 2, 2, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(467, 1, 3, 3, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(468, 1, 4, 4, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(469, 1, 1, 5, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(470, 1, 2, 6, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(471, 1, 3, 7, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(472, 1, 4, 8, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(473, 1, 1, 9, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(474, 1, 2, 10, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(475, 1, 3, 11, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(476, 1, 4, 12, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(477, 1, 1, 13, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(478, 1, 2, 14, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(479, 1, 3, 15, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(480, 1, 4, 16, '2024-10-24', '2024-10-24', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(481, 1, 1, 1, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(482, 1, 2, 2, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(483, 1, 3, 3, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(484, 1, 4, 4, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(485, 1, 1, 5, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(486, 1, 2, 6, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(487, 1, 3, 7, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(488, 1, 4, 8, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(489, 1, 1, 9, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(490, 1, 2, 10, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(491, 1, 3, 11, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(492, 1, 4, 12, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(493, 1, 1, 13, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(494, 1, 2, 14, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(495, 1, 3, 15, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(496, 1, 4, 16, '2024-10-24', '2024-10-24', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(497, 1, 1, 1, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(498, 1, 2, 2, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(499, 1, 3, 3, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(500, 1, 4, 4, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(501, 1, 1, 5, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(502, 1, 2, 6, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(503, 1, 3, 7, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(504, 1, 4, 8, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(505, 1, 1, 9, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(506, 1, 2, 10, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(507, 1, 3, 11, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(508, 1, 4, 12, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(509, 1, 1, 13, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(510, 1, 2, 14, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(511, 1, 3, 15, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(512, 1, 4, 16, '2024-10-24', '2024-10-24', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(513, 1, 1, 1, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(514, 1, 2, 2, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(515, 1, 3, 3, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(516, 1, 4, 4, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(517, 1, 1, 5, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(518, 1, 2, 6, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(519, 1, 3, 7, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(520, 1, 4, 8, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(521, 1, 1, 9, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(522, 1, 2, 10, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(523, 1, 3, 11, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(524, 1, 4, 12, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(525, 1, 1, 13, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(526, 1, 2, 14, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(527, 1, 3, 15, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(528, 1, 4, 16, '2024-10-25', '2024-10-25', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(529, 1, 1, 1, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(530, 1, 2, 2, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(531, 1, 3, 3, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(532, 1, 4, 4, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(533, 1, 1, 5, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(534, 1, 2, 6, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(535, 1, 3, 7, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(536, 1, 4, 8, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(537, 1, 1, 9, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(538, 1, 2, 10, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(539, 1, 3, 11, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(540, 1, 4, 12, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(541, 1, 1, 13, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(542, 1, 2, 14, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(543, 1, 3, 15, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(544, 1, 4, 16, '2024-10-25', '2024-10-25', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(545, 1, 1, 1, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(546, 1, 2, 2, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(547, 1, 3, 3, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(548, 1, 4, 4, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(549, 1, 1, 5, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(550, 1, 2, 6, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(551, 1, 3, 7, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(552, 1, 4, 8, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(553, 1, 1, 9, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(554, 1, 2, 10, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(555, 1, 3, 11, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(556, 1, 4, 12, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(557, 1, 1, 13, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(558, 1, 2, 14, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(559, 1, 3, 15, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(560, 1, 4, 16, '2024-10-25', '2024-10-25', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(561, 1, 1, 1, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(562, 1, 2, 2, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(563, 1, 3, 3, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(564, 1, 4, 4, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(565, 1, 1, 5, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(566, 1, 2, 6, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(567, 1, 3, 7, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(568, 1, 4, 8, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(569, 1, 1, 9, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(570, 1, 2, 10, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(571, 1, 3, 11, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(572, 1, 4, 12, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(573, 1, 1, 13, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(574, 1, 2, 14, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 2, 14);
INSERT INTO `exam_schedules` (`schedule_id`, `exam_id`, `branch_id`, `course_id`, `exam_date_start`, `exam_date_end`, `start_time`, `end_time`, `semester`, `College`, `Department`) VALUES
(575, 1, 3, 15, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(576, 1, 4, 16, '2024-10-25', '2024-10-25', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(577, 1, 1, 1, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(578, 1, 2, 2, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(579, 1, 3, 3, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(580, 1, 4, 4, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(581, 1, 1, 5, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(582, 1, 2, 6, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(583, 1, 3, 7, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(584, 1, 4, 8, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(585, 1, 1, 9, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(586, 1, 2, 10, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(587, 1, 3, 11, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(588, 1, 4, 12, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(589, 1, 1, 13, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(590, 1, 2, 14, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(591, 1, 3, 15, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(592, 1, 4, 16, '2024-10-26', '2024-10-26', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(593, 1, 1, 1, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(594, 1, 2, 2, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(595, 1, 3, 3, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(596, 1, 4, 4, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(597, 1, 1, 5, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(598, 1, 2, 6, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(599, 1, 3, 7, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(600, 1, 4, 8, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(601, 1, 1, 9, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(602, 1, 2, 10, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(603, 1, 3, 11, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(604, 1, 4, 12, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(605, 1, 1, 13, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(606, 1, 2, 14, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(607, 1, 3, 15, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(608, 1, 4, 16, '2024-10-26', '2024-10-26', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(609, 1, 1, 1, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(610, 1, 2, 2, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(611, 1, 3, 3, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(612, 1, 4, 4, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(613, 1, 1, 5, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(614, 1, 2, 6, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(615, 1, 3, 7, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(616, 1, 4, 8, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(617, 1, 1, 9, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(618, 1, 2, 10, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(619, 1, 3, 11, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(620, 1, 4, 12, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(621, 1, 1, 13, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(622, 1, 2, 14, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(623, 1, 3, 15, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(624, 1, 4, 16, '2024-10-26', '2024-10-26', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(625, 1, 1, 1, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(626, 1, 2, 2, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(627, 1, 3, 3, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(628, 1, 4, 4, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(629, 1, 1, 5, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(630, 1, 2, 6, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(631, 1, 3, 7, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(632, 1, 4, 8, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(633, 1, 1, 9, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(634, 1, 2, 10, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(635, 1, 3, 11, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(636, 1, 4, 12, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(637, 1, 1, 13, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(638, 1, 2, 14, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(639, 1, 3, 15, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(640, 1, 4, 16, '2024-10-26', '2024-10-26', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(641, 1, 1, 1, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(642, 1, 2, 2, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(643, 1, 3, 3, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(644, 1, 4, 4, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(645, 1, 1, 5, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(646, 1, 2, 6, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(647, 1, 3, 7, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(648, 1, 4, 8, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(649, 1, 1, 9, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(650, 1, 2, 10, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(651, 1, 3, 11, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(652, 1, 4, 12, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(653, 1, 1, 13, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(654, 1, 2, 14, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(655, 1, 3, 15, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(656, 1, 4, 16, '2024-10-27', '2024-10-27', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(657, 1, 1, 1, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(658, 1, 2, 2, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(659, 1, 3, 3, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(660, 1, 4, 4, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(661, 1, 1, 5, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(662, 1, 2, 6, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(663, 1, 3, 7, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(664, 1, 4, 8, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(665, 1, 1, 9, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(666, 1, 2, 10, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(667, 1, 3, 11, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(668, 1, 4, 12, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(669, 1, 1, 13, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(670, 1, 2, 14, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(671, 1, 3, 15, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(672, 1, 4, 16, '2024-10-27', '2024-10-27', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(673, 1, 1, 1, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(674, 1, 2, 2, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(675, 1, 3, 3, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(676, 1, 4, 4, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(677, 1, 1, 5, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(678, 1, 2, 6, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(679, 1, 3, 7, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(680, 1, 4, 8, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(681, 1, 1, 9, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(682, 1, 2, 10, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(683, 1, 3, 11, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(684, 1, 4, 12, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(685, 1, 1, 13, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(686, 1, 2, 14, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(687, 1, 3, 15, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(688, 1, 4, 16, '2024-10-27', '2024-10-27', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(689, 1, 1, 1, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(690, 1, 2, 2, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(691, 1, 3, 3, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(692, 1, 4, 4, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(693, 1, 1, 5, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(694, 1, 2, 6, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(695, 1, 3, 7, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(696, 1, 4, 8, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(697, 1, 1, 9, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(698, 1, 2, 10, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(699, 1, 3, 11, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(700, 1, 4, 12, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(701, 1, 1, 13, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(702, 1, 2, 14, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(703, 1, 3, 15, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(704, 1, 4, 16, '2024-10-27', '2024-10-27', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(705, 1, 1, 1, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(706, 1, 2, 2, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(707, 1, 3, 3, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(708, 1, 4, 4, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(709, 1, 1, 5, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(710, 1, 2, 6, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(711, 1, 3, 7, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(712, 1, 4, 8, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(713, 1, 1, 9, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(714, 1, 2, 10, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(715, 1, 3, 11, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(716, 1, 4, 12, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(717, 1, 1, 13, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(718, 1, 2, 14, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(719, 1, 3, 15, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(720, 1, 4, 16, '2024-10-28', '2024-10-28', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(721, 1, 1, 1, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(722, 1, 2, 2, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(723, 1, 3, 3, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(724, 1, 4, 4, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(725, 1, 1, 5, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(726, 1, 2, 6, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(727, 1, 3, 7, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(728, 1, 4, 8, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(729, 1, 1, 9, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(730, 1, 2, 10, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(731, 1, 3, 11, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(732, 1, 4, 12, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(733, 1, 1, 13, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(734, 1, 2, 14, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(735, 1, 3, 15, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(736, 1, 4, 16, '2024-10-28', '2024-10-28', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(737, 1, 1, 1, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(738, 1, 2, 2, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(739, 1, 3, 3, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(740, 1, 4, 4, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(741, 1, 1, 5, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(742, 1, 2, 6, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(743, 1, 3, 7, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(744, 1, 4, 8, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(745, 1, 1, 9, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(746, 1, 2, 10, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(747, 1, 3, 11, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(748, 1, 4, 12, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(749, 1, 1, 13, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(750, 1, 2, 14, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(751, 1, 3, 15, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(752, 1, 4, 16, '2024-10-28', '2024-10-28', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(753, 1, 1, 1, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(754, 1, 2, 2, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(755, 1, 3, 3, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(756, 1, 4, 4, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(757, 1, 1, 5, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(758, 1, 2, 6, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(759, 1, 3, 7, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(760, 1, 4, 8, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(761, 1, 1, 9, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(762, 1, 2, 10, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(763, 1, 3, 11, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(764, 1, 4, 12, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(765, 1, 1, 13, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(766, 1, 2, 14, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(767, 1, 3, 15, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(768, 1, 4, 16, '2024-10-28', '2024-10-28', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(769, 1, 1, 1, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(770, 1, 2, 2, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(771, 1, 3, 3, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(772, 1, 4, 4, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(773, 1, 1, 5, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(774, 1, 2, 6, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(775, 1, 3, 7, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(776, 1, 4, 8, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(777, 1, 1, 9, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(778, 1, 2, 10, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(779, 1, 3, 11, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(780, 1, 4, 12, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(781, 1, 1, 13, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(782, 1, 2, 14, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(783, 1, 3, 15, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(784, 1, 4, 16, '2024-10-29', '2024-10-29', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(785, 1, 1, 1, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(786, 1, 2, 2, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(787, 1, 3, 3, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(788, 1, 4, 4, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(789, 1, 1, 5, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(790, 1, 2, 6, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(791, 1, 3, 7, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(792, 1, 4, 8, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(793, 1, 1, 9, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(794, 1, 2, 10, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(795, 1, 3, 11, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(796, 1, 4, 12, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(797, 1, 1, 13, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(798, 1, 2, 14, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(799, 1, 3, 15, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(800, 1, 4, 16, '2024-10-29', '2024-10-29', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(801, 1, 1, 1, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(802, 1, 2, 2, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(803, 1, 3, 3, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(804, 1, 4, 4, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(805, 1, 1, 5, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(806, 1, 2, 6, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(807, 1, 3, 7, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(808, 1, 4, 8, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(809, 1, 1, 9, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(810, 1, 2, 10, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(811, 1, 3, 11, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(812, 1, 4, 12, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(813, 1, 1, 13, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(814, 1, 2, 14, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(815, 1, 3, 15, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(816, 1, 4, 16, '2024-10-29', '2024-10-29', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(817, 1, 1, 1, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(818, 1, 2, 2, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(819, 1, 3, 3, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(820, 1, 4, 4, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(821, 1, 1, 5, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(822, 1, 2, 6, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(823, 1, 3, 7, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(824, 1, 4, 8, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(825, 1, 1, 9, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(826, 1, 2, 10, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(827, 1, 3, 11, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(828, 1, 4, 12, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(829, 1, 1, 13, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(830, 1, 2, 14, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(831, 1, 3, 15, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(832, 1, 4, 16, '2024-10-29', '2024-10-29', '20:30:00', '21:30:00', 'Semester 1', 4, 16),
(833, 2, 1, 1, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 1, 1),
(834, 2, 2, 2, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 2, 2),
(835, 2, 3, 3, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 3, 3),
(836, 2, 4, 4, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 4, 4),
(837, 2, 1, 5, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 1, 5),
(838, 2, 2, 6, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 2, 6),
(839, 2, 3, 7, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 3, 7),
(840, 2, 4, 8, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 4, 8),
(841, 2, 1, 9, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 1, 9),
(842, 2, 2, 10, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 2, 10),
(843, 2, 3, 11, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 3, 11),
(844, 2, 4, 12, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 4, 12),
(845, 2, 1, 13, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 1, 13),
(846, 2, 2, 14, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 2, 14),
(847, 2, 3, 15, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 3, 15),
(848, 2, 4, 16, '2024-12-10', '2024-12-10', '16:00:00', '17:00:00', 'Semester 1', 4, 16),
(849, 2, 1, 1, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 1, 1),
(850, 2, 2, 2, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 2, 2),
(851, 2, 3, 3, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 3, 3),
(852, 2, 4, 4, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 4, 4),
(853, 2, 1, 5, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 1, 5),
(854, 2, 2, 6, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 2, 6),
(855, 2, 3, 7, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 3, 7),
(856, 2, 4, 8, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 4, 8),
(857, 2, 1, 9, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 1, 9),
(858, 2, 2, 10, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 2, 10),
(859, 2, 3, 11, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 3, 11),
(860, 2, 4, 12, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 4, 12),
(861, 2, 1, 13, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 1, 13),
(862, 2, 2, 14, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 2, 14),
(863, 2, 3, 15, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 3, 15),
(864, 2, 4, 16, '2024-12-10', '2024-12-10', '17:30:00', '18:30:00', 'Semester 1', 4, 16),
(865, 2, 1, 1, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 1, 1),
(866, 2, 2, 2, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 2, 2),
(867, 2, 3, 3, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 3, 3),
(868, 2, 4, 4, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 4, 4),
(869, 2, 1, 5, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 1, 5),
(870, 2, 2, 6, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 2, 6),
(871, 2, 3, 7, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 3, 7),
(872, 2, 4, 8, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 4, 8),
(873, 2, 1, 9, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 1, 9),
(874, 2, 2, 10, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 2, 10),
(875, 2, 3, 11, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 3, 11),
(876, 2, 4, 12, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 4, 12),
(877, 2, 1, 13, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 1, 13),
(878, 2, 2, 14, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 2, 14),
(879, 2, 3, 15, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 3, 15),
(880, 2, 4, 16, '2024-12-10', '2024-12-10', '19:00:00', '20:00:00', 'Semester 1', 4, 16),
(881, 2, 1, 1, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 1, 1),
(882, 2, 2, 2, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 2, 2),
(883, 2, 3, 3, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 3, 3),
(884, 2, 4, 4, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 4, 4),
(885, 2, 1, 5, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 1, 5),
(886, 2, 2, 6, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 2, 6),
(887, 2, 3, 7, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 3, 7),
(888, 2, 4, 8, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 4, 8),
(889, 2, 1, 9, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 1, 9),
(890, 2, 2, 10, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 2, 10),
(891, 2, 3, 11, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 3, 11),
(892, 2, 4, 12, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 4, 12),
(893, 2, 1, 13, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 1, 13),
(894, 2, 2, 14, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 2, 14),
(895, 2, 3, 15, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 3, 15),
(896, 2, 4, 16, '2024-12-10', '2024-12-10', '20:30:00', '21:30:00', 'Semester 1', 4, 16);

-- --------------------------------------------------------

--
-- Table structure for table `help_requests`
--

CREATE TABLE `help_requests` (
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `type_help` varchar(30) NOT NULL,
  `assigned_to_user` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `status` enum('Pending','In Progress','Completed') DEFAULT 'Pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `help_requests`
--

INSERT INTO `help_requests` (`request_id`, `user_id`, `description`, `type_help`, `assigned_to_user`, `branch_id`, `status`, `created_at`) VALUES
(3, 11, '2 two papers ', 'Request papers', 16, 1, 'In Progress', '2024-12-01 16:02:45');

-- --------------------------------------------------------

--
-- Table structure for table `issues`
--

CREATE TABLE `issues` (
  `issue_id` int(11) NOT NULL,
  `reported_by_user` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Open','In Progress','Resolved') DEFAULT 'Open',
  `assigned_to_user` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_problems`
--

CREATE TABLE `report_problems` (
  `report_id` int(11) NOT NULL,
  `reported_by_user` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `type_problem` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `Attachments` varchar(1000) DEFAULT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_problems`
--

INSERT INTO `report_problems` (`report_id`, `reported_by_user`, `branch_id`, `type_problem`, `description`, `Attachments`, `created_at`) VALUES
(4, 11, 1, 'Cheating incident', 'غش في قاعة 33 ', 'uploads/chat.png', '2024-12-01');

-- --------------------------------------------------------

--
-- Table structure for table `screen_share`
--

CREATE TABLE `screen_share` (
  `screen_share_id` int(11) NOT NULL,
  `proctor_or_it` int(11) NOT NULL,
  `role` enum('Proctor','IT-Support') NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_evaluations`
--

CREATE TABLE `service_evaluations` (
  `evaluation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `feedback` text DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `submitted_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `service_evaluations`
--

INSERT INTO `service_evaluations` (`evaluation_id`, `user_id`, `rating`, `feedback`, `branch_id`, `submitted_at`) VALUES
(3, 11, 4, 'لا توجد مشاكل', 1, '2024-12-01 16:06:00');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` int(11) NOT NULL,
  `proctor_id` int(11) NOT NULL,
  `support_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_link` varchar(255) NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `end_time` timestamp NULL DEFAULT NULL,
  `is_sharing` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_id`, `proctor_id`, `support_id`, `branch_id`, `session_link`, `start_time`, `end_time`, `is_sharing`) VALUES
(10, 12, 16, 1, 'session_674816d8cc2820.40344852', '2024-11-28 07:08:08', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(500) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(500) NOT NULL,
  `role` enum('Admin','superadmin','Proctor','IT-Support') NOT NULL,
  `gender` enum('male','Female') NOT NULL,
  `branch_id` int(11) NOT NULL,
  `account_status` enum('Active','Suspended') DEFAULT 'Suspended',
  `verification` int(30) NOT NULL,
  `verification_use` varchar(1) DEFAULT 'N',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password_hash`, `role`, `gender`, `branch_id`, `account_status`, `verification`, `verification_use`, `created_at`) VALUES
(1, 'Dr. Hamdan Ahmed Al-Zahrani', 'hzahrani@seu.edu.sa', '$2y$10$bL7WvHa8AjHioUxa6eaLk.2Lui9QF3vyBEm36dgWcxd4T.YcVcnhC', 'Proctor', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(2, 'Dr. Ihsan Ahmed', 'iahmed@seu.edu.sa', '$2y$10$gz.2uti3fPGk0TQTx.MrvO04rURJXO73bHDcSguJbFpTxuJZlhqVm', 'Proctor', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(3, 'Dr. Youssef Ali Al-Mansour', 'ymansour@seu.edu.sa', '$2y$10$PP7j4VZI.J3HK.HxxJ3Htem/hOGZh5aBSm9j0kF6ik1RRXmNFx2Xq', 'Proctor', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(4, 'Dr. Khaled Mohammed Al-Shehri', 'kshehri@seu.edu.sa', '$2y$10$lCWSs7xo2stjAARjHUL9CuVtQdCpR96yLegqovouUOWX271kEuSNC', 'Proctor', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(5, 'Dr. Ziad Mohammed Al-Ali', 'zsaleh@seu.edu.sa', '$2y$10$C0lGJEi7/zHZfw0.GtEPbe0eg8whTeX1tdqf.t8972Ux5WEX3FP76', 'Proctor', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(6, 'Ahmed Saeed Al-Ghamdi', 'aghamdi@seu.edu.sa', '$2y$10$L2XKdS4NimhM7CXzxJK7eO03V9ZzdmPfnfJ1/X2WIXYlCVy1dg5mC', 'IT-Support', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(7, 'Omar Abdulaziz Al-Fahad', 'ofahad@seu.edu.sa', '$2y$10$i3dA7XgrJF09r1mJ4aDUru90mZzta6dYHUSk274gh7uS.y4/ZQm.y', 'IT-Support', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(8, 'Faisal Mohammed Al-Harbi', 'fharbi1@seu.edu.sa', '$2y$10$J7Migi/ET.M9wYiEGJ3PIOjgOjlbS2GMgRXwZ34r86a5e8R/ecqVG', 'IT-Support', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(9, 'Tamer Ali Al-Mutairi', 'tmutairi@seu.edu.sa', '$2y$10$iUZVgLcgr95VVzxkct7bsesViav55nsDltf91of3EEARSrFeSmtAy', 'IT-Support', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(10, 'Nasser Ibrahim Al-Juhani', 'njuhani@seu.edu.sa', '$2y$10$oTdpApVDuavNs3NB8oDNpeLuPPa67LLxwIXaeiIWE4TNmao/sXENO', 'IT-Support', 'male', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(11, 'Dr. Abrar Mohammed Al-Zahrani', 'abrar@seu.edu.sa', '$2y$10$qY9ersodoFvj3sIIXpty/eFXNSYHG4U7fmZkeX2mYZ6Hx15IRbNqG', 'Proctor', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(12, 'Dr.Buthaina Saeed Al-Harbi', 'buthaina@seu.edu.sa', '$2y$10$uDv7PpiY3840gF4yD4S6lexU8PdRyHJ3DO32q7EJBMDhj.JmjU89i', 'Proctor', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(13, 'Dr.Sabah Ahmed Al-Ghamdi', 'sabah@seu.edu.sa', '$2y$10$w0KVhi0WiDDIxqY1QGx2ZOsIBpcGyghQ4XwJuMBd7VOqpXNbfI30i', 'Proctor', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(14, 'Dr.Zainab Ali Al-Shehri', 'zainab@seu.edu.sa', '$2y$10$PGWoH/foCOBNWYBoYY7CuOD385z.ltiyhwi8PPZ.1S.6XS3HCNm8S', 'Proctor', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(15, 'Dr.Wardah Ibrahim Al-Juhani', 'wardah@seu.edu.sa', '$2y$10$dhAfmxXAuiYr3q0HU4pvjumwrWxk2pMKK22Q8LW4gT/0TlH0OhO6S', 'Proctor', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(16, 'Hasna Abdullah Al-Fahad', 'hasna@seu.edu.sa', '$2y$10$72ft5RCWXjXu/hKN/9JPXOytTEAYNBDQdCoistmtYYHekdIbk6fdO', 'IT-Support', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(17, 'Alya Mohammed Al-Mutairi', 'alya@seu.edu.sa', '$2y$10$IuM6Wmza4qoMjDzYeeq4j.bWqylVkn0ff17pfw31onXutwwQd7P0O', 'IT-Support', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(18, 'Amani Saeed Al-Ghamdi', 'amanis@seu.edu.sa', '$2y$10$8jN.ZNh8q.3dtDTop3W0o.1QUJrwfDQFGfbH.DsboFCwLKfOnf8eG', 'IT-Support', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(19, 'Ahlam Ahmed Al-Saleh', 'ahlam@seu.edu.sa', '$2y$10$Vhkicg.uzrdvquy2MSTbQuJvLeSp58LhZCaTPgRzFMlgMgSHgdTq.', 'IT-Support', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(20, 'Widad Khalid Al-Shehri', 'widad@seu.edu.sa', '$2y$10$yFQmw8h6Fdd7xcw3Br6HwOloZmGjBweo/bbhVQvx53GCNgMNz2vxG', 'IT-Support', 'Female', 1, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(21, 'Dr. Samir Ahmed Al-Mansour', 'smansour1@seu.edu.sa', '$2y$10$2vwdIXK8JbYAEKNX23cL9eX/SwD978f.ieuRkVJfM/O4KXCV.CU4.', 'Proctor', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(22, 'Dr. Tariq Ali Al-Harbi', 'tharbi@seu.edu.sa', '$2y$10$lsjadbkRBaUWtgOFNi7nCeUN6dFtc.FIpe9bfCOc/l1PxgfXzmKM2', 'Proctor', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(23, 'Dr. Rami Abdulaziz Al-Ghamdi', 'rghamdi@seu.edu.sa', '$2y$10$vgCSiO/DzOwF4wPU69EqbudhGA..iB.cxtQ9KRp/FJKeGkuuP6Rte', 'Proctor', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(24, 'Dr. Walid Mohammed Al-Juhani', 'wjuhani@seu.edu.sa', '$2y$10$QaaaRODaXncyrSneZ1Ztw.x.UfQgsxyvc5U1FFxExBV7.vJAJFdXC', 'Proctor', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(25, 'Dr. Abdullah Mohammed Al-Saleh', 'asaleh1@seu.edu.sa', '$2y$10$oJr5dCQruxy7uq1n2DrTve99LO1c1K6WITdavLoUrqyLhoncehh5q', 'Proctor', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(26, 'Saeed Ibrahim Al-Fahad', 'sfahad@seu.edu.sa', '$2y$10$sB/9Bg74p/KbOanXfMZHS.SK8ijzdmsuNx7JoJ014Jjag.ChGhtnm', 'IT-Support', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(27, 'Khalid Ali Al-Mutairi', 'kmutairi@seu.edu.sa', '$2y$10$ORln99jddH8phWUF/jBNueIftHGxLUGRuvROAyFILxK5Aqd8GQ2ru', 'IT-Support', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(28, 'Omar Mohammed Al-Saleh', 'osaleh@seu.edu.sa', '$2y$10$Jcetz9hKP278k02XWibX.OyFbxXcST5L.xHeGWZd9ALIfAXTiS/iq', 'IT-Support', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(29, 'Yasser Abdulaziz Al-Mansour', 'ymansour1@seu.edu.sa', '$2y$10$megsM.Zv6PDozm13fC0HEeIKpWPJ8.ag2xXWyzcgI3sk9sg5el9jC', 'IT-Support', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(30, 'Fawaz Mohammed Al-Juhani', 'fjuhani@seu.edu.sa', '$2y$10$D7VBmUPIComClYNTZPI/0ewSfy.YxNxLxLaPShQ01yT.jAHUYndwK', 'IT-Support', 'male', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(31, 'Dr.Shahd Ali Al-Najdi', 'shahd@seu.edu.sa', '$2y$10$L7ftlaYK1ZpJlpQeZXhQWOIQ64cmP0BFRLFTKesokglDrrReNyBse', 'Proctor', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(32, 'Dr.Noura Ahmed Al-Shehri', 'noura@seu.edu.sa', '$2y$10$qZ9hnofQM1lFjFhL8JMtZez2oiUthK7SAbu2Y5jeUIeh557fn9WKy', 'Proctor', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(33, 'Dr.Fatima Mohammed Al-Suqur', 'fatima@seu.edu.sa', '$2y$10$Cm.RUoeB5qe8pzKM1cHMOOJt4KspBZUhb27aIeRQr1OECfhXeQTkC', 'Proctor', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(34, 'Dr.Ranya Zainab Al-Mansour', 'ranya@seu.edu.sa', '$2y$10$NpGFcDCNhbFG3fhM5WEG1exWe42rX5ZFlddsZh0opTI7RyYdb3fCW', 'Proctor', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(35, 'Dr.Reem Abdulrahman Al-Fahad', 'reem@seu.edu.sa', '$2y$10$n04iHm1limvcEZrlXqlVUO8krjaIz7kcSQhGFjkinsXkekY7iVm6u', 'Proctor', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(36, 'Maha Ali Al-Saleh', 'maha@seu.edu.sa', '$2y$10$sRSn87j7G5kyKqdxZIxeSOPGbMKoKrWm1I/ww7bPaKoKjGBQhbVc.', 'IT-Support', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(37, 'Sara Mohammed Al-Juhani', 'sara@seu.edu.sa', '$2y$10$OLtCQfzi9j4F.OJBJp2aZ.e4sZfvBMFiVktZ/72uRnk2rOU3vQKWK', 'IT-Support', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(38, 'Layla Ibrahim Al-Ghamdi', 'layla@seu.edu.sa', '$2y$10$939PHHFh3qRMy5gd49dFXONeLtiIZAHbnd.EwzYSOqnQbCwb1yFIu', 'IT-Support', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(39, 'Hanan Zainab Al-Suqur', 'hanan@seu.edu.sa', '$2y$10$rA2m/VAr7Kz67R9vl30YPOulSHDF5.Xv2kLSZFzh9znQSa.zq/jCi', 'IT-Support', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(40, 'Hind Abdulrahman Al-Mansour', 'hind@seu.edu.sa', '$2y$10$WL99LBqL7wEEKq93OsJdqe4WFB1Fhtwu2ztcFlR.rFRasZ/UjMyO2', 'IT-Support', 'Female', 2, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(41, 'Dr. Ahmad Mohammed Al-Juhani', 'amjuhani@seu.edu.sa', '$2y$10$75UcrGmzhq9YwIGLRJpch.xDlQp1tT6Hu6sMZ4K0eNBhvaXMxizhC', 'Proctor', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(42, 'Dr. Khalil Ali Al-Fahad', 'kalfahad@seu.edu.sa', '$2y$10$ij.iKjftAE16JqQraBefK.2ZY/pSd1ES1a0qCXU.Lu2yWH4A3DcYu', 'Proctor', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(43, 'Dr. Ali Ahmad Al-Suqur', 'aaalq@seu.edu.sa', '$2y$10$pUT52nxm2CN9LFx9irKoOeMGqcuiGaOidVwWoIk2BG6kbWBGa5hrC', 'Proctor', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(44, 'Dr. Zahir Abdulaziz Al-Mansour', 'zalmansour@seu.edu.sa', '$2y$10$uCODDcCJhsZTX283vAV6QOmJafx7aBTYKHfRm1HMbDJQGgZYDawWW', 'Proctor', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(45, 'Dr. Nabil Mohammed Al-Ghamdi', 'nghamdi@seu.edu.sa', '$2y$10$4FT9BU6CSYlvGY9wlUajzeYZQjeGApW.ipGxsde1bkf.f7khxhM0O', 'Proctor', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(46, 'Yusuf Saeed Al-Juhani', 'yusuf@seu.edu.sa', '$2y$10$Eirm/dVSHZ07j6aKM4hAteOHLuIgyiJIzrk1VjdjJYfSm5o5A/CPK', 'IT-Support', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(47, 'Abdul Rahman Khalid Al-Fahad', 'arfahad@seu.edu.sa', '$2y$10$NLOpgNAoSaI504jV7Cr39.9gFL58Plg05a.Znt41klDjLB2R8GqFG', 'IT-Support', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(48, 'Zaid Mohammed Al-Suqur', 'zaid@seu.edu.sa', '$2y$10$3K1w4F9mcebUbwdKKezHmeQiyIst5ltGVphcuaNKgQQs47Umdw/Xq', 'IT-Support', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(49, 'Rami Abdulaziz Al-Mansour', 'rami@seu.edu.sa', '$2y$10$2ss0sLasw/Z9SQDTlSecl.I6J4nHcQg0qs8lD7xS0Bm5FasakF1B6', 'IT-Support', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(50, 'Hamza Ali Al-Ghamdi', 'hamza@seu.edu.sa', '$2y$10$gzh7sZWsZtwFxsGYw/g12Om8zeH8Tg1JdH3uT/fFlrHXo2vpy2GUK', 'IT-Support', 'male', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(51, 'Dr.Sara Ali Al-Qahtani', 'saraqahtani@seu.edu.sa', '$2y$10$t2qbM/8tbOfQDMNioLdk3.k9dHLXzz7hFn2rB/5l6pnGUWK8g79ki', 'Proctor', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(52, 'Dr.Lina Mohammed Al-Mutairi', 'linamutairi@seu.edu.sa', '$2y$10$8braTqW9ESvQrj0l/JntAu/gVOrjhjlNboME8s8zs4NwbfjrdJehS', 'Proctor', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(53, 'Dr.Dalia Abdulrahman Al-Najdi', 'dalia@seu.edu.sa', '$2y$10$GUA6fXnyl.xrGRc64nNGmeRjytaY3yVhU6cktlGaOSRBaP3bQWvQC', 'Proctor', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(54, 'Dr.Hana Saeed Al-Qarmizi', 'hana@seu.edu.sa', '$2y$10$dofwFYeOwrsvHwzvzfgpR.zwwRTXB3ZyBjBG6ElnGBcFcHEOsZfrW', 'Proctor', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(55, 'Dr.Salma Abdulaziz Hilal', 'salma@seu.edu.sa', '$2y$10$8nhqs7wK5/Y4RUWoKGxWPe.w7LFj2QcHMvQ2cVB6HeK8aC0d94Gjy', 'Proctor', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(56, 'Nour Ahmed Al-Hamad', 'nour@seu.edu.sa', '$2y$10$5hSh8jXPmVejASG6SZQcPO5U7BCoTc2KL7B13x3JjbhTqg5Ks8dRO', 'IT-Support', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(57, 'Rana Zainab Al-Suqur', 'rana@seu.edu.sa', '$2y$10$0jIokW8PNI/yehgFCvOOFOlmu07Pw60vWyi.4KaL5Krw2BSlZGHKe', 'IT-Support', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(58, 'Amani Khalid Al-Naqour', 'amani@seu.edu.sa', '$2y$10$I2v6VcDM/xobDRpazKWoUuSa.vbOnYkChNpAa9IkmGYQGmk9R.NzC', 'IT-Support', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(59, 'Yasmin Ali Al-Masry', 'yasmina@seu.edu.sa', '$2y$10$7ppHTzMyTFJtTlZCTZhWVeEpR.WviwV1ptV.aHDwABfVwLjP4nfYu', 'IT-Support', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(60, 'Raghad Mohammed Al-Ghamdi', 'raghad@seu.edu.sa', '$2y$10$nhHY429o6get2xoJMeA0duNiJ4lzibrnfvCXlNNEbK3Txf8Udyc3m', 'IT-Support', 'Female', 3, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(61, 'Dr. Hamid Abdulaziz Al-Harbi', 'hamid@seu.edu.sa', '$2y$10$z1A/p1FNvcjCMsrk.r5G8erZmbGJx5mRECfCuWv9tFYC593r3C9ua', 'Proctor', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(62, 'Dr. Basim Mohammed Al-Ghamdi', 'bgamdi@seu.edu.sa', '$2y$10$dcTvzaqRHaYoyrM8z8TELujH1b.WgJL4omrUWDfixWXKwMv0tLC7S', 'Proctor', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(63, 'Dr. Khaled Ali Al-Saleh', 'kalsaleh@seu.edu.sa', '$2y$10$vZnN6eeYgaCIaxs7dsSYQ.N5DQqokVEfr2jYfsBpgMc8gpbZMn73W', 'Proctor', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(64, 'Dr. Samir Ahmad Al-Qarni', 'saqarni@seu.edu.sa', '$2y$10$u.GIcOOk15dSBVJz7olCKOjPB7tMGWsp9TGplrObaO5QJWT5ay1S2', 'Proctor', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(65, 'Dr. Munir Ali Al-Awaji', 'mawaji@seu.edu.sa', '$2y$10$AHn/tOOcjRLYeacOfeAJbuehYicCBs9O8Lx.TTmrAyv1B52m1tJsO', 'Proctor', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(66, 'Adnan Khalid Al-Ghamdi', 'adnan@seu.edu.sa', '$2y$10$169vhzCdOez1LnyXxHki/.AHcziEHQHIIKV1Nil2yEh/W1H.az6c.', 'IT-Support', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(67, 'Yasmeen Mohammed Al-Suqur', 'yasmeen@seu.edu.sa', '$2y$10$N4NUk9q7zOk7x9/9ayX/LOJtcIaSGj0c9nkXarPmvl036tiuUwGO2', 'IT-Support', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(68, 'Saad Abdulaziz Al-Juhani', 'saad@seu.edu.sa', '$2y$10$mGadX3lXE32CwJH6iiDb7OhcNBqnL6Kt4CoXyJIe5gFFIX7v5ln1O', 'IT-Support', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(69, 'Mohammed Hamad Al-Fahad', 'mohammed@seu.edu.sa', '$2y$10$nKKASGQqS2ZCwfPNCTP91.3EBVYy0cXPWkHU.v/aV9vu91E.27w6y', 'IT-Support', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(70, 'Sultan Mohammed Al-Mutairi', 'sultan@seu.edu.sa', '$2y$10$1Fpx.GmFxH/aB/tMumG0HO6olUI0cGuAHpUFQFVSFXqCzVw3e4M/S', 'IT-Support', 'male', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(71, 'Dr.Rama Aisha Al-Suqur', 'rama@seu.edu.sa', '$2y$10$f7TfxTn5uvE736k/COm4BertPdNDSme66TC250aLx0X7rYRjowrvG', 'Proctor', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(72, 'Dr.Afnan Ali Al-Mansour', 'afnan@seu.edu.sa', '$2y$10$/uRM2nufPeWX/rNTISrY/uGe33WE1gjz0jgncOZAVgCcvhRwmPds.', 'Proctor', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(73, 'Dr.Nadia Abdulaziz Al-Ghamdi', 'nadia@seu.edu.sa', '$2y$10$tWsFS4lWeZsKjuHE.qxDbOtkP5BaOKCs5BiDxmx1zl7/cfp04Pjuy', 'Proctor', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(74, 'Dr.Alaa Mohammed Al-Juhani', 'alaa@seu.edu.sa', '$2y$10$cGeiaYjZWKJRTpXN7r.W5u0s0BUUuOMwNSOH99Wj3liwXK5RTW.my', 'Proctor', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(75, 'Dr.Yasmin Khalid Al-Najdi', 'yasmin@seu.edu.sa', '$2y$10$HcdLXTvEczJGqd5kQhQHTO/A5QYGGvnnK59/iwWewX126YOZZxgl6', 'Proctor', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(76, 'Alia Zainab Al-Saleh', 'alia@seu.edu.sa', '$2y$10$qh6CNJ2klPYAVQ0LbGKGtuAA4X52x8TstTnoxTEttvrRJ0kJMLUDe', 'IT-Support', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(77, 'Rita Abdulrahman Al-Ghamdi', 'rita@seu.edu.sa', '$2y$10$fg6QDKhj7UCoqX1QfyjKweFYgqorXEeYS0nkKMWfnkN6VawxPASEa', 'IT-Support', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(78, 'Noura Ahmed Al-Najdi', 'nouraa@seu.edu.sa', '$2y$10$AgQkNOYGc7bUQ3rafSeycuJQH0vOKCbtAyppvaqcDtX45WzYODi.2', 'IT-Support', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(79, 'Muna Mohammed Al-Fahad', 'muna@seu.edu.sa', '$2y$10$9IrgvKEqpS9TnmBuSy3xP.bzu0GXaIn6cF0gLCOyLM1nlTerM/HZy', 'IT-Support', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(80, 'Mariam Ali Al-Juhani', 'mariam@seu.edu.sa', '$2y$10$R5LV9IuO2mOtQIn4JtFwL.zyoc5PWtRqzHJ15Vo5N.7vvnehS32QW', 'IT-Support', 'Female', 4, 'Active', 0, 'Y', '2024-10-20 02:44:50'),
(81, 'admin', 'admin@seu.edu.sa', '$2y$10$X8ZeQ/Graxg3.1bOM1LDX.qJnQIMCyDb3KDgB/978TyIPY2QS.rtm', 'superadmin', 'male', 1, 'Active', 639700, 'Y', '2024-10-21 12:29:58'),
(96, 'Riyadh Branch Admin', 'admin.riyadh@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 1, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(97, 'Jeddah Branch Admin', 'admin.jeddah@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 2, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(98, 'Madinah Branch Admin', 'admin.madinah@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 3, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(99, 'Dammam Branch Admin', 'admin.dammam@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 4, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(100, 'Qassim Branch Admin', 'admin.qassim@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 5, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(101, 'Al-Ahsa Branch Admin', 'admin.alahsa@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 6, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(102, 'Tabuk Branch Admin', 'admin.tabuk@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 7, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(103, 'Abha Branch Admin', 'admin.abha@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 8, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(104, 'Jazan Branch Admin', 'admin.jazan@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 9, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(105, 'Al-Ula Branch Admin', 'admin.alula@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 10, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(106, 'Al-Qurayyat Branch Admin', 'admin.qurayyat@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 11, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(107, 'Hail Branch Admin', 'admin.hail@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 12, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(108, 'Najran Branch Admin', 'admin.najran@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 13, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(109, 'Jubail Branch Admin', 'admin.jubail@seu.edu.sa', '$2y$10$aJxQDX4JN2CVPp2WwSwlWO17Jnv5UW826J5J6nFrz1vg7WCTCD.hG', 'Admin', 'male', 14, 'Active', 1, 'Y', '2024-10-21 12:47:37'),
(110, 'Yanbu Branch Admin', 'admin.yanbu@seu.edu.sa', '$2y$10$HQw9Oq5tqtBZZLHjv01YEeS5WXq67tABSFZZ/Pi/PwgJCi2KRmHIO', 'Admin', 'male', 15, 'Active', 1, 'Y', '2024-11-27 04:54:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chat_id`),
  ADD KEY `Branch_id` (`Branch_id`),
  ADD KEY `sender_user_id` (`sender_user_id`),
  ADD KEY `Recipient_id` (`Recipient_id`);

--
-- Indexes for table `classrooms`
--
ALTER TABLE `classrooms`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `college`
--
ALTER TABLE `college`
  ADD PRIMARY KEY (`College_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `course_code` (`course_code`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Department_id`),
  ADD KEY `collage_id` (`collage_id`);

--
-- Indexes for table `exam_assignments`
--
ALTER TABLE `exam_assignments`
  ADD PRIMARY KEY (`assignment_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `porit_id` (`porit_id`),
  ADD KEY `room_id` (`room_id`);

--
-- Indexes for table `exam_schedules`
--
ALTER TABLE `exam_schedules`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `exam_schedules_ibfk_1` (`course_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `Department` (`Department`),
  ADD KEY `College` (`College`);

--
-- Indexes for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `assigned_to_user` (`assigned_to_user`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `issues`
--
ALTER TABLE `issues`
  ADD PRIMARY KEY (`issue_id`),
  ADD KEY `reported_by_user` (`reported_by_user`),
  ADD KEY `assigned_to_user` (`assigned_to_user`);

--
-- Indexes for table `report_problems`
--
ALTER TABLE `report_problems`
  ADD PRIMARY KEY (`report_id`),
  ADD KEY `branch_id` (`branch_id`),
  ADD KEY `reported_by_user` (`reported_by_user`);

--
-- Indexes for table `screen_share`
--
ALTER TABLE `screen_share`
  ADD PRIMARY KEY (`screen_share_id`);

--
-- Indexes for table `service_evaluations`
--
ALTER TABLE `service_evaluations`
  ADD PRIMARY KEY (`evaluation_id`),
  ADD KEY `session_id` (`user_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `proctor_id` (`proctor_id`),
  ADD KEY `support_id` (`support_id`),
  ADD KEY `branch_id` (`branch_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `branch_id` (`branch_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `branches`
--
ALTER TABLE `branches`
  MODIFY `branch_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `chat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `classrooms`
--
ALTER TABLE `classrooms`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `college`
--
ALTER TABLE `college`
  MODIFY `College_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Department_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `exam_assignments`
--
ALTER TABLE `exam_assignments`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `exam_schedules`
--
ALTER TABLE `exam_schedules`
  MODIFY `schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=897;

--
-- AUTO_INCREMENT for table `help_requests`
--
ALTER TABLE `help_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `issues`
--
ALTER TABLE `issues`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `report_problems`
--
ALTER TABLE `report_problems`
  MODIFY `report_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `screen_share`
--
ALTER TABLE `screen_share`
  MODIFY `screen_share_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_evaluations`
--
ALTER TABLE `service_evaluations`
  MODIFY `evaluation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `chats`
--
ALTER TABLE `chats`
  ADD CONSTRAINT `chats_ibfk_1` FOREIGN KEY (`Branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `chats_ibfk_2` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `chats_ibfk_3` FOREIGN KEY (`Recipient_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `college`
--
ALTER TABLE `college`
  ADD CONSTRAINT `college_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`);

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `department_ibfk_1` FOREIGN KEY (`collage_id`) REFERENCES `college` (`College_id`);

--
-- Constraints for table `exam_assignments`
--
ALTER TABLE `exam_assignments`
  ADD CONSTRAINT `exam_assignments_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `exam_assignments_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `exam_assignments_ibfk_3` FOREIGN KEY (`porit_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `exam_assignments_ibfk_4` FOREIGN KEY (`room_id`) REFERENCES `classrooms` (`room_id`);

--
-- Constraints for table `exam_schedules`
--
ALTER TABLE `exam_schedules`
  ADD CONSTRAINT `exam_schedules_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `exam_schedules_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `exam_schedules_ibfk_3` FOREIGN KEY (`Department`) REFERENCES `department` (`Department_id`),
  ADD CONSTRAINT `exam_schedules_ibfk_4` FOREIGN KEY (`College`) REFERENCES `college` (`College_id`);

--
-- Constraints for table `help_requests`
--
ALTER TABLE `help_requests`
  ADD CONSTRAINT `help_requests_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `help_requests_ibfk_2` FOREIGN KEY (`assigned_to_user`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `help_requests_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`);

--
-- Constraints for table `issues`
--
ALTER TABLE `issues`
  ADD CONSTRAINT `issues_ibfk_1` FOREIGN KEY (`reported_by_user`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `issues_ibfk_2` FOREIGN KEY (`assigned_to_user`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `report_problems`
--
ALTER TABLE `report_problems`
  ADD CONSTRAINT `report_problems_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `report_problems_ibfk_2` FOREIGN KEY (`reported_by_user`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `service_evaluations`
--
ALTER TABLE `service_evaluations`
  ADD CONSTRAINT `service_evaluations_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`),
  ADD CONSTRAINT `service_evaluations_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`proctor_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `sessions_ibfk_2` FOREIGN KEY (`support_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `sessions_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`branch_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
