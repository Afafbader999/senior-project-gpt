<style>
    /* Navbar styling */
    .navbar {
        background-color: #000; /* Background color */
    }

    .nav-link {
        position: relative;
        padding: 5px 15px;
        color: #fff; /* Text color */
        transition: all 0.3s ease-in-out;
    }

    .nav-link:hover {
        color: #fff; /* Text color on hover */
        background: linear-gradient(45deg, #054e9d, #57a4fc); /* Gradient background */
        border-radius: 20px; /* Rounded corners */
        padding-left: 20px;
        padding-right: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); /* Shadow effect */
    }

    .nav-link::before {
        content: "";
        position: absolute;
        width: 0;
        height: 2px;
        bottom: 0;
        left: 0;
        background-color: #57a4fc;
        visibility: hidden;
        transition: all 0.3s ease-in-out;
    }

    .nav-link:hover::before {
        visibility: visible;
        width: 100%; /* Underline effect */
    }
</style>

<header class="bg-navbar navbar-dark">
    <nav class="navbar navbar-expand-lg text-light">
        <div class="container-fluid">
            <!-- Brand -->
            <a class="navbar-brand text-light text-uppercase" href="index.php">
                <?php echo getTranslation('brand', $lang, $translations); ?>
            </a>

            <!-- Toggler for mobile -->
            <button class="navbar-toggler text-light" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navbar links -->
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
                        <!-- Show nav items based on roles -->
                        <li class="nav-item"><a class="nav-link text-light" href="index.php"><?php echo getTranslation('index', $lang, $translations); ?></a></li>
                        
                        <?php if ($_SESSION['role'] === 'Proctor'): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="exam_assignments.php"><?php echo getTranslation('exam_assignments', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                    <?php else: ?>
                        <!-- Non-logged-in user nav -->
                        <?php if (basename($_SERVER['PHP_SELF']) !== "index.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="index.php"><?php echo getTranslation('index', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                        
                        <?php if (basename($_SERVER['PHP_SELF']) !== "register.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="register.php"><?php echo getTranslation('signup', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                        
                        <?php if (basename($_SERVER['PHP_SELF']) !== "login.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="login.php"><?php echo getTranslation('login', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                        
                        <?php if (basename($_SERVER['PHP_SELF']) !== "about.php"): ?>
                            <li class="nav-item"><a class="nav-link text-light" href="about.php"><?php echo getTranslation('about', $lang, $translations); ?></a></li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- User and Language Dropdowns -->
            <ul class="navbar-nav ms-auto">
                <?php if (isset($_SESSION['user_id']) && !empty($_SESSION['user_id'])): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle text-light" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo htmlspecialchars($_SESSION['username']); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php"><?php echo getTranslation('profile', $lang, $translations); ?></a></li>
                            <li><a class="dropdown-item" href="logout.php"><?php echo getTranslation('logout', $lang, $translations); ?></a></li>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Language Dropdown -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-light" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo ($lang === 'ar') ? 'العربية' : 'English'; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="languageDropdown">
                        <li><a class="dropdown-item" href="?lang=en">English</a></li>
                        <li><a class="dropdown-item" href="?lang=ar">العربية</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>
