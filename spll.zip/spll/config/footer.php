    <!-- Footer section -->
    <footer>
        <p><?php echo getTranslation('footer', $lang, $translations); ?></p>
        <p>&copy; eEPS 2024</p>
    </footer>
    
    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body {
        margin: 0;
        display: flex;
        flex-direction: column;
        min-height: 100vh; /* Ensures the body takes up the full height of the viewport */
    }

    .content {
        flex: 1; /* Allows the content area to grow and take available space */
    }

    footer {
        height: 80px;
        background-color: #000000; /* Set the footer background color */
        padding: 10px; /* Padding inside the footer */
        text-align: center; /* Center the footer text */
    }
</style>