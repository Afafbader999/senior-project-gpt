<?php
session_start();

// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // إعادة توجيه المستخدم لصفحة تسجيل الدخول
    exit();
}

// تضمين ملف الترجمة
include 'lang.php';

// تحديد اللغة
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; // افتراضياً اللغة الإنجليزية
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

?>

<!DOCTYPE html>
<html lang="<?php
            echo ($lang == 'ar') ? 'ar' : 'en'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('dashboard', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }

        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
            transition: width 0.3s;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .dashboard-header {
            background-color: #000;
            color: white;
            padding: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }

        .dashboard-content {
            margin-top: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin 0.3s;
        }

        .content-section {
            padding: 20px;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .sidebar {
                display: none;
            }

            .dashboard-header,
            .dashboard-content {
                margin: 0;
            }
        }

        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
            /* ضبط محاذاة النص */
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>margin-left: 15px;
            /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>margin-right: 15px;
            /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .navbar .dropdown-menu a {
            color: black;
        }

        .btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }

        .nav-link:hover {
            background-color: #0000;
            /* لون أزرق غامق عند التحويم */
            color: #ffffff;
            /* تأكيد على بقاء النص باللون الأبيض */
        }
        .nav-link{
            color:#ffffff;
        }
    </style>
</head>

<body>

    <?php include 'sidebaradminsup.php'; ?>

    <!-- Header -->
    <div class="container dashboard-content">
        <div class="row">
            <div id="message" style="color: red;"></div>

            <!-- Toast Container -->
            <div class="toast-container position-fixed top-50 end-50 p-3">
                <?php if (isset($_SESSION['message'])): ?>
                    <div class="toast show" role="alert" aria-live="assertive" aria-atomic="true">
                        <div class="toast-header">
                            <strong class="me-auto">Notification</strong>
                            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                        </div>
                        <div class="toast-body">
                            <?php
                            echo $_SESSION['message'];
                            unset($_SESSION['message']);
                            ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

               <!-- Nav Tabs -->
    <ul class="nav nav-tabs p-1 text-white shadow bg-dark rounded" id="myTab" role="tablist" style="border-width: 4px; border-style: solid;">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="branches-tab" data-bs-toggle="tab" href="#branches" role="tab" aria-controls="branches" aria-selected="true">Branch</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="courses-tab" data-bs-toggle="tab" href="#courses" role="tab" aria-controls="courses" aria-selected="false">Courses</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="exam_schedules-tab" data-bs-toggle="tab" href="#exam_schedules" role="tab" aria-controls="exam_schedules" aria-selected="false">Exam Schedules</a>
        </li>
    </ul>

    <!-- Tab Content -->
    <div class="tab-content mt-4" id="myTabContent">
        <!-- Branches Form -->
        <div class="tab-pane fade show active" id="branches" role="tabpanel" aria-labelledby="branches-tab">
            <form action="add_branch.php" method="POST">
                <div class="mb-3">
                    <label for="branch_name" class="form-label">Branch Name</label>
                    <input type="text" class="form-control" id="branch_name" name="branch_name" required>
                </div>
                <div class="mb-3">
                    <label for="city" class="form-label"><?php echo getTranslation('city', $lang, $translations); ?></label>
                    <select class="form-select" id="city" name="city" required>
                        <option value="" disabled selected><?php echo getTranslation('select_city', $lang, $translations); ?></option>
                        <?php foreach ($cities as $city) : ?>
                            <?php if ($city['lang'] == $lang) : ?>
                                <option value="<?php echo $city['key']; ?>"><?php echo $city['value']; ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="address" name="address">
                </div>
                <div class="mb-3">
                    <label for="phone_number" class="form-label">Phone Number</label>
                    <input type="text" class="form-control" id="phone_number" name="phone_number">
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email">
                </div>
                <button type="submit" class="btn btn-primary">Add Branch</button>
            </form>

            <h4 class="mt-4">Existing Branches</h4>
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th>Branch Name</th>
                            <th>City</th>
                            <th>Address</th>
                            <th>Phone Number</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include 'config/connect.php';
                        $sql = "SELECT * FROM branches";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['branch_name']}</td>
                                        <td>{$row['city']}</td>
                                        <td>{$row['address']}</td>
                                        <td>{$row['phone_number']}</td>
                                        <td>{$row['email']}</td>
                                        <td><a href='edit_branch.php?id={$row['branch_id']}' class='btn btn-secondary btn-sm'>Edit</a></td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>No branches found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Courses Form -->
        <div class="tab-pane fade" id="courses" role="tabpanel" aria-labelledby="courses-tab">
            <form action="add_course.php" method="POST">
                <div class="mb-3">
                    <label for="course_name" class="form-label"><?php echo getTranslation('course_name', $lang, $translations); ?></label>
                    <input type="text" class="form-control" id="course_name" name="course_name" required>
                </div>
                <div class="mb-3">
                    <label for="course_code" class="form-label"><?php echo getTranslation('course_code', $lang, $translations); ?></label>
                    <input type="text" class="form-control" id="course_code" name="course_code" required>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo getTranslation('add_course', $lang, $translations); ?></button>
            </form>

            <h4 class="mt-4"><?php echo getTranslation('existing_courses', $lang, $translations); ?></h4>
            <div class="table-responsive">
                <table class="table table-hover table-bordered">
                    <thead class="table-dark">
                        <tr>
                            <th><?php echo getTranslation('course_name', $lang, $translations); ?></th>
                            <th><?php echo getTranslation('course_code', $lang, $translations); ?></th>
                            <th><?php echo getTranslation('actions', $lang, $translations); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT course_id, course_name, course_code FROM courses";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                        <td>{$row['course_name']}</td>
                                        <td>{$row['course_code']}</td>
                                        <td><a href='edit_course.php?id={$row['course_id']}' class='btn btn-secondary btn-sm'>Edit</a></td>
                                      </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='3'>" . getTranslation('no_courses_found', $lang, $translations) . "</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Exam Schedules Form -->
        <div class="tab-pane fade" id="exam_schedules" role="tabpanel" aria-labelledby="exam_schedules-tab">
        <form method="POST" action="create_exam_schedule.php">

        <div class="mb-3">
        <label for="semester" class="form-label">Semester</label>
        <select class="form-control" id="semester" name="semester" required>
            <option value="1">First Semester</option>
            <option value="2">Second Semester</option>
            <option value="3">Summer Semester</option>
        </select>
    </div>
    <div class="mb-3">
        <label for="exam_id" class="form-label">Exam Type</label>
        <select class="form-control" id="exam_id" name="exam_id" required>
            <option value="1">Midterm Exam</option>
            <option value="2">Final Exam</option>
            <option value="3">Lab</option>
        </select>
    </div>

    <div class="mb-3">
        <label for="exam_date_start" class="form-label">Exam Start Date</label>
        <input type="date" class="form-control" id="exam_date_start" name="exam_date_start" required>
    </div>

    <div class="mb-3">
        <label for="exam_date_end" class="form-label">Exam End Date</label>
        <input type="date" class="form-control" id="exam_date_end" name="exam_date_end" required>
    </div>



    <button type="submit" class="btn btn-primary">Generate Exam Schedule</button>
</form>


<h4 class="mt-4">Existing Exam Schedules</h4>
<div class="table-responsive">
    <table class="table table-hover table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Exam ID</th>
                <th>Branch</th>
                <th>Exam Date Start</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>College</th>
                <th>Department</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "
                SELECT es.*, b.branch_name, cl.College_name, d.Department 
                FROM exam_schedules es 
                JOIN branches b ON es.branch_id = b.branch_id 
                JOIN college cl ON es.College = cl.College_id 
                JOIN department d ON es.Department = d.Department_id
            ";

            $result = $conn->query($sql);

            if (!$result) {
                echo "Error: " . $conn->error;
            } else {
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>{$row['exam_id']}</td>
                                <td>{$row['branch_name']}</td>
                                <td>{$row['exam_date_start']}</td>
                                <td>{$row['start_time']}</td>
                                <td>{$row['end_time']}</td>
                                <td>{$row['College_name']}</td>
                                <td>{$row['Department']}</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No exam schedules found.</td></tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
                        function fetchClassrooms(branchId) {
                            if (branchId) {
                                const xhr = new XMLHttpRequest();
                                xhr.open('GET', `fetch_classrooms.php?branch_id=${branchId}`, true);
                                xhr.onload = function() {
                                    if (this.status === 200) {
                                        const classrooms = JSON.parse(this.responseText);
                                        const classroomSelect = document.getElementById('classroom_id');
                                        classroomSelect.innerHTML = ''; // Clear previous options
                                        classrooms.forEach(function(classroom) {
                                            const option = document.createElement('option');
                                            option.value = classroom.room_id;
                                            option.textContent = classroom.room_name;
                                            classroomSelect.appendChild(option);
                                        });
                                        document.getElementById('classroom-container').style.display = 'block'; // Show classroom section
                                    }
                                };
                                xhr.send();
                            } else {
                                document.getElementById('classroom-container').style.display = 'none'; // Hide classroom section if no branch is selected
                            }
                        }
                    </script>
        <script>
            // Function to check classroom availability and manage form submission
            document.getElementById("end_time").addEventListener("blur", function () {
                var classroomId = document.getElementById("classroom_id").value;
                var branchId = document.getElementById("branch_idl").value; // إضافة branch_id هنا
                var examDate = document.getElementById("exam_date").value;
                var startTime = document.getElementById("start_time").value;
                var endTime = document.getElementById("end_time").value;
                var classMessage = document.getElementById("classMessage");
                var submitButton = document.getElementById("submit");

                // طباعة القيم للتحقق
                console.log("Classroom ID:", classroomId);
                console.log("Branch ID:", branchId); // تأكد من طباعة branch_id
                console.log("Exam Date:", examDate);
                console.log("Start Time:", startTime);
                console.log("End Time:", endTime);

                // التأكد من أن كل الحقول الضرورية مليئة
                if (classroomId && branchId && examDate && startTime && endTime) {
                    // AJAX request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function () {
                        if (this.readyState === 4 && this.status === 200) {
                            var responseText = this.responseText.trim(); // إزالة المسافات الزائدة
                            classMessage.innerText = responseText;

                            // تحقق من توفر القاعة
                            if (responseText === 'The classroom is available.') {
                                submitButton.disabled = false; // تفعيل زر الإرسال
                            } else {
                                submitButton.disabled = true; // تعطيل زر الإرسال
                            }
                        }
                    };
                    xhttp.open("POST", "check_class_availability.php", true);
                    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                    xhttp.send("classroom_id=" + classroomId + "&branch_id=" + branchId + "&exam_date=" + examDate + "&start_time=" + startTime + "&end_time=" + endTime); // إرسال branch_id هنا
                } else {
                    classMessage.innerText = "Please fill in all fields.";
                    submitButton.disabled = true; // تعطيل زر الإرسال إذا كانت الحقول غير مكتملة
                }
            });

            // Function to update the submit button state based on field values
            function updateSubmitButton() {
                var classroomId = document.getElementById("classroom_id").value;
                var branchId = document.getElementById("branch_id").value; // إضافة branch_id هنا
                var examDate = document.getElementById("exam_date").value;
                var startTime = document.getElementById("start_time").value;
                var endTime = document.getElementById("end_time").value;
                var submitButton = document.querySelector("form button[type='submit']");

                // التأكد من أن كل الحقول الضرورية مليئة
                if (classroomId && branchId && examDate && startTime && endTime) {
                    submitButton.disabled = false; // تفعيل زر الإرسال
                } else {
                    submitButton.disabled = true; // تعطيل زر الإرسال
                }
            }
        </script>
 








    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const toastEl = document.querySelector('.toast');
            if (toastEl) {
                const bsToast = new bootstrap.Toast(toastEl);
                setTimeout(() => {
                    bsToast.hide();
                }, 3000);
            }
        });
    </script>


    
    </div>
    </div>
    </div>
    </div>
</body>

</html>