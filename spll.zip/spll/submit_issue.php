
<?php

//submit_issue.php
session_start();
include 'config/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $reported_by_user = $_SESSION['user_id'];
    $branch_id = $_SESSION['branch_id'];
    $description = $conn->real_escape_string($_POST['description']);

    $query = "INSERT INTO issues (reported_by_user,branch_id, description) VALUES ($reported_by_user,'$branch_id', '$description')";

    if ($conn->query($query)) {
        echo "<div class='alert alert-success'>Issue submitted successfully.</div>";
    } else {
        echo "<div class='alert alert-danger'>Error submitting issue: " . $conn->error . "</div>";
    }
}
?>
