<?php
session_start();
include 'lang.php';
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
include 'config/connect.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Incident Report</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <style>
        footer {
    height: 80px;
    background-color: #ffffff; /* Set the footer background color */
    padding: 10px; /* Padding inside the footer */
    text-align: center; /* Center the footer text */
    color: white; /* Change text color to white */
}
html, body {
    height: 100%;
    margin: 0;
    display: flex;
    flex-direction: column;
}

.container {
    flex: 1; /* This allows the container to grow and fill the available space */
}
.btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }
        .btn-primary:hover {
    background-color: #000; /* Keep background color black on hover */
    color: #fff; /* Keep text color white on hover */
    opacity: 0.8; /* Optional: Change opacity on hover for effect */
}

    </style>
</head>
<body>
<?php include 'config/header.php'; ?>
<div class="container mt-5">
    <h2>Exam Incident Report</h2>
    <div id="response_message"></div>

    <form id="incidentReportForm" enctype="multipart/form-data">
        <div class="form-group">
            <label for="type_problem">Type of Problem</label>
            <select class="form-control" id="type_problem" name="type_problem" required>
                <option value="Technical issue">Technical issue</option>
                <option value="Cheating incident">Cheating incident</option>
                <option value="Health issue">Health issue</option>
                <option value="Other">Other</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="description">Description</label>
            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
        </div>
        
        <div class="form-group">
            <label for="attachment">Attachment</label>
            <input type="file" class="form-control-file" id="attachment" name="attachment">
        </div>
        
        <button type="submit" class="btn btn-primary mt-3 mb-3">Submit Report</button>
    </form>
</div>
<?php include 'config/footer.php'; ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

<script>
    $(document).ready(function() {
        $('#incidentReportForm').on('submit', function(event) {
            event.preventDefault();
            let formData = new FormData(this);
            
            $.ajax({
                url: 'submit_incident_report.php',
                type: 'POST',
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#response_message').html(response);
                },
                error: function() {
                    $('#response_message').html('<div class="alert alert-danger">Error submitting report.</div>');
                }
            });
        });
    });
</script>
</body>
</html>
