<?php
session_start();

// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// تضمين ملف الترجمة
include 'lang.php';

// تضمين ملف الاتصال بقاعدة البيانات
include 'config/connect.php';

// التحقق من وجود معرف الفرع في الرابط
if (isset($_GET['id'])) {
    $branch_id = $_GET['id'];

    // استعلام لجلب بيانات الفرع
    $sql = "SELECT * FROM branches WHERE branch_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $branch_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // التحقق من وجود بيانات الفرع
    if ($result->num_rows > 0) {
        $branch = $result->fetch_assoc();
    } else {
        echo "Branch not found.";
        exit();
    }
} else {
    echo "No branch ID specified.";
    exit();
}

// تحديد اللغة
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
?>

<!DOCTYPE html>
<html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('edit_branch', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h3>Edit Branch</h3>
    <form action="update_branch.php?id=<?php echo $branch_id; ?>" method="POST">
        <div class="mb-3">
            <label for="branch_name" class="form-label">Branch Name</label>
            <input type="text" class="form-control" id="branch_name" name="branch_name" value="<?php echo $branch['branch_name']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="city" class="form-label">City</label>
            <input type="text" class="form-control" id="city" name="city" value="<?php echo $branch['city']; ?>" required>
        </div>
        <div class="mb-3">
            <label for="address" class="form-label">Address</label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo $branch['address']; ?>">
        </div>
        <div class="mb-3">
            <label for="phone_number" class="form-label">Phone Number</label>
            <input type="text" class="form-control" id="phone_number" name="phone_number" value="<?php echo $branch['phone_number']; ?>">
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" value="<?php echo $branch['email']; ?>">
        </div>
        <button type="submit" class="btn btn-primary">Update Branch</button>
    </form>
</div>

</body>
</html>
