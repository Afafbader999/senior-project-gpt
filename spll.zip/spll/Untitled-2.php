<?php
// Load Composer's autoloader
require 'vendor/autoload.php';

// Create an instance of PHPMailer
$mail = new PHPMailer\PHPMailer\PHPMailer();

$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->SMTPAuth = true;
$mail->Username   = 'e.exam.proctor.website@gmail.com';                          
$mail->Password   = 'ewwq zdyw yugc lskr'; // Use App Password if 2FA is enabled
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; // Use PHPMailer::ENCRYPTION_STARTTLS if you prefer that
$mail->Port       = 465; // Use 587 for TLS
$mail->setFrom('e.exam.proctor.website@gmail.com', 'E-exam Proctor Support');
$mail->isHTML(true);
$mail->CharSet = "UTF-8";

// Start session and connect to the database
session_start();
require_once('config/connect.php');

// Check session
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect to login page
    exit();
}

// Include language file
include 'lang.php';

// Set language
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

// Retrieve suspended users
$sql = "SELECT user_id, username, email FROM users WHERE account_status = 'Suspended'";
$result = $conn->query($sql);

// Handle account status change
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = intval($_POST['user_id']);
    $action = $_POST['action'];

    if ($action === 'activate') {
        $update_sql = "UPDATE users SET account_status = 'Active' WHERE user_id = $user_id";
    } elseif ($action === 'suspend') {
        $update_sql = "UPDATE users SET account_status = 'Suspended' WHERE user_id = $user_id";
    }

    if ($conn->query($update_sql) === TRUE) {
        echo "<div class='alert alert-success dashboard-content'>Account status updated successfully</div>";

        // Retrieve email of the user
        $email_sql = "SELECT email FROM users WHERE user_id = $user_id";
        $email_result = $conn->query($email_sql);
        if ($email_result->num_rows > 0) {
            $user_email = $email_result->fetch_assoc()['email'];

            // Send email
            $mail->addAddress($user_email);
            $mail->Subject = 'Account Activation';
            $mail->Body = 'Your account has been activated successfully.';

            if ($mail->send()) {
                echo "<div class='alert alert-info dashboard-content'>Activation email sent to $user_email.</div>";
            } else {
                echo "<div class='alert alert-danger dashboard-content'>Failed to send email: " . $mail->ErrorInfo . "</div>";
            }
        }

        header("Refresh:3"); // Refresh the page to reflect changes
    } else {
        echo "<div class='alert alert-danger'>Error updating account status: " . $conn->error . "</div>";
    }
}

?>

<!DOCTYPE html>
<html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('Security', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/styles.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }
        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
            transition: width 0.3s;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .dashboard-header {
            background-color: #000;
            color: white;
            padding: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
            transition: margin  0.3s;
        }
        .dashboard-content {
            padding: 20px;
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="#">Dashboard</a>
        <a href="#">Security</a>
        <a href="#">Settings</a>
    </div>
    <div class="dashboard-header">
        <h1><?php echo getTranslation('Security', $lang, $translations); ?></h1>
    </div>
    <div class="dashboard-content">
        <h2><?php echo getTranslation('Suspended  Users', $lang, $translations); ?></h2>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col"><?php echo getTranslation('Username', $lang, $translations); ?></th>
                    <th scope="col"><?php echo getTranslation('Email', $lang, $translations); ?></th>
                    <th scope="col"><?php echo getTranslation('Actions', $lang, $translations); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                while ($row = $result->fetch_assoc()) {
                    ?>
                    <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo $row['username']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td>
                            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                <button type="submit" name="action" value="activate" class="btn btn-success">Activate</button>
                                <button type="submit" name="action" value="suspend" class="btn btn-danger">Suspend</button>
                            </form>
                        </td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>