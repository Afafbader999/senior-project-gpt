<?php
include 'config/connect.php'; 

$exam_id = $_POST['exam_id'];
$branch_id = $_POST['branch_id'];

// التحقق من أن exam_id و branch_id تم استلامهما
if (isset($exam_id) && isset($branch_id)) {
    // SQL لاسترجاع المواد بناءً على exam_id و branch_id
    $query = "
        SELECT c.course_id, c.course_name
        FROM courses c
        JOIN exam_schedules es ON c.course_id = es.course_id
        WHERE es.exam_id = $exam_id AND es.branch_id = $branch_id
    ";

    $result = mysqli_query($conn, $query);

    // بناء خيارات قائمة المواد
    $options = "<option value=''>Select Course</option>";
    while ($row = mysqli_fetch_assoc($result)) {
        $options .= "<option value='{$row['course_id']}'>{$row['course_name']}</option>";
    }
    echo $options;
}
?>
