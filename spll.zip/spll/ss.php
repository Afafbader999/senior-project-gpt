<!DOCTYPE html>
<html>
<head>
    <title>Proctor Screen Sharing</title>
    <script>
        async function handleScreenSharing(action) {
            const supportUserSelect = document.getElementById('supportUser');
            const supportId = supportUserSelect.value;

            if (!supportId) {
                alert('Please select a support user.');
                return;
            }

            try {
                const response = await fetch('proctor.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=${action}&support_id=${supportId}`
                });

                const result = await response.json();
                alert(result.message);

                if (!result.success) {
                    console.error(result.message);
                }
            } catch (err) {
                console.error('Error:', err);
                alert('An unexpected error occurred.');
            }
        }
    </script>
</head>
<body>
    <h1>Proctor Screen Sharing</h1>

    <!-- اختيار المستخدم من الدعم الفني -->
    <label for="supportUser">Select IT-Support:</label>
    <select id="supportUser">
        <option value="">-- Select IT-Support --</option>
        <?php
        // عرض قائمة المستخدمين من الدعم الفني
        while ($row = $result_support_users->fetch_assoc()) {
            echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
        }
        ?>
    </select>

    <!-- أزرار بدء وإيقاف مشاركة الشاشة -->
    <button onclick="handleScreenSharing('start')">Start Screen Sharing</button>
    <button onclick="handleScreenSharing('stop')">Stop Screen Sharing</button>
</body>
</html>
