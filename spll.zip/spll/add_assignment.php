<?php
require_once('config/connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $exam_id = $_POST['exam_id'];
    $porit_id = $_POST['porit_id'];
    $role = $_POST['role'];
    $branch_id = $_POST['branch_id'];
    $room_id = $_POST['room_id']; // Make sure this field is available
    $course_id = $_POST['course_id']; // Make sure this field is available
    $assignment_date = date('Y-m-d'); // Assuming you want to set the current date

    // Prepare the query
    $query = "INSERT INTO exam_assignments (exam_id, porit_id, role, branch_id, room_id, course_id, assignment_date)
              VALUES ('$exam_id', '$porit_id', '$role', '$branch_id', '$room_id', '$course_id', '$assignment_date')";

    // Execute the query
    if ($conn->query($query) === TRUE) {
        echo "Assignment added successfully.";
    } else {
        echo "Error: " . $conn->error;
    }
}

$conn->close();
?>
