<?php 
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';
include 'lang.php';
$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];
$gender = $_SESSION['gender']; // استبدال $role بـ $gender

// البحث عن المستخدمين الذين يمكن إرسال الرسالة لهم بناءً على الدور
if ($role === 'Proctor') {
    $recipient_role = 'IT-Support';
} else if ($role === 'IT-Support') {
    $recipient_role = 'Proctor';
} else {
    echo "You do not have permission to chat.";
    exit();
}

// البحث عن المستخدمين الذين يمكن التحدث معهم بناءً على الدور والجنس والفرع
$query = "SELECT user_id, username FROM users WHERE role = ? AND branch_id = ? AND gender = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("sis", $recipient_role, $branch_id, $gender);
$stmt->execute();
$result = $stmt->get_result();

// التحقق من وجود مستخدمين
if ($result->num_rows == 0) {
    echo "No users found in the same branch.";
    exit();
}

// الحصول على الجلسات السابقة
$query_sessions = "
    SELECT DISTINCT 
        c.session_id, 
        CASE 
            WHEN c.sender_user_id = $user_id THEN c.Recipient_id 
            ELSE c.sender_user_id 
        END AS other_user_id,
        u.username 
    FROM chats c 
    JOIN users u ON (u.user_id = CASE 
        WHEN c.sender_user_id = $user_id THEN c.Recipient_id 
        ELSE c.sender_user_id 
    END)
    WHERE (c.sender_user_id = $user_id OR c.Recipient_id = $user_id) 
    AND u.branch_id = $branch_id
";
$sessions_result = $conn->query($query_sessions);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Start Chat</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }
        .btn-primary:hover {
            background-color: #0000;
            color: #000;
        }
        html {
            height: 100%;
        }
        body {
            font-family: 'Cairo', sans-serif;
        }
       
        .form-container {
            margin-top: 50px;
            max-width: 500px;
            margin-left: auto;
            margin-right: auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #f9f9f9;
        }
        footer {
            text-align: center;
            background-color: #000;
            color: #fff;
            padding: 10px;
            margin-top: 16%;
        }
    </style>
</head>
<body>
<?php include 'config/header.php'; ?>
    <div class="container mt-5">
        
        <!-- تغيير العنوان بناءً على الدور -->
        <?php if ($role === 'IT-Support'): ?>
            <h2>Start Chat with Proctor</h2>
            <label for="recipient">Select Proctor:</label>
        <?php elseif ($role === 'Proctor'): ?>
            <h2>Start Chat with IT-Support</h2>
            <label for="recipient">Select IT-Support:</label>
        <?php endif; ?>

        <form id="start-chat-form">
            <div class="form-group">
                <select class="form-control" id="recipient" name="recipient_id">
                    <?php
                    // عرض قائمة المستخدمين
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Start Chat</button>
        </form>

        <h4 class="mt-5">Previous Chats:</h4>
        <ul class="list-group">
            <?php while ($session_row = $sessions_result->fetch_assoc()): ?>
                <li class="list-group-item">
                    <?php echo htmlspecialchars($session_row['username']); ?>
                    <a href="chat.php?recipient_id=<?php echo $session_row['other_user_id']; ?>" class="btn btn-secondary btn-sm float-right">Continue</a>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        // عندما يتم اختيار مستلم وبدء المحادثة
        $('#start-chat-form').on('submit', function (e) {
            e.preventDefault();
            const recipient_id = $('#recipient').val(); // الحصول على ID المستلم

            if (recipient_id) {
                window.location.href = 'chat.php?recipient_id=' + recipient_id; // الانتقال إلى صفحة الشات مع المستلم المختار
            }
        });
    </script>
    <?php include 'config/footer.php'; ?>
</body>
</html>