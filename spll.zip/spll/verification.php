<?php
session_start();
require_once('config/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['verification_code'])) {
        $verification_code = $_POST['verification_code'];
        
        // Retrieve the email address from the session
        if (isset($_SESSION['email'])) {
            $email = $_SESSION['email'];
            
            // Check if the verification code matches the one stored in the database
            $sql = "SELECT * FROM users WHERE email = ? AND verification = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $email, $verification_code);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                // Verification successful, mark the user as active
                $row = $result->fetch_assoc();
                $user_id = $row['user_id'];
                $sql_update = "UPDATE users SET verification_use = 'Y' WHERE user_id = ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("i", $user_id);

                if ($stmt_update->execute()) {
                    $_SESSION['user_id'] = $row['user_id'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['role'] = $row['role'];
                    $_SESSION['branch_id'] = $row['branch_id'];
                    
                    // Redirect the user to the pending activation page
                    header("Location: pending_activation.php");
                    exit();
                } else {
                    echo "<p class='error'>Error updating record: " . $conn->error . "</p>";
                }
            } else {
                echo "<p class='error'>Invalid verification code.</p>";
            }
        } else {
            echo "<p class='error'>Session data not found.</p>";
        }
    } else {
        echo "<p class='error'>Verification code is required.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }
        input[type="text"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            text-align: center;
        }
        button[type="submit"], button[type="button"] {
            width: 100%;
            padding: 10px;
            background-color: #000000;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button[type="submit"]:hover, button[type="button"]:hover {
            background-color: #444444;
        }
        .error {
            color: red;
            font-size: 14px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Email Verification</h2>
        <h3>The code has been sent to your email. Please check your email to complete the login.</h3>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="verification_code">Verification Code:</label>
            <input type="text" id="verification_code" name="verification_code" required>
            <button type="submit">Verify</button>
            <br>
            <br>
            <button type="button" onclick="window.location.href='index.php';">Go Home</button>
        </form>
    </div>
</body>
</html>