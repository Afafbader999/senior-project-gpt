<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];

if (!isset($_GET['recipient_id'])) {
    echo "Recipient not selected.";
    exit();
}

$recipient_id = $_GET['recipient_id'];

// البحث عن اسم المستلم والتأكد من أنه في نفس الفرع
$query = "SELECT username FROM users WHERE user_id = ? AND branch_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $recipient_id, $branch_id);
$stmt->execute();
$result = $stmt->get_result();
$recipient = $result->fetch_assoc();

if (!$recipient) {
    echo "Recipient not found in the same branch.";
    exit();
}

$recipient_username = htmlspecialchars($recipient['username']);
$session_id = min($user_id, $recipient_id) . '_' . max($user_id, $recipient_id); // إنشاء معرف الجلسة بناءً على المستخدمين
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with <?php echo $recipient_username; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
    <style>
        .chat-box {
            border: 1px solid #ddd;
            height: 400px;
            overflow-y: scroll;
            padding: 10px;
            margin-bottom: 10px;
            background-color: #f9f9f9;
        }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 8px;
        }
        .message-sent {
            background-color: BlanchedAlmond;
            color: #000;
            text-align: right;
        }
        .message-received {
            background-color: #e0e0e0;
            text-align: left;
        }

        .btn-primary {
            background-color: #000;
            color: #fff;
            padding: 10px 20px;
            border-radius: 15px;
        }

        .btn-primary:hover {
            background-color: #0000;
            /* لون أزرق غامق عند التحويم */
            color: #000;
            /* تأكيد على بقاء النص باللون الأبيض */
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Chat with <?php echo $recipient_username; ?></h2>
        <a href="selectit.php" class="btn btn-secondary mt-3">Back to list Chat</a>
        <br>
        <div class="chat-box" id="chat-box">
            <!-- سيتم تحميل الرسائل هنا عبر JavaScript/AJAX -->
        </div>

        <form id="chat-form" class="chat-form">
            <input type="text" id="message" class="form-control" placeholder="Type your message..." required>
            <button type="submit" class="btn btn-primary mt-3">Send</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
    <script>
        // تحميل الرسائل
        function loadMessages() {
    $.ajax({
        url: 'load_messages.php',
        method: 'GET',
        data: { session_id: '<?php echo $session_id; ?>' },
        success: function(data) {
            $('#chat-box').html(data);
            $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight); // Scroll to the bottom
        },
        error: function(xhr, status, error) {
            console.error("Error loading messages: " + error);
        }
    });
}

        // تحديث الرسائل كل 3 ثوانٍ
        setInterval(loadMessages, 3000);

        // إرسال الرسالة
        $('#chat-form').on('submit', function(e) {
            e.preventDefault();
            const message = $('#message').val();
            if (message.trim()) {
                $.ajax({
                    url: 'send_message.php',
                    method: 'POST',
                    data: {
                        session_id: '<?php echo $session_id; ?>',
                        sender_user_id: '<?php echo $user_id; ?>',
                        recipient_id: '<?php echo $recipient_id; ?>',
                        branch_id: '<?php echo $branch_id; ?>',
                        message_content: message
                    },
                    success: function() {
                        $('#message').val(''); // تفريغ الحقل بعد الإرسال
                        loadMessages(); // تحديث الرسائل بعد الإرسال
                    }
                });
            }
        });

        // رد على الرسالة
        $(document).on('click', '.reply-message', function() {
            const chatId = $(this).data('chat-id');
            const messageDiv = $(this).closest('.message');
            const originalMessage = messageDiv.contents().filter(function() {
                return this.nodeType === 3; // الحصول على نص الرسالة
            }).text().trim();

            const replyMessage = prompt('رد على الرسالة: "' + originalMessage + '"');
            if (replyMessage) {
                $.ajax({
                    url: 'send_message.php',
                    method: 'POST',
                    data: {
                        session_id: '<?php echo $session_id; ?>',
                        sender_user_id: '<?php echo $user_id; ?>',
                        recipient_id: '<?php echo $recipient_id; ?>',
                        branch_id: '<?php echo $branch_id; ?>',
                        message_content: replyMessage + ' (رد على: "' + originalMessage + '")'
                    },
                    success: function() {
                        loadMessages(); // تحديث الرسائل بعد الإرسال
                    }
                });
            }
        });

        // تعديل الرسالة
        $(document).on('click', '.edit-message', function() {
            const chatId = $(this).data('chat-id');
            const messageDiv = $(this).closest('.message');
            const currentMessage = messageDiv.contents().filter(function() {
                return this.nodeType === 3; // الحصول على نص الرسالة
            }).text().trim();

            const newMessage = prompt('Edit your message:', currentMessage);
            if (newMessage) {
                $.ajax({
                    url: 'update_message.php',
                    method: 'POST',
                    data: {
                        chat_id: chatId,
                        message_content: newMessage
                    },
                    success: function() {
                        // تحديث النص وإضافة إشعار "تم تعديل هذه الرسالة"
                        messageDiv.contents().filter(function() {
                            return this.nodeType === 3; // تحديث نص الرسالة
                        }).remove();
                        messageDiv.append(' ' + newMessage + ' <span class="text-muted">(تم تعديل هذه الرسالة)</span>');
                    }
                });
            }
        });

        // حذف الرسالة
        $(document).on('click', '.delete-message', function() {
            const chatId = $(this).data('chat-id');
            $.ajax({
                url: 'delete_message.php',
                method: 'POST',
                data: {
                    chat_id: chatId
                },
                success: function() {
                    // تحديث الرسالة إلى نص "تم حذف هذه الرسالة"
                    const messageDiv = $('[data-chat-id="' + chatId + '"]').closest('.message');
                    messageDiv.html('<span class="text-muted">(تم حذف هذه الرسالة)</span>');
                }
            });
        });

        // تحميل الرسائل عند تحميل الصفحة
        loadMessages();
    </script>
</body>
</html>