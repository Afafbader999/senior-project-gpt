<?php
session_start();
// الاتصال بقاعدة البيانات
require_once('config/connect.php');

// التحقق من إرسال البيانات
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على القيم من النموذج
    $course_name = $_POST['course_name'];
    $course_code = $_POST['course_code'];

    // استعلام SQL لإدخال البيانات
    $sql = "INSERT INTO courses (course_name, course_code) 
            VALUES ('$course_name', '$course_code')";

    // تنفيذ الاستعلام والتحقق
    if ($conn->query($sql) === TRUE) {
        $_SESSION['message'] = 'coruses added successfully.';
        header("Location: dashboardadminsup.php");
        exit();
    } else {
        $_SESSION['message'] = 'An error occurred while adding the courses.';
        header("Location: dashboardadminsup.php");
        exit();
    }
    
    
    // إغلاق الاتصال بقاعدة البيانات
    mysqli_close($conn);
}
?>
