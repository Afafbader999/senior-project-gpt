<?php
session_start();
// Include translations array
include 'lang.php';

// Check if language is set via GET or default to Arabic
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en';

include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$role = $_SESSION['role'];

// التأكد أن المستخدم هو مراقب
if ($role !== 'Proctor') {
    echo "You do not have permission to submit a help request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>" dir="<?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('brand', $lang, $translations); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> <!-- Include jQuery -->
    <style>
        footer {
            text-align: center;
            background-color: #000;
            color: #fff;
            padding: 10px;
        }
    </style>
</head>
<body>
    
<?php
include 'config/header.php';
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// التحقق من تسجيل دخول المستخدم
 
if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-danger">You must be logged in to view your requests.</div>';
    exit;
}

$user_id = $_SESSION['user_id']; // هوية المستخدم الحالي

// جلب الطلبات مع اسم المستخدم المعين
$query = "
    SELECT 
        hr.request_id,
        hr.type_help,
        hr.description,
        hr.status,
        hr.created_at,
        u.username AS assigned_user
    FROM 
        help_requests hr
    LEFT JOIN 
        users u 
    ON 
        hr.assigned_to_user = u.user_id
    WHERE 
        hr.user_id = $user_id
    ORDER BY 
        hr.created_at DESC
";
$result = mysqli_query($conn, $query);
?>
<div class="container mt-5">
    <h2>My Help Requests</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Type of Help</th>
                <th>Description</th>
                <th>Status</th>
                <th>Assigned To</th>
                <th>Date Created</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $assigned_user = $row['assigned_user'] ? $row['assigned_user'] : 'No one has been assigned to handle this request yet.';
                    echo "<tr>
                        <td>{$row['request_id']}</td>
                        <td>{$row['type_help']}</td>
                        <td>{$row['description']}</td>
                        <td>{$row['status']}</td>
                        <td>{$assigned_user}</td>
                        <td>{$row['created_at']}</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No requests found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

<br>
<br>
<?php include 'config/footer.php'; ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#helpRequestForm').on('submit', function(event) {
            event.preventDefault(); // منع إعادة تحميل الصفحة
            
            $.ajax({
                url: 'submit_help_request.php', // صفحة معالجة الطلب
                type: 'POST',
                data: $(this).serialize(), // تحويل بيانات النموذج إلى سلسلة
                success: function(response) {
                    $('#response_message').html(response); // عرض الاستجابة
                },
                error: function() {
                    $('#response_message').html('<div class="alert alert-danger">Error submitting request.</div>');
                }
            });
        });
    });
</script>

</body>
</html>
