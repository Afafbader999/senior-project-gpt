<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات
// التحقق من الجلسة
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php"); // إعادة التوجيه إلى صفحة تسجيل الدخول
    exit();
}

// تضمين ملف الترجمة
include 'lang.php';
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'en'; // افتراضياً اللغة الإنجليزية
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// التحقق من فرع المستخدم
if (!isset($_SESSION['branch_id'])) {
    echo json_encode(["error" => "Branch ID is not set."]);
    exit();
}
$branch_id = intval($_SESSION['branch_id']);

// جلب البيانات من قاعدة البيانات
$branch_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM branches"))['count'];
$admin_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users WHERE role = 'Admin'"))['count'];
$support_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users WHERE role = 'IT-Support'"))['count'];
$monitor_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM users WHERE role = 'Proctor'"))['count'];
$problem_reports = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM report_problems"))['count'];
$evaluation_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS count FROM service_evaluations"))['count'];
?>

<!DOCTYPE html>
<html lang="<?php echo ($lang == 'ar') ? 'ar' : 'en'; ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getTranslation('dashboard', $lang, $translations); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Cairo', sans-serif;
            background-color: #f4f4f9;
            direction: <?php echo ($lang == 'ar') ? 'rtl' : 'ltr'; ?>;
        }

        .card {
            margin: 15px;
        }

        .chart-container {
            margin: 30px 0;
        }

        .sidebar {
            height: 100vh;
            background-color: #000;
            color: white;
            text-align: center;
            padding-top: 20px;
            position: fixed;
            top: 0;
            <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 0;
            width: 250px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 20px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .dashboard-content {
            margin-<?php echo ($lang == 'ar') ? 'right' : 'left'; ?>: 250px;
        }
        .navbar {
            background-color: #000;
            padding: 10px;
            text-align: <?php echo ($lang == 'ar') ? 'right' : 'left'; ?>;
            /* ضبط محاذاة النص */
        }

        .navbar a {
            color: white;
            <?php if ($lang == 'ar') { ?>margin-left: 15px;
            /* المسافة إلى اليسار للغة العربية */
            <?php } else { ?>margin-right: 15px;
            /* المسافة إلى اليمين للغات الأخرى */
            <?php } ?>
        }

        .navbar .dropdown-menu a {
            color: black;
        }
    </style>
</head>

<body>
    <!-- الشريط الجانبي -->
    <?php include 'sidebar.php'; ?>

    <!-- محتوى لوحة التحكم -->
    <div class="container dashboard-content mt-4">
        <h1 class="text-center"><?php echo getTranslation('dashboard', $lang, $translations); ?></h1>

        <!-- بطاقات الإحصائيات -->
        <div class="row text-center">
            <div class="col-md-4">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h3>Branches</h3>
                        <h2><?php echo $branch_count; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-success text-white">
                    <div class="card-body">
                        <h3>Admins</h3>
                        <h2><?php echo $admin_count; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-info text-white">
                    <div class="card-body">
                        <h3>IT Support</h3>
                        <h2><?php echo $support_count; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h3>Proctors </h3>
                        <h2><?php echo $monitor_count; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-danger text-white">
                    <div class="card-body">
                        <h3>Problem Reports</h3>
                        <h2><?php echo $problem_reports; ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card bg-secondary text-white">
                    <div class="card-body">
                        <h3>Evaluations</h3>
                        <h2><?php echo $evaluation_count; ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- الرسوم البيانية -->
        <div class="chart-container">
            <h3 class="text-center">Data Overview</h3>
            <canvas id="barChart"></canvas>
        </div>

       
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js"></script>

    <!-- JavaScript للرسوم البيانية -->
    <script>
        // بيانات الرسم البياني العمودي
        const barData = {
            labels: ['Branches', 'Admins', 'IT Support', 'Proctors', 'Problem Reports', 'Evaluations'],
            datasets: [{
                label: 'Counts',
                data: [
                    <?php echo $branch_count; ?>,
                    <?php echo $admin_count; ?>,
                    <?php echo $support_count; ?>,
                    <?php echo $monitor_count; ?>,
                    <?php echo $problem_reports; ?>,
                    <?php echo $evaluation_count; ?>
                ],
                backgroundColor: [
                    'rgba(54, 162, 235, 0.6)',
                    'rgba(75, 192, 192, 0.6)',
                    'rgba(255, 206, 86, 0.6)',
                    'rgba(153, 102, 255, 0.6)',
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(201, 203, 207, 0.6)'
                ],
                borderWidth: 1
            }]
        };

        // تكوين الرسم البياني العمودي
        const barConfig = {
            type: 'bar',
            data: barData,
            options: { responsive: true }
        };

        // بيانات الرسم البياني الدائري
        const pieData = {
            labels: ['Positive', 'Neutral', 'Negative'], // مثال
            datasets: [{
                label: 'Evaluation Breakdown',
                data: [50, 30, 20], // بيانات افتراضية
                backgroundColor: ['rgba(54, 162, 235, 0.6)', 'rgba(255, 206, 86, 0.6)', 'rgba(255, 99, 132, 0.6)']
            }]
        };

        // تكوين الرسم البياني الدائري
        const pieConfig = { type: 'pie', data: pieData, options: { responsive: true } };

        // عرض الرسوم البيانية
        new Chart(document.getElementById('barChart'), barConfig);
        new Chart(document.getElementById('pieChart'), pieConfig);
    </script>
</body>

</html>
