<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    echo "User not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$session_id = $_POST['session_id'] ?? null;
$recipient_id = $_POST['recipient_id'] ?? null;
$message_content = $_POST['message_content'] ?? null;

if (!$session_id || !$recipient_id || !$message_content) {
    echo "Required fields are missing.";
    exit();
}

// تأكد من أن المحتوى ليس فارغًا
$message_content = trim($message_content);
if (empty($message_content)) {
    echo "Message content cannot be empty.";
    exit();
}

// إدخال البيانات في جدول الشات
$query = "INSERT INTO chats (session_id, sender_user_id, Recipient_id, Branch_id, message_content) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("siiis", $session_id, $user_id, $recipient_id, $branch_id, $message_content);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "Message sent successfully.";
    } else {
        echo "Error sending message.";
    }
    $stmt->close();
} else {
    echo "Database query failed: " . $conn->error;
}

$conn->close();
