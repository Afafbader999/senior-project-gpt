<?php

session_start();
include 'config/connect.php';

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id'];
$type_problem = $_POST['type_problem'];
$description = $_POST['description'];
$attachment_path = null;

if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == 0) {
    $attachment_name = $_FILES['attachment']['name'];
    $attachment_tmp_name = $_FILES['attachment']['tmp_name'];
    $attachment_path = 'uploads/' . $attachment_name;

    move_uploaded_file($attachment_tmp_name, $attachment_path);
}

$query = "INSERT INTO report_problems (reported_by_user,branch_id, type_problem, description, Attachments) 
          VALUES ($user_id, '$branch_id','$type_problem', '$description', '$attachment_path')";

if ($conn->query($query)) {
    echo '<div class="alert alert-success">Report submitted successfully.</div>';
} else {
    echo '<div class="alert alert-danger">Error submitting report.</div>';
}
?>
