<?php
session_start();
include 'config/connect.php'; // الاتصال بقاعدة البيانات
include 'lang.php'; // تضمين الترجمات

// تأكيد تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$branch_id = $_SESSION['branch_id']; // الحصول على رقم الفرع من الجلسة
$role = $_SESSION['role'];
$gender = $_SESSION['gender'];  // يتم تحديد الجنس هنا من الجلسة

// استعلام لاختيار المستخدمين من نفس الفرع
if ($gender == 'Female') {
    $query_support_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ? AND gender = 'Female'";
} else {
    $query_support_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ?";
}

$stmt = $conn->prepare($query_support_users);
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result_support_users = $stmt->get_result();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['support_user'])) {
    // تخزين الجلسة في قاعدة البيانات
    $support_id = $_POST['support_user'];
    $session_link = "https://localhost/screen_share.php?session=" . uniqid() . "&branch=" . $branch_id;

    // استعلام لإدخال الجلسة في قاعدة البيانات
    $query_insert_session = "INSERT INTO sessions (proctor_id, support_id, branch_id, session_link) 
                             VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query_insert_session);
    $stmt->bind_param("iiis", $user_id, $support_id, $branch_id, $session_link);
    $stmt->execute();

    // توليد QR
    include 'phpqrcode/qrlib.php';
    $qr_file = 'qrcode.png'; // ملف QR
    QRcode::png($session_link, $qr_file, 'L', 10, 4);

    echo "<h2>Session Link and QR Code</h2>";
    echo "<p>Share this link with the IT-Support: <a href='$session_link' target='_blank'>$session_link</a></p>";
    echo "<img src='$qr_file' alt='QR Code'>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate QR Code for Session</title>
</head>
<body>
    <h1>Select IT-Support to Share Screen</h1>
    <form method="POST">
        <label for="support_user">Select IT-Support:</label>
        <select name="support_user" id="support_user" required>
            <?php
            while ($row = $result_support_users->fetch_assoc()) {
                echo '<option value="' . $row['user_id'] . '">' . htmlspecialchars($row['username']) . '</option>';
            }
            ?>
        </select>
        <button type="submit">Generate Session</button>
    </form>
</body>
</html>
