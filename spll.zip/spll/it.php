<?php
session_start();
include 'config/connect.php';

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];

if ($role !== 'IT-Support') {
    echo "Access Denied.";
    exit();
}

// استعلام للحصول على جلسات المشاركة النشطة
$query = "SELECT session_id, session_link, proctor_id FROM sessions WHERE support_id = ? AND is_sharing = 1";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
    <title>IT-Support Dashboard</title>
    <script>
        async function joinSession(session_link) {
            window.location.href = session_link;
        }
    </script>
</head>
<body>
    <h1>IT-Support Dashboard</h1>
    <h3>Active Sessions:</h3>
    <ul>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <li>
                Proctor ID: <?php echo $row['proctor_id']; ?> 
                <button onclick="joinSession('<?php echo $row['session_link']; ?>')">Join</button>
            </li>
        <?php } ?>
    </ul>
</body>
</html>
