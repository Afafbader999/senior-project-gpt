<?php
session_start();
include 'config/connect.php';

$user_id = $_SESSION['user_id'];
$role = $_SESSION['role'];
$branch_id = $_SESSION['branch_id'];

if ($role !== 'Proctor') {
    echo "Access Denied.";
    exit();
}

// استعلام للحصول على قائمة الدعم
$query_support_users = "SELECT user_id, username FROM users WHERE role = 'IT-Support' AND branch_id = ?";
$stmt = $conn->prepare($query_support_users);
$stmt->bind_param("i", $branch_id);
$stmt->execute();
$result_support_users = $stmt->get_result();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['start_share'])) {
    $support_id = $_POST['support_id']; // دعم مختار
    $session_link = uniqid("session_", true);
    $query = "INSERT INTO sessions (proctor_id, support_id, branch_id, session_link, is_sharing) 
              VALUES (?, ?, ?, ?, 1)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiis", $user_id, $support_id, $branch_id, $session_link);
    $stmt->execute();
    echo json_encode(["success" => true, "session_link" => $session_link]);
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Proctor Screen Sharing</title>
    <script>
        async function startShare() {
            const support_id = document.getElementById("supportUser").value;

            const response = await fetch("proctor.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `start_share=true&support_id=${support_id}`
            });

            const result = await response.json();
            if (result.success) {
                alert("Screen sharing started. Session link: " + result.session_link);
            } else {
                alert("Failed to start screen sharing.");
            }
        }
    </script>
</head>
<body>
    <h1>Proctor Screen Sharing</h1>
    <label for="supportUser">Select IT-Support:</label>
    <select id="supportUser">
        <?php while ($row = $result_support_users->fetch_assoc()) { ?>
            <option value="<?php echo $row['user_id']; ?>"><?php echo htmlspecialchars($row['username']); ?></option>
        <?php } ?>
    </select>
    <button onclick="startShare()">Start Screen Sharing</button>
</body>
</html>
