<?php
// مصفوفة تحتوي على النصوص باللغتين
$translations = [
    ['key' => 'brand', 'value' => 'دعم مراقبة الامتحانات', 'lang' => 'ar'],
    ['key' => 'brand', 'value' => 'E-exam Proctor Support', 'lang' => 'en'],
    ['key' => 'welcome', 'value' => 'مرحبًا بكم في دعم مراقبة الامتحانات!', 'lang' => 'ar'],
    ['key' => 'welcome', 'value' => 'Welcome to E-exam Proctor Support!', 'lang' => 'en'],
    ['key' => 'description', 'value' => '"نسعى لملء الفجوة بين موظفي الدعم الفني والمراقبين لتجربة امتحانات أفضل."', 'lang' => 'ar'],
    ['key' => 'description', 'value' => '"We aim to bridge the gap between IT support and proctors for a better exam experience."', 'lang' => 'en'],
    ['key' => 'join_us', 'value' => 'انضم إلينا لمساعدة طلابنا.', 'lang' => 'ar'],
    ['key' => 'join_us', 'value' => 'Join us to help our students.', 'lang' => 'en'],
    ['key' => 'join_button', 'value' => 'انضم إلينا', 'lang' => 'ar'],
    ['key' => 'join_button', 'value' => 'Join Us', 'lang' => 'en'],
    ['key' => 'about', 'value' => 'حول', 'lang' => 'ar'],
    ['key' => 'about', 'value' => 'About', 'lang' => 'en'], 
       ['key' => 'index', 'value' => 'الرئيسية', 'lang' => 'ar'],
    ['key' => 'index', 'value' => 'Home', 'lang' => 'en'],
    ['key' => 'login', 'value' => 'تسجيل الدخول', 'lang' => 'ar'],
    ['key' => 'login', 'value' => 'Login', 'lang' => 'en'],
    ['key' => 'signup', 'value' => 'التسجيل', 'lang' => 'ar'],
    ['key' => 'signup', 'value' => 'Sign Up', 'lang' => 'en'],
    ['key' => 'footer', 'value' => 'دعم مراقبة الامتحانات', 'lang' => 'ar'],
    ['key' => 'footer', 'value' => 'Exam Proctoring Support', 'lang' => 'en'], 
    ['key' => 'course', 'value' => 'المقرر', 'lang' => 'ar'],
    ['key' => 'course', 'value' => 'Course', 'lang' => 'en'],
    ['key' => 'time', 'value' => 'الوقت', 'lang' => 'ar'],
    ['key' => 'time', 'value' => 'Time', 'lang' => 'en'],
    ['key' => 'room', 'value' => 'الغرفة', 'lang' => 'ar'],
    ['key' => 'room', 'value' => 'Room', 'lang' => 'en'],
    ['key' => 'building', 'value' => 'المبنى', 'lang' => 'ar'],
    ['key' => 'building', 'value' => 'Building', 'lang' => 'en'],

    //register
   // حقل اسم المستخدم
   ['key' => 'username', 'value' => 'اسم المستخدم', 'lang' => 'ar'],
   ['key' => 'username', 'value' => 'Username', 'lang' => 'en'],

   // حقل البريد الإلكتروني
   ['key' => 'email', 'value' => 'البريد الإلكتروني', 'lang' => 'ar'],
   ['key' => 'email', 'value' => 'Email', 'lang' => 'en'],

   ['key' => 'gender', 'value' => 'الجنس', 'lang' => 'ar'],
   ['key' => 'gender', 'value' => 'gender', 'lang' => 'en'],

   
   ['key' => 'male', 'value' => 'ذكر', 'lang' => 'ar'],
   ['key' => 'male', 'value' => 'male', 'lang' => 'en'],

   ['key' => 'female', 'value' => 'انثى', 'lang' => 'ar'],
   ['key' => 'female', 'value' => 'female', 'lang' => 'en'],

   // حقل كلمة المرور
   ['key' => 'password', 'value' => 'كلمة المرور', 'lang' => 'ar'],
   ['key' => 'password', 'value' => 'Password', 'lang' => 'en'],

   // حقل تأكيد كلمة المرور
   ['key' => 'confirmPassword', 'value' => 'تأكيد كلمة المرور', 'lang' => 'ar'],
   ['key' => 'confirmPassword', 'value' => 'Confirm Password', 'lang' => 'en'],

   // حقل اختيار نوع المستخدم (دور المستخدم)
   ['key' => 'role', 'value' => 'نوع المستخدم', 'lang' => 'ar'],
   ['key' => 'role', 'value' => 'User Role', 'lang' => 'en'],
   
   // الخيارات لنوع المستخدم (مراقب أو دعم تقني)
   ['key' => 'proctor', 'value' => 'مراقب', 'lang' => 'ar'],
   ['key' => 'proctor', 'value' => 'Proctor', 'lang' => 'en'],
   ['key' => 'it_support', 'value' => 'دعم تقني', 'lang' => 'ar'],
   ['key' => 'it_support', 'value' => 'IT Support', 'lang' => 'en'],

   // زر إرسال
   ['key' => 'submit', 'value' => 'تسجيل', 'lang' => 'ar'],
   ['key' => 'submit', 'value' => 'login', 'lang' => 'en'],
   ['key' => 'select_branch', 'value' => 'اختار الفرع', 'lang' => 'ar'],
   ['key' => 'select_branch', 'value' => 'select branch', 'lang' => 'en'],


   ['key' => 'building_name', 'value' => 'اسم المبني', 'lang' => 'ar'],
   ['key' => 'building_name', 'value' => 'building name ', 'lang' => 'en'],


   ['key' => 'room_type', 'value' => 'نوع القاعة ', 'lang' => 'ar'],
   ['key' => 'room_type', 'value' => 'type  room ', 'lang' => 'en'],

   ['key' => 'select_semester', 'value' => ' اختار الفصل الدراسي', 'lang' => 'ar'],
   ['key' => 'select_semester', 'value' => 'select semester  ', 'lang' => 'en'],

   ['key' => 'select_course', 'value' => 'الكورس ', 'lang' => 'ar'],
   ['key' => 'select_course', 'value' => 'select courses ', 'lang' => 'en'],


   ['key' => 'course_name', 'value' => 'الكورس ', 'lang' => 'ar'],
   ['key' => 'course_name', 'value' => 'Name courses ', 'lang' => 'en'],

   ['key' => 'course_code', 'value' => ' كود الكورس ', 'lang' => 'ar'],
   ['key' => 'course_code', 'value' => 'code courses ', 'lang' => 'en'],

   ['key' => 'add_course', 'value' => 'الكورس اضافة', 'lang' => 'ar'],
   ['key' => 'add_course', 'value' => 'Add courses ', 'lang' => 'en'],

   ['key' => 'existing_courses', 'value' => 'الكورس ', 'lang' => 'ar'],
   ['key' => 'existing_courses', 'value' => 'the courses ', 'lang' => 'en'],


   ['key' => 'actions', 'value' => 'عمليات ', 'lang' => 'ar'],
   ['key' => 'actions', 'value' => ' actions ', 'lang' => 'en'],


   ['key' => 'floor', 'value' => 'اسم الطابق', 'lang' => 'ar'],
   ['key' => 'floor', 'value' => 'floor name ', 'lang' => 'en'],
   // اللغة
   ['key' => 'arabic', 'value' => 'العربية', 'lang' => 'ar'],
   ['key' => 'arabic', 'value' => 'Arabic', 'lang' => 'en'],
   ['key' => 'english', 'value' => 'الإنجليزية', 'lang' => 'ar'],
   ['key' => 'english', 'value' => 'English', 'lang' => 'en'],
   //رابط لديا حساب
   ['key' => 'already_have_account', 'value' => 'لديك حساب من قبل', 'lang' => 'ar'],
    ['key' => 'already_have_account', 'value' => 'Already have an account', 'lang' => 'en'],

    // حقل اختيار الفرع
['key' => 'branch', 'value' => 'الفرع', 'lang' => 'ar'],
['key' => 'branch', 'value' => 'Branch', 'lang' => 'en'],


   ['key' => 'dashboard', 'value' => 'لوحة التحكم', 'lang' => 'ar'],
   ['key' => 'dashboard', 'value' => 'Dashboard', 'lang' => 'en'],

   //Account_Security
   ['key' => 'Security', 'value' => 'ادارة الحسابات', 'lang' => 'ar'],
   ['key' => 'Security', 'value' => 'Account managment', 'lang' => 'en'],
   //dashboard
   ['key' => 'database', 'value' => 'البيانات الاساسية', 'lang' => 'ar'],
   ['key' => 'database', 'value' => 'Basic data', 'lang' => 'en'],

   ['key' => 'Account_Security', 'value' => 'ادارة الحسابات', 'lang' => 'ar'],
   ['key' => 'Account_Security', 'value' => 'Account managment', 'lang' => 'en'],
   ['key' => 'reports', 'value' => 'التقارير', 'lang' => 'ar'],
   ['key' => 'reports', 'value' => 'Reports', 'lang' => 'en'],
   ['key' => 'settings', 'value' => 'الإعدادات', 'lang' => 'ar'],
   ['key' => 'settings', 'value' => 'Settings', 'lang' => 'en'],
   ['key' => 'logout', 'value' => 'تسجيل الخروج', 'lang' => 'ar'],
   ['key' => 'logout', 'value' => 'Logout', 'lang' => 'en'],
   ['key' => 'welcome_user', 'value' => 'مرحبًا بك، المستخدم', 'lang' => 'ar'],
   ['key' => 'welcome_user', 'value' => 'Welcome, User', 'lang' => 'en'],
   ['key' => 'user_details', 'value' => 'تفاصيل المستخدم', 'lang' => 'ar'],
   ['key' => 'user_details', 'value' => 'User Details', 'lang' => 'en'],
   ['key' => 'service_info', 'value' => 'معلومات الخدمات', 'lang' => 'ar'],
   ['key' => 'service_info', 'value' => 'Service Information', 'lang' => 'en'],
   ['key' => 'report_info', 'value' => 'معلومات التقارير', 'lang' => 'ar'],
   ['key' => 'report_info', 'value' => 'Report Information', 'lang' => 'en'],
   ['key' => 'menu', 'value' => 'القائمة', 'lang' => 'ar'],
   ['key' => 'menu', 'value' => 'Menu', 'lang' => 'en'],
   // نصوص أخرى مضافة مسبقاً
   ['key' => 'proctor', 'value' => 'مراقب', 'lang' => 'ar'],
   ['key' => 'proctor', 'value' => 'Proctor', 'lang' => 'en'],
   ['key' => 'it_support', 'value' => 'دعم تقني', 'lang' => 'ar'],
   ['key' => 'it_support', 'value' => 'IT Support', 'lang' => 'en'],
   ['key' => 'profile', 'value' => ' الملف الشخصي', 'lang' => 'ar'],
   ['key' => 'profile', 'value' => 'profile', 'lang' => 'en'],

    
 

    // Profile Page Translations
    ['key' => 'profile_title', 'value' => 'الملف الشخصي', 'lang' => 'ar'],
    ['key' => 'profile_title', 'value' => 'Profile', 'lang' => 'en'],
    
    ['key' => 'username', 'value' => 'اسم المستخدم', 'lang' => 'ar'],
    ['key' => 'username', 'value' => 'Username', 'lang' => 'en'],

    ['key' => 'email', 'value' => 'البريد الإلكتروني', 'lang' => 'ar'],
    ['key' => 'email', 'value' => 'Email', 'lang' => 'en'],

    ['key' => 'new_password', 'value' => 'كلمة المرور الجديدة (اترك الحقل فارغاً إذا لم ترغب بالتغيير)', 'lang' => 'ar'],
    ['key' => 'new_password', 'value' => 'New Password (leave empty if not changing)', 'lang' => 'en'],

    ['key' => 'edit_button', 'value' => 'تعديل', 'lang' => 'ar'],
    ['key' => 'edit_button', 'value' => 'Edit', 'lang' => 'en'],

    ['key' => 'save_button', 'value' => 'حفظ التغييرات', 'lang' => 'ar'],
    ['key' => 'save_button', 'value' => 'Save Changes', 'lang' => 'en'],

    ['key' => 'change_password', 'value' => 'تغيير كلمة المرور', 'lang' => 'ar'],
    ['key' => 'change_password', 'value' => 'Change Password', 'lang' => 'en'],
    
    ['key' => 'save_password', 'value' => 'تغيير كلمة المرور', 'lang' => 'ar'],
    ['key' => 'save_password', 'value' => 'Change Password', 'lang' => 'en'],

    ['key' => 'current_password', 'value' => ' الحالية كلمة المرور', 'lang' => 'ar'],
    ['key' => 'current_password', 'value' => 'old Password', 'lang' => 'en'],
    

// login page 
['key' => 'register', 'value' => ' ليس لديا حساب ', 'lang' => 'ar'],
['key' => 'register', 'value' => ' Account create', 'lang' => 'en'],

['key' => 'forgot_password', 'value' => ' نسيت كلمة المرور', 'lang' => 'ar'],
['key' => 'forgot_password', 'value' => 'forgot Password', 'lang' => 'en'],

['key' => 'remember_me', 'value' =>'تذكرني', 'lang' => 'ar'],
['key' => 'remember_me', 'value' => 'remember me', 'lang' => 'en'],


  // About Us Page
  ['key' => 'about_us', 'value' => 'عنّا', 'lang' => 'ar'],
  ['key' => 'about_us', 'value' => 'About Us', 'lang' => 'en'],

  ['key' => 'our_mission', 'value' => 'مهمتنا', 'lang' => 'ar'],
  ['key' => 'our_mission', 'value' => 'Our Mission', 'lang' => 'en'],

  ['key' => 'mission_description', 'value' => 'نهدف إلى مواجهة التحديات التي تواجه الطلاب خلال الامتحانات عبر الإنترنت، مثل مشاكل تكنولوجيا المعلومات والاتصال بالإنترنت، من خلال تسهيل التواصل الفعال بين موظفي الدعم الفني والمراقبين. هدفنا هو تقليل القلق وعدم الراحة، وضمان أن يحصل كل طالب على المساعدة الفورية ويمكنه الأداء بأفضل ما لديه.', 'lang' => 'ar'],
  ['key' => 'mission_description', 'value' => 'We aim to address the challenges faced during online examinations, such as IT and internet connectivity issues, by facilitating efficient communication between IT support staff and invigilators. Our goal is to reduce anxiety and discomfort, ensuring that every student receives prompt assistance and can perform to the best of their abilities.', 'lang' => 'en'],

  ['key' => 'our_history', 'value' => 'تاريخنا', 'lang' => 'ar'],
  ['key' => 'our_history', 'value' => 'Our History', 'lang' => 'en'],

  ['key' => 'history_description', 'value' => 'تأسست في عام 2024، تم إنشاء E-exam ProctorSupport لمواجهة التحديات التي يواجهها الطلاب خلال الامتحانات عبر الإنترنت. من خلال البحث والتحليل، قمنا بتطوير نهج منظم باستخدام منهجية الشلال لضمان التواصل الفعال والدعم.', 'lang' => 'ar'],
  ['key' => 'history_description', 'value' => 'Founded in 2024, E-exam ProctorSupport was created to tackle the challenges students face during online exams. Through research and analysis, we developed a structured approach using the Waterfall methodology to ensure effective communication and support.', 'lang' => 'en'],

  ['key' => 'our_values', 'value' => 'قيمنا', 'lang' => 'ar'],
  ['key' => 'our_values', 'value' => 'Our Values', 'lang' => 'en'],

  ['key' => 'value_student_focused', 'value' => 'تركيز على الطلاب: أولوية احتياجات الطلاب.', 'lang' => 'ar'],
  ['key' => 'value_student_focused', 'value' => 'Student Focused: Prioritizing the needs of students.', 'lang' => 'en'],

  ['key' => 'value_innovation', 'value' => 'الابتكار: تحسين مستمر لمواجهة التحديات المتطورة.', 'lang' => 'ar'],
  ['key' => 'value_innovation', 'value' => 'Innovation: Continuously improving to meet evolving challenges.', 'lang' => 'en'],

  ['key' => 'value_excellence', 'value' => 'التميز: نسعى لتحقيق أعلى معايير الجودة في حلولنا.', 'lang' => 'ar'],
  ['key' => 'value_excellence', 'value' => 'Excellence: We strive to meet the highest standards in our solutions.', 'lang' => 'en'],

  ['key' => 'the_team', 'value' => 'الفريق', 'lang' => 'ar'],
  ['key' => 'the_team', 'value' => 'The Team', 'lang' => 'en'],

  ['key' => 'team_member_rawan', 'value' => 'راوان عبد الله', 'lang' => 'ar'],
  ['key' => 'team_member_rawan', 'value' => 'Rawan Abdullah', 'lang' => 'en'],

  ['key' => 'team_member_shahad', 'value' => 'شهد الخضري', 'lang' => 'ar'],
  ['key' => 'team_member_shahad', 'value' => 'Shahad Alkhodari', 'lang' => 'en'],

  ['key' => 'team_member_afaf', 'value' => 'عفاف بدر', 'lang' => 'ar'],
  ['key' => 'team_member_afaf', 'value' => 'Afaf Bader', 'lang' => 'en'],


  ['key' => 'select_city', 'value' => 'اختر المدينة', 'lang' => 'ar'],
  ['key' => 'select_city', 'value' => 'Select City', 'lang' => 'en'],

  ['key' => 'branch', 'value' => 'اختر الفرع', 'lang' => 'ar'],
  ['key' => 'branch', 'value' => 'Select branch', 'lang' => 'en'],

  //exam_assignments
  
  ['key' => 'exam_assignments', 'value' => 'مواعيدالامتحان ', 'lang' => 'ar'],
  ['key' => 'exam_assignments', 'value' => ' exam schedules', 'lang' => 'en'],
//logout

['key' => 'logout', 'value' => 'تسجيل الخروج', 'lang' => 'ar'],
['key' => 'logout', 'value' => 'log out', 'lang' => 'en'],

['key' => 'invigilators', 'value' => ' توزيع  المراقبين ', 'lang' => 'ar'],
['key' => 'invigilators', 'value' => 'invigilators', 'lang' => 'en'],

['key' => 'myassignments', 'value' => 'تقويمي', 'lang' => 'ar'],
['key' => 'myassignments', 'value' => 'myassignments', 'lang' => 'en'],
];
// رسائل الأخطاء
$translations[] = ['key' => 'account_suspended', 'value' => 'حسابك موقوف.', 'lang' => 'ar'];
$translations[] = ['key' => 'account_suspended', 'value' => 'Your account is suspended.', 'lang' => 'en'];

$translations[] = ['key' => 'invalid_credentials', 'value' => 'اسم المستخدم أو كلمة المرور غير صحيحة.', 'lang' => 'ar'];
$translations[] = ['key' => 'invalid_credentials', 'value' => 'Invalid username or password.', 'lang' => 'en'];

$translations[] = ['key' => 'username_not_exist', 'value' => 'اسم المستخدم لا يوجد.', 'lang' => 'ar'];
$translations[] = ['key' => 'username_not_exist', 'value' => 'Username does not exist.', 'lang' => 'en'];

$translations[] = ['key' => 'missing_credentials', 'value' => 'اسم المستخدم وكلمة المرور مطلوبان.', 'lang' => 'ar'];
$translations[] = ['key' => 'missing_credentials', 'value' => 'Username and password are required.', 'lang' => 'en'];



// Function to get translation by key and language
function getTranslation($key, $lang, $translations) {
    foreach ($translations as $translation) {
        if ($translation['key'] === $key && $translation['lang'] === $lang) {
            return $translation['value'];
        }
    }
    return null; // Return null if translation is not found
}
//city

$cities = [
    ['key' => 'riyadh', 'value' => 'الرياض', 'lang' => 'ar'],
    ['key' => 'riyadh', 'value' => 'Riyadh', 'lang' => 'en'],
    ['key' => 'jeddah', 'value' => 'جدة', 'lang' => 'ar'],
    ['key' => 'jeddah', 'value' => 'Jeddah', 'lang' => 'en'],
    ['key' => 'dammam', 'value' => 'الدمام', 'lang' => 'ar'],
    ['key' => 'dammam', 'value' => 'Dammam', 'lang' => 'en'],
    ['key' => 'khobar', 'value' => 'الخبر', 'lang' => 'ar'],
    ['key' => 'khobar', 'value' => 'Khobar', 'lang' => 'en'],
    ['key' => 'mecca', 'value' => 'مكة', 'lang' => 'ar'],
    ['key' => 'mecca', 'value' => 'Mecca', 'lang' => 'en'],
    ['key' => 'medina', 'value' => 'المدينة المنورة', 'lang' => 'ar'],
    ['key' => 'medina', 'value' => 'Medina', 'lang' => 'en'],
    ['key' => 'tabuk', 'value' => 'تبوك', 'lang' => 'ar'],
    ['key' => 'tabuk', 'value' => 'Tabuk', 'lang' => 'en'],
    ['key' => 'abha', 'value' => 'أبها', 'lang' => 'ar'],
    ['key' => 'abha', 'value' => 'Abha', 'lang' => 'en'],
    ['key' => 'khamees_mushait', 'value' => 'خميس مشيط', 'lang' => 'ar'],
    ['key' => 'khamees_mushait', 'value' => 'Khamis Mushait', 'lang' => 'en'],
    ['key' => 'najran', 'value' => 'نجران', 'lang' => 'ar'],
    ['key' => 'najran', 'value' => 'Najran', 'lang' => 'en'],
    ['key' => 'hufuf', 'value' => 'الهفوف', 'lang' => 'ar'],
    ['key' => 'hufuf', 'value' => 'Al-Hufuf', 'lang' => 'en'],
    ['key' => 'al_qassim', 'value' => 'القصيم', 'lang' => 'ar'],
    ['key' => 'al_qassim', 'value' => 'Al-Qassim', 'lang' => 'en'],
    ['key' => 'buraidah', 'value' => 'بريدة', 'lang' => 'ar'],
    ['key' => 'buraidah', 'value' => 'Buraidah', 'lang' => 'en'],
    // يمكنك إضافة مدن أخرى إذا لزم الأمر
];

?>