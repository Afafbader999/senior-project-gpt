<?php
session_start();
require_once('config/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على القيم من الطلب
    $branch_id = $_POST['branch_id'];
    $room_id = $_POST['classroom_id'];
    $exam_date = $_POST['exam_date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    // تحقق من القاعة
    $query = "SELECT * FROM exam_schedules 
                   WHERE branch_id='$branch_id' 
                   AND room_id='$room_id' 
                   AND exam_date='$exam_date' 
                   AND ('$start_time' < end_time or '$end_time' > start_time)";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        echo 'The classroom is not available.';
    } else {
        echo 'The classroom is available.';
    }
} else {
    echo 'Invalid request.';
}
?>
