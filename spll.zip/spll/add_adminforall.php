<?php
require_once('config/connect.php');

// مصفوفة تحتوي على بيانات الفروع مع أرقام الفروع
$branches = [
    ['branch_id' => 1, 'name' => 'Riyadh Branch', 'email' => 'admin.riyadh@seu.edu.sa'],
    ['branch_id' => 2, 'name' => 'Jeddah Branch', 'email' => 'admin.jeddah@seu.edu.sa'],
    ['branch_id' => 3, 'name' => 'Madinah Branch', 'email' => 'admin.madinah@seu.edu.sa'],
    ['branch_id' => 4, 'name' => 'Dammam Branch', 'email' => 'admin.dammam@seu.edu.sa'],
    ['branch_id' => 5, 'name' => 'Qassim Branch', 'email' => 'admin.qassim@seu.edu.sa'],
    ['branch_id' => 6, 'name' => 'Al-Ahsa Branch', 'email' => 'admin.alahsa@seu.edu.sa'],
    ['branch_id' => 7, 'name' => 'Tabuk Branch', 'email' => 'admin.tabuk@seu.edu.sa'],
    ['branch_id' => 8, 'name' => 'Abha Branch', 'email' => 'admin.abha@seu.edu.sa'],
    ['branch_id' => 9, 'name' => 'Jazan Branch', 'email' => 'admin.jazan@seu.edu.sa'],
    ['branch_id' => 10, 'name' => 'Al-Ula Branch', 'email' => 'admin.alula@seu.edu.sa'],
    ['branch_id' => 11, 'name' => 'Al-Qurayyat Branch', 'email' => 'admin.qurayyat@seu.edu.sa'],
    ['branch_id' => 12, 'name' => 'Hail Branch', 'email' => 'admin.hail@seu.edu.sa'],
    ['branch_id' => 13, 'name' => 'Najran Branch', 'email' => 'admin.najran@seu.edu.sa'],
    ['branch_id' => 14, 'name' => 'Jubail Branch', 'email' => 'admin.jubail@seu.edu.sa'],
];

// كلمة مرور موحدة
$unified_password = "123456";
$password_hash = password_hash($unified_password, PASSWORD_DEFAULT); // تشفير كلمة المرور الموحدة

// إضافة أدمن لكل فرع
foreach ($branches as $branch) {
    $username = $branch['name'] . " Admin";
    $email = $branch['email'];
    $branch_id = $branch['branch_id']; // استخرج رقم الفرع مباشرة من المصفوفة

    // تأكد من وجود فرع بالرقم المحدد
    $query = "INSERT INTO users (username, email, password_hash, role, branch_id, account_status, verification, verification_use ,gender) 
              VALUES ('$username', '$email', '$password_hash', 'Admin', '$branch_id', 'Active', 1, 'Y' ,'male')";

    if (mysqli_query($conn, $query)) {
        echo "Admin added for " . $branch['name'] . "<br>";
    } else {
        echo "Error: " . mysqli_error($conn) . "<br>";
    }
}

// إغلاق الاتصال بقاعدة البيانات
mysqli_close($conn);
?>
